Before run install necessary libraries:

sudo apt-get install cmake build-essential libopencv-dev


The application built with:

cmake version 3.18.4
gcc (Debian 10.2.1-6) 10.2.1 20210110
opencv version: 4.5.1

