Before run install necessary libraries:

sudo apt-get install cmake build-essential libopencv-dev


The application built with:

cmake version 3.25.1
gcc (Debian 12.2.0-14) 12.2.0
opencv version: 4.6.0

