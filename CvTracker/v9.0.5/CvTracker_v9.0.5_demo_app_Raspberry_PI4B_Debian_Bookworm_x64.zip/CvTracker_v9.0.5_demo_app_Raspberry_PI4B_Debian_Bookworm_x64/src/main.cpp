#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <opencv2/opencv.hpp>
#include "CvTracker.h"
#include "SimpleFileDialog.h"
#include "FormatConverterOpenCv.h"
#include "VSourceOpenCv.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::utils;
using namespace cr::video;
using namespace std::chrono;
using namespace cr::vtracker;



/// Parameters class.
class Params
{
public:

    /// Video tracker params.
    class CvTrackerParams
    {
    public:
        /// Size (number of video frames to store) of video frame buffer.
        int frameBufferSize{128};
        /// Horizontal size of tracking rectangle.
        int rectWidth{72};
        /// Vertical size of tracking rectangle.
        int rectHeight{72};
        /// Width of search window.
        int searchWindowWidth{256};
        /// Height of search window.
        int searchWindowHeight{256};
        /// LOST mode option.
        int lostModeOption{0};
        /// Maximum number of frames in LOST mode to auto reset.
        int maxFramesInLostMode{128};
        /// Tracking rectangle auto size flag.
        bool rectAutoSize{false};
        /// Tracking rectangle auto position flag.
        bool rectAutoPosition{false};
        /// Num channels.
        int numChannels{3};
        /// Use multiple threads for calculations. Set by user.
        bool multipleThreads{false};

        JSON_READABLE(CvTrackerParams, frameBufferSize, rectWidth, rectHeight,
                      searchWindowWidth, searchWindowHeight, lostModeOption,
                      maxFramesInLostMode, rectAutoSize, rectAutoPosition,
                      numChannels, multipleThreads);
    };

    /// Video source params.
    class VideoSourceParams
    {
    public:
        /// Video source init string, "file dialog" for file dialog.
        string source{"file dialog"};

        JSON_READABLE(VideoSourceParams, source);
    };

    /// Video tracker params.
    CvTrackerParams videoTracker;
    /// Video source params.
    VideoSourceParams videoSource;

    JSON_READABLE(Params, videoTracker, videoSource);
};



/// Application params.
Params g_params;
/// Video tracker object.
CvTracker g_tracker;
/// Video tracker result data.
VTrackerParams g_trackerData;
/// Video frames width.
int g_frameWidth{0};
/// Video frames height.
int g_frameHeight{0};
/// Horizontal cursor position in video window.
int g_mousePositionX{0};
/// Vertical cursor position in video window.
int g_mousePositionY{0};
/// Buffer for probability chart.
float g_probabilityBuffer[256];
/// Current frame ID in tracker frame buffer.
int32_t g_currentBufferFrameID{0};
/// STOP-FRAME mode flag.
bool g_stopFrameFlag = false;
/// Flag to stop playing video.
bool g_stopPlayFlag = false;
/// Video writer object.
VideoWriter* g_videoWriter = nullptr;



/// Mouse events callback function.
void mouseCallBackFunction(int event, int x, int y, int flags, void* userdata);

/// Draw info on video.
void drawInfoFunction(Mat& frame);

/// Process keyboard events.
void keyboardEventsFunction(int key);

/// Get current date and time string.
std::string getDayTimeString();

/// Draw tracking rectangle.
void drawTrackingRectangle(Mat& frame);

/// Load configuration params from JSON file.
bool loadConfig();



/// Entry point.
int main(void)
{
    // Welcome message.
    cout
    << "===============================================" << endl
    << "CvTracker Demo App v" << CvTracker::getVersion()   << endl
    << "===============================================" << endl
    << endl << endl;

    // Load config file.
    if (!loadConfig())
    {
        cout << "ERROR: Can't open config. New one has been created." << endl;
        this_thread::sleep_for(seconds(1));
        return -1;
    }

    // Open file dialog.
    if (g_params.videoSource.source == "file dialog" ||
        g_params.videoSource.source == "dialog" ||
        g_params.videoSource.source == "File dialog" ||
        g_params.videoSource.source == "Dialog")
        g_params.videoSource.source = SimpleFileDialog::dialog();

    // Open video source.
    VSourceOpenCv videoSource;
    if (!videoSource.openVSource(g_params.videoSource.source))
    {
        cout << "ERROR: Can't open video source." << endl;
        this_thread::sleep_for(seconds(1));
        return -1;
    }

    // Set video tracker params.
    if (!g_tracker.setParam(VTrackerParam::FRAME_BUFFER_SIZE,
                            g_params.videoTracker.frameBufferSize))
        cout << "ERROR: Can't set FRAME_BUFFER_SIZE: " <<
        g_params.videoTracker.frameBufferSize << endl;
    if (!g_tracker.setParam(VTrackerParam::RECT_WIDTH,
                            g_params.videoTracker.rectWidth))
        cout << "ERROR: Can't set RECT_WIDTH: " <<
        g_params.videoTracker.rectWidth << endl;
    if (!g_tracker.setParam(VTrackerParam::RECT_HEIGHT,
                            g_params.videoTracker.rectHeight))
        cout << "ERROR: Can't set RECT_HEIGHT: " <<
        g_params.videoTracker.rectHeight << endl;
    if (!g_tracker.setParam(VTrackerParam::SEARCH_WINDOW_WIDTH,
                            g_params.videoTracker.searchWindowWidth))
        cout << "ERROR: Can't set SEARCH_WINDOW_WIDTH: " <<
        g_params.videoTracker.searchWindowWidth << endl;
    if (!g_tracker.setParam(VTrackerParam::SEARCH_WINDOW_HEIGHT,
                            g_params.videoTracker.searchWindowHeight))
        cout << "ERROR: Can't set SEARCH_WINDOW_HEIGHT: " <<
        g_params.videoTracker.searchWindowHeight << endl;
    if (!g_tracker.setParam(VTrackerParam::LOST_MODE_OPTION,
                            g_params.videoTracker.lostModeOption))
        cout << "ERROR: Can't set LOST_MODE_OPTION: " <<
        g_params.videoTracker.lostModeOption << endl;
    if (!g_tracker.setParam(VTrackerParam::MAX_FRAMES_IN_LOST_MODE,
                            g_params.videoTracker.maxFramesInLostMode))
        cout << "ERROR: Can't set MAX_FRAMES_IN_LOST_MODE: " <<
        g_params.videoTracker.maxFramesInLostMode << endl;
    if (!g_tracker.setParam(VTrackerParam::MAX_FRAMES_IN_LOST_MODE,
                            g_params.videoTracker.maxFramesInLostMode))
        cout << "ERROR: Can't set MAX_FRAMES_IN_LOST_MODE: " <<
        g_params.videoTracker.maxFramesInLostMode << endl;
    if (!g_tracker.setParam(VTrackerParam::RECT_AUTO_SIZE,
                            g_params.videoTracker.rectAutoSize ? 1 : 0))
        cout << "ERROR: Can't set RECT_AUTO_SIZE: " <<
        g_params.videoTracker.rectAutoSize << endl;
    if (!g_tracker.setParam(VTrackerParam::RECT_AUTO_POSITION,
                            g_params.videoTracker.rectAutoPosition ? 1 : 0))
        cout << "ERROR: Can't set RECT_AUTO_POSITION: " <<
        g_params.videoTracker.rectAutoPosition << endl;
    if (!g_tracker.setParam(VTrackerParam::NUM_CHANNELS,
                            g_params.videoTracker.numChannels))
        cout << "ERROR: Can't set NUM_CHANNELS: " <<
        g_params.videoTracker.numChannels << endl;
    if (!g_tracker.setParam(VTrackerParam::MULTIPLE_THREADS,
                            g_params.videoTracker.multipleThreads ? 1 : 0))
        cout << "ERROR: Can't set RECT_AUTO_POSITION: " <<
        g_params.videoTracker.multipleThreads << endl;

    // Get video frame.
    g_frameWidth = (int)videoSource.getParam(VSourceParam::WIDTH);
    g_frameHeight = (int)videoSource.getParam(VSourceParam::HEIGHT);

    // Init mouse position.
    g_mousePositionX = g_frameWidth / 2;
    g_mousePositionY = g_frameHeight / 2;

    // Create images.
    Mat displayImage;
    Mat trackerPatternImage(Size(256, 256), CV_8UC3);
    Mat trackerMaskImage(Size(256, 256), CV_8UC3);
    Mat trackerCorrImage(Size(256, 256), CV_8UC3);

    // Create windows.
    namedWindow("VIDEO TRACKER v" + CvTracker::getVersion(), WINDOW_AUTOSIZE);
    moveWindow("VIDEO TRACKER v" + CvTracker::getVersion(), 0, 0);
    setMouseCallback("VIDEO TRACKER v" + CvTracker::getVersion(),
                         mouseCallBackFunction, nullptr);

    // Init variables.
    Frame sourceFrame;
    Frame bufferFrame;
    Frame playbackBufferFrame;
    Frame yuvFrame;
    Frame tmpFrame(256, 256, Fourcc::GRAY);
    yuvFrame.fourcc = Fourcc::YUV24;
    FormatConverterOpenCv converter;

    // Main loop.
    uint16_t frameId = 0;
    while (true)
    {
        // Get next video frame.
        if (g_stopPlayFlag)
        {
            sourceFrame = playbackBufferFrame;
        }
        else
        {
            if (!videoSource.getFrame(sourceFrame, 1000))
            {
                cout << "Not input video frame" << endl;
                continue;
            }

            playbackBufferFrame = sourceFrame;
        }
        sourceFrame.frameId = frameId++;

        // Update frame size.
        g_frameWidth = (int)videoSource.getParam(VSourceParam::WIDTH);
        g_frameHeight = (int)videoSource.getParam(VSourceParam::HEIGHT);

        // Convert to YUV.
        converter.convert(sourceFrame, yuvFrame);

        // Tracking.
        g_tracker.processFrame(yuvFrame);

        // Get tracker data.
        g_tracker.getParams(g_trackerData);

        // Copy frame to buffer.
        if (g_stopFrameFlag)
            sourceFrame = bufferFrame;
        else
            bufferFrame = sourceFrame;

        // Remember current frame ID.
        if (!g_stopFrameFlag)
            g_currentBufferFrameID = g_trackerData.frameId;

        // Get pattern image.
        g_tracker.getImage(0, tmpFrame);
        Mat tmpFrameCv(tmpFrame.height, tmpFrame.width, CV_8UC1, tmpFrame.data);
        cvtColor(tmpFrameCv, trackerPatternImage, COLOR_GRAY2BGR);

        // Get mask image.
        g_tracker.getImage(1, tmpFrame);
        cvtColor(tmpFrameCv, trackerMaskImage, COLOR_GRAY2BGR);

        // Get correlation surface image.
        g_tracker.getImage(2, tmpFrame);
        cvtColor(tmpFrameCv, trackerCorrImage, COLOR_GRAY2BGR);

        // Draw info function.
        cv::Mat sourceImage(sourceFrame.height, sourceFrame.width, CV_8UC3, sourceFrame.data);
        drawInfoFunction(sourceImage);

        // Record video.
        int pos = 25;
        string str;
        if (g_videoWriter != nullptr)
        {
            // Write video frame.
            g_videoWriter->write(sourceImage);
            str = "RECORDING (R to stop)";
            putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                    Scalar(0, 0, 0), 1, LINE_AA);
            putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                    Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            str = "[R start recording]";
            putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                    Scalar(0, 0, 0), 1, LINE_AA);
            putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                    Scalar(255, 255, 255), 1, LINE_AA);
        }

        pos += 25;
        str = "Mode: ";
        if (g_trackerData.mode == 0)
            str += "FREE";
        else if (g_trackerData.mode == 1)
            str += "TRACKING";
        else if (g_trackerData.mode == 2)
            str += "LOST";
        else if (g_trackerData.mode == 3)
            str += "INERTIAL";
        else if (g_trackerData.mode == 4)
            str += "STATIC";
        else if (g_trackerData.mode == 2)
            str += "UNKNOWN";
        str += " processing time " + to_string(g_trackerData.processingTimeMks / 1000) + " msec";
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[D +8, A -8] Rect width: " + to_string(g_trackerData.rectWidth);
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[W +8, S -8] Rect height: " + to_string(g_trackerData.rectHeight);
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[Q enable/disable] Auto rect size adjustment: " +
              string(g_trackerData.rectAutoSize ? "ON" : "OFF");
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[E enable/disable] Auto rect position adjustment: " +
              string(g_trackerData.rectAutoPosition ? "ON" : "OFF");
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[T move rect Up, G move rect down, F move rect left, H move rect right]";
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[SPACE for STOP-FRAME mode]";
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[ENTER freeze video to capture object]";
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);
        pos += 25;
        str = "[Mouse left button - capture, mouse right button - reset]";
        putText(sourceImage, str, Point(10, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
        putText(sourceImage, str, Point(11, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(255, 255, 255), 1, LINE_AA);

        // Init display image.
        if (displayImage.empty())
        {
            if (g_frameHeight < 828)
                displayImage = Mat::zeros(828, g_frameWidth + 256 + 4, CV_8UC3);
            else
                displayImage = Mat::zeros(g_frameHeight, g_frameWidth + 256 + 4, CV_8UC3);
        }

        putText(displayImage, "PATTERN", Point(g_frameWidth + 2, 15), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1, LINE_AA);
        putText(displayImage, "MASK", Point(g_frameWidth + 2, 20 + 256 + 15), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1, LINE_AA);
        putText(displayImage, "CORRELATION", Point(g_frameWidth + 2, 40 + 512 + 15), FONT_HERSHEY_SIMPLEX, 0.4, Scalar(255, 255, 255), 1, LINE_AA);

        // Copy source image to display image.
        sourceImage.copyTo(displayImage(Rect(0, 0, sourceImage.cols, sourceImage.rows)));
        trackerPatternImage.copyTo(displayImage(Rect(sourceImage.cols + 2, 20, 256, 256)));
        trackerMaskImage.copyTo(displayImage(Rect(sourceImage.cols + 2, 40 + 256, 256, 256)));
        trackerCorrImage.copyTo(displayImage(Rect(sourceImage.cols + 2, 60 + 512, 256, 256)));
        rectangle(displayImage, Rect(sourceImage.cols + 2, 20, 256, 256), Scalar(128, 128, 128), 1);
        rectangle(displayImage, Rect(sourceImage.cols + 2, 40 + 256, 256, 256), Scalar(128, 128, 128), 1);
        rectangle(displayImage, Rect(sourceImage.cols + 2, 60 + 512, 256, 256), Scalar(128, 128, 128), 1);

        // Show images.
        imshow("VIDEO TRACKER v" + CvTracker::getVersion(), displayImage);

        // Process keyboard events.
        keyboardEventsFunction(waitKey(1));
    }

    return 1;
}



void mouseCallBackFunction(int event, int x, int y, int flags, void* userdata)
{
    // Update mouse position.
    g_mousePositionX = x;
    if (g_mousePositionX - g_trackerData.rectWidth / 2 < 1)
        g_mousePositionX = g_trackerData.rectWidth / 2 + 1;
    if (g_mousePositionX + g_trackerData.rectWidth / 2 > g_frameWidth - 1)
        g_mousePositionX = g_frameWidth - g_trackerData.rectWidth / 2 - 1;
    g_mousePositionY = y;
    if (g_mousePositionY - g_trackerData.rectHeight / 2 < 1)
        g_mousePositionY = g_trackerData.rectHeight / 2 + 1;
    if (g_mousePositionY + g_trackerData.rectHeight / 2 > g_frameHeight - 1)
        g_mousePositionY = g_frameHeight - g_trackerData.rectHeight / 2 - 1;

    // Check event.
    switch (event)
    {
    case cv::EVENT_LBUTTONDOWN: // Capture/Reset function
    {
        /*
        Capture object if tracker is free.
        last parameter is frame ID of last displayed frame (for STOP-FRAME).
        */
        g_tracker.executeCommand( VTrackerCommand::CAPTURE,
                g_mousePositionX, g_mousePositionY, g_currentBufferFrameID);

        // Reset buffers for charts.
        memset(g_probabilityBuffer, 0, 256 * sizeof(float));

        g_stopFrameFlag = false;
        g_stopPlayFlag = false;
    }
    break;
    case cv::EVENT_RBUTTONDOWN:
    {
        // Reset tracker if tracker no in FREE mode.
        g_tracker.executeCommand(VTrackerCommand::RESET);
        g_stopFrameFlag = false;
        g_stopPlayFlag = false;
    }
    break;
    case cv::EVENT_MBUTTONDOWN:	break;
    case cv::EVENT_MOUSEMOVE:	break;
    }
}



void drawInfoFunction(Mat& frame)
{
    // Check video tracker mode. We draw video tracker data only in tracking modes.
    if (g_trackerData.mode != 0)
    {
        // Choose a color for tracking the rectangle depending on mode.
        Scalar strobColor;
        if (g_trackerData.mode == 1)
            strobColor = Scalar(0, 0, 255);
        if (g_trackerData.mode == 2)
            strobColor = Scalar(255, 0, 0);
        if (g_trackerData.mode == 3)
            strobColor = Scalar(0, 255, 0);
        if (g_trackerData.mode == 4)
            strobColor = Scalar(255, 255, 0);

        // Calculate tracking rectangle.
        Rect strobeRect(g_trackerData.rectX - g_trackerData.rectWidth / 2,
            g_trackerData.rectY - g_trackerData.rectHeight / 2,
            g_trackerData.rectWidth, g_trackerData.rectHeight);
        // Calculate object rectangle.
        Rect objectRect(g_trackerData.objectX - g_trackerData.objectWidth / 2,
            g_trackerData.objectY - g_trackerData.objectHeight / 2,
            g_trackerData.objectWidth, g_trackerData.objectHeight);

        // Draw object rectangle.
        rectangle(frame, objectRect, Scalar(255, 255, 255), 1);
        // Draw tracking rectangle.
        rectangle(frame, strobeRect, strobColor, 2 * 2);

        // Draw center of tracking rectangle.
        if (g_trackerData.mode == 1)
        {
            line(frame, Point(g_trackerData.rectX - 10,
                              g_trackerData.rectY),
                Point(g_trackerData.rectX + 10, g_trackerData.rectY),
                Scalar(255, 255, 255));
            line(frame, Point(g_trackerData.rectX, g_trackerData.rectY - 10),
                 Point(g_trackerData.rectX, g_trackerData.rectY + 10),
                 Scalar(255, 255, 255));
        }
    }
    else
    {
        // In FREE mode draw only capture rectangle.
        rectangle(frame, Rect(g_mousePositionX - g_trackerData.rectWidth / 2,
            g_mousePositionY - g_trackerData.rectHeight / 2,
            g_trackerData.rectWidth, g_trackerData.rectHeight),
            Scalar(255, 255, 255), 2);
    }
}



void keyboardEventsFunction(int key)
{
    // Check returned value from cv::waitKey(...) function.
    switch (key) {
    // ESC - EXIT.
    case 27:
        std::cout << "EXIT" << std::endl;
        if (g_videoWriter != nullptr)
            g_videoWriter->release();
        exit(0);
    // W - Increase tracking rectangle vertical size.
    case 119:
        g_tracker.setParam(VTrackerParam::RECT_HEIGHT,
        (float)g_trackerData.rectHeight + 8.0f);
        break;
    // S - Decrease tracking rectangle vertical size.
    case 115:
        g_tracker.setParam(VTrackerParam::RECT_HEIGHT,
        (float)g_trackerData.rectHeight - 8.0f);
        break;
    // D - Increase tracking rectangle horizontal size.
    case 100:
        g_tracker.setParam(VTrackerParam::RECT_WIDTH,
        (float)g_trackerData.rectWidth + 8.0f);
        break;
    // A - Decrease tracking rectangle horizontal size.
    case 97:
        g_tracker.setParam(VTrackerParam::RECT_WIDTH,
        (float)g_trackerData.rectWidth - 8.0f);
        break;
    // T - Move strobe UP (change position in TRACKING mode).
    case 116:
        g_tracker.executeCommand(VTrackerCommand::MOVE_RECT, 0, 4);
        break;
    // G - Move strobe DOWN (change position in TRACKING mode).
    case 103:
        g_tracker.executeCommand(VTrackerCommand::MOVE_RECT, 0, -4);
        break;
    // H - Move strobe RIGHT (change position in TRACKING mode).
    case 104:
        g_tracker.executeCommand(VTrackerCommand::MOVE_RECT, -4, 0);
        break;
    // F - Move strobe LEFT (change position in TRACKING mode).
    case 102:
        g_tracker.executeCommand(VTrackerCommand::MOVE_RECT, 4, 0);
        break;
    // R - Start/stop video recording.
    case 114:
        if (g_videoWriter != nullptr)
        {
            g_videoWriter->release();
            g_videoWriter = nullptr;
        }
        else {
            std::string videoFileName = "record_" + getDayTimeString() + ".avi";
            g_videoWriter = new cv::VideoWriter(
                videoFileName, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'), 30,
                cv::Size(g_frameWidth, g_frameHeight), true);
            assert(g_videoWriter != 0);
        }
        break;
    // Z - Adjust of tracking rectangle and position.
    case 122:
        g_tracker.executeCommand(VTrackerCommand::ADJUST_RECT_SIZE);
        g_tracker.executeCommand(VTrackerCommand::ADJUST_RECT_POSITION);
        break;
    // Q - enable/disable tracking rectangle auto size.
    case 113:
        g_tracker.setParam(VTrackerParam::RECT_AUTO_SIZE, g_trackerData.rectAutoSize ? 0 : 1);
        break;
    // E - enable/disable tracking rectangle auto position.
    case 101:
        g_tracker.setParam(VTrackerParam::RECT_AUTO_POSITION, g_trackerData.rectAutoPosition ? 0 : 1);
        break;
    // SPACE - on/off STOP-FRAME mode.
    case 32:
        if (g_stopFrameFlag)
            g_stopFrameFlag = false;
        else
            g_stopFrameFlag = true;
        break;
    // ENTER - on/off stop playback mode.
    case 13:
        g_stopPlayFlag = !g_stopPlayFlag;
        break;

    default:
        return;
    }
}



std::string getDayTimeString()
{
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);

    std::stringstream ss;
    ss << std::put_time(std::localtime(&in_time_t), "%d_%m_%Y_%H_%M_%S");
    std::string str = ss.str();

    return str;
}



bool loadConfig()
{
    ConfigReader config;
    std::string configFileName = "CvTrackerDemo.json";

    // Open config json file (if not exist - create new and exit)
    if(config.readFromFile(configFileName))
    {
        // Read values and set to params
        if(!config.get(g_params, "Params"))
        {
            cout << "ERROR: Invalid params in config file" << endl;

            // Save params.
            config.set(g_params, "Params");
            config.writeToFile(configFileName);
            return true;
        }
    }
    else
    {
        cout << "ERROR: Can't open config file" << endl;

        // Save params.
        config.set(g_params, "Params");
        config.writeToFile(configFileName);
        return true;
    }

    return true;
}