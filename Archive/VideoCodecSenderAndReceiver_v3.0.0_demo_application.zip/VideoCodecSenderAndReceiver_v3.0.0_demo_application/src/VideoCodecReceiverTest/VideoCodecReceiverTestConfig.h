#pragma once
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <ctime>
#include <cstring>
#include <cstdint>
#include <atomic>

#include <opencv2/opencv.hpp>

#include "Tracer.h"
#include "UdpChannel.h"
#include "ConfigReader.h"
#include "UsefulDefines.h"
#include "VideoCodec.h"
#include "VideoDataProtocolParser.h"

#ifdef VIDEO_CODEC_INTEL_MEDIA
#include "VideoCodecIntelMedia.h"
#endif
#ifdef VIDEO_CODEC_GSTREAMER
#include "VideoCodecGstreamer.h"
#endif

#ifdef PIXEL_CONVERTER_INTEL_IPP
#include "IntelIPP_PixelFormatConverter.h"
#endif
#ifdef PIXEL_CONVERTER_PURE_CPP
#include "PureCPP_PixelFormatConverter.h"
#endif
#ifdef PIXEL_CONVERTER_OPEN_CV
#include "OpenCV_PixelFormatConverter.h"
#endif

using namespace vsource;
using namespace cr::clib;
using namespace cr::utils;
using namespace std::chrono;

static std::shared_ptr<Tracer>
g_tracer = Tracer::createTracer(DEBUG, "VideoCodecReceiverTest");

class Params {
public:
    class VideoStreamChannel : public InitParamsBase {
    public:
        std::string dstIp;
        uint16_t hostUdpPort;
        uint16_t dstUdpPort;
        uint16_t waitTimeoutMs;

        JSON_READABLE(VideoStreamChannel,
                      dstIp, hostUdpPort, dstUdpPort, waitTimeoutMs)

        std::string toInitString() {
            initList.clear();
            initList.push_back(dstIp);
            initList.push_back(std::to_string(hostUdpPort));
            initList.push_back(std::to_string(dstUdpPort));

            return InitParamsBase::toInitString();
        }
    };


    class Additional
    {
    public:
        bool showInputVideo;

        JSON_READABLE(Additional, showInputVideo);
    };

    VideoStreamChannel videoStreamChannel;
    Additional additional;

    JSON_READABLE(Params, videoStreamChannel, additional)
};


/*
GLOBAL VARIABLES
*/
Params g_params;
std::shared_ptr<UdpChannel> g_videoStreamChannel(new UdpChannel());

#ifdef PIXEL_CONVERTER_INTEL_IPP
auto g_pixelFormatConverter(new IntelIPP_PixelFormatConverter());
#endif
#ifdef PIXEL_CONVERTER_PURE_CPP
auto g_pixelFormatConverter(new PureCPP_PixelFormatConverter());
#endif
#ifdef PIXEL_CONVERTER_OPEN_CV
auto g_pixelFormatConverter(new OpenCV_PixelFormatConverter());
#endif

#ifdef VIDEO_CODEC_INTEL_MEDIA
auto g_videoCodec = new vcodec::VideoCodecIntelMedia();
#endif
#ifdef VIDEO_CODEC_GSTREAMER
auto g_videoCodec = new vcodec::VideoCodecGstreamer();
#endif

std::mutex telemetryMutex;
std::map<int, std::map<std::string, int>> telemetryInfo;
