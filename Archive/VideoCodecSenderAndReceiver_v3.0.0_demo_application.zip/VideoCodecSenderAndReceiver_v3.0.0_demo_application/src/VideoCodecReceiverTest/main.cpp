#include "VideoCodecReceiverTestVersion.h"
#include "VideoCodecReceiverTestConfig.h"

/**
 * @brief Loading configuration params from JSON file.
 * @return TRUE on success or FALSE.
 */
bool loadConfig();

/**
 * @brief Initialization of program variables and objects.
 * @return TRUE on success or FALSE.
 */
bool initProgram();

/**
 * @brief Function to draw string on frame
 * @param Frame on which to be drawn
 * @param str to be written
 */
void drawStrOnFrame(cv::Mat& Frame, std::string str);

int main(void)
{
    std::cout<<"=================================================" << std::endl;
    std::cout<<"Video Receiver Test "<< RECEIVER_TEST_VERSION      << std::endl;
    std::cout<<"=================================================" << std::endl;
    std::cout<<"Submodule versions: "                              << std::endl;
    std::cout<<"Tracer:............"<< Tracer::getVersion()        << std::endl;
    std::cout<<"ConfigReader:......"<< ConfigReader::getVersion()  << std::endl;
    std::cout<<"UsefulDefines:....."<< UsefulDefines::getVersion() << std::endl;
    std::cout<<"UdpChannel:........"<< UdpChannel::getVersion()    << std::endl;
    std::cout<<"UdpSocket:........."<< UdpSocket::getVersion()     << std::endl;
    std::cout<<"VideoCodec:........"<< g_videoCodec->getVersion()  << std::endl;
    std::cout<<"-------------------------------------------------" << std::endl;

    // Load configuration.
    if (!loadConfig()) {
        g_tracer->print(EXCEPTION)<< "Configuration file not loaded"<<std::endl;
        return -1;
    }

    // Init program parameters.
    if (!initProgram()) {
        g_tracer->print(EXCEPTION)<<"Program initialization problems"<<std::endl;
        return -1;
    }

    // Init video protocol parser.
    vsource::VideoDataProtocolParser videoProtocolParser;

    // Init images.
    // received compressed frame in h264 or h265 format after protocol decoding
    vsource::Frame inputEncodedFrame;
    // raw frame in NV12 format after decoding of inputEncodedFrame
    vsource::Frame decodedNV12Frame;
    decodedNV12Frame.fourcc = (uint32_t)vsource::ValidFourccCodes::NV12;
    // raw frame in BGR24 format after pixel format converting of decodedNV12Frame
    vsource::Frame decodedBgrFrame;
    decodedBgrFrame.fourcc = (uint32_t)vsource::ValidFourccCodes::BGR24;
    // cv::Mat frame in BGR24 format for displaying
    cv::Mat decodedBgrMatFrame;


    // Main loop.
    const uint32_t inputDataBufferSize = 1920 * 1080 * 3;
    uint8_t* inputDataBuffer = new uint8_t[inputDataBufferSize];
    INIT_TIME_MEASUREMENT(capturingTime);
    INIT_TIME_MEASUREMENT(transcodingTime);
    INIT_TIME_MEASUREMENT(convertingTime);
    INIT_TIME_MEASUREMENT(showingTime);
    INIT_TIME_MEASUREMENT(mainCycleTime);
    while (true)
	{
		// Wait data wait_data_time_ms ms.
        uint32_t inputDataSize = 0;
        int32_t logicPort = 0;
        // Wait new video frame.
        if (!g_videoStreamChannel->getData(
                    inputDataBuffer, inputDataBufferSize, inputDataSize,
                    logicPort, g_params.videoStreamChannel.waitTimeoutMs)) {
            g_tracer->print(WARNING) << "no data" << std::endl;
            continue;
        }

		// Decode video protocol.
        if (!videoProtocolParser.decode(
                    inputEncodedFrame, inputDataBuffer, inputDataSize)) {
            g_tracer->print(WARNING) << "Input data not decoded" << std::endl;
			continue;
        }
        GET_TIME_MEASUREMENT(capturingTime, milliseconds);

        // Decomress data.
        START_TIME_MEASUREMENT(transcodingTime);
        if (!g_videoCodec->transcode(inputEncodedFrame, decodedNV12Frame)) {
            g_tracer->print(WARNING) << "not decoded" << std::endl;
			continue;
		}
        GET_TIME_MEASUREMENT(transcodingTime, milliseconds);

        // Convert to BGR24.
        START_TIME_MEASUREMENT(convertingTime);
        g_pixelFormatConverter->convert(decodedNV12Frame, decodedBgrFrame);
        GET_TIME_MEASUREMENT(convertingTime, milliseconds);

        START_TIME_MEASUREMENT(showingTime)
        if (decodedBgrMatFrame.empty() ||
            (int)decodedBgrFrame.width != decodedBgrMatFrame.size().width ||
            (int)decodedBgrFrame.height != decodedBgrMatFrame.size().height)
            decodedBgrMatFrame = cv::Mat(cv::Size(decodedBgrFrame.width, decodedBgrFrame.height), CV_8UC3);
        memcpy(decodedBgrMatFrame.data, decodedBgrFrame.data, decodedBgrFrame.size);


        // Show input video.
        if (g_params.additional.showInputVideo) {
            // Show image.
            drawStrOnFrame(decodedBgrMatFrame, std::to_string(inputEncodedFrame.frameID));
            cv::imshow("RECEIVED VIDEO", decodedBgrMatFrame);

            // Wait keyboard events.
            switch (cv::waitKey(1))
            {
            case 27: // Exit.
                cv::destroyAllWindows();
                return 1;
                break;

            default:
                break;
            }
        }
        GET_TIME_MEASUREMENT(showingTime, milliseconds);
        GET_TIME_MEASUREMENT(mainCycleTime, milliseconds);

        g_tracer->print(WHITE, "FrameId") << inputEncodedFrame.frameID << ": ";
        g_tracer->print(WHITE, "Main Cycle") << "" << mainCycleTime << " ms = ";
        g_tracer->print(WHITE, "Capturing") << "" << capturingTime << " ms + ";
        g_tracer->print(WHITE, "Transcoding") << "" << transcodingTime << " ms + ";
        g_tracer->print(WHITE, "Converting") << "" << convertingTime << " ms + ";
        g_tracer->print(WHITE, "Showing") << "" << showingTime << " ms " << std::endl;

        // Reset cycle time.
        START_TIME_MEASUREMENT(mainCycleTime);
        START_TIME_MEASUREMENT(capturingTime);
	}

	return 1;
}



bool loadConfig()
{
    ConfigReader config;
    const std::string configFileName = "VideoCodecReceiverTest.json";

    // Open config json file (if not exist - create new and exit)
    if(config.readFromFile(configFileName)) {
        // Read values and set to params
        if(!config.get(g_params, "Params")) {
            g_tracer->print(WARNING) << "Params were not read" << std::endl;
            return false;
        }
    }else {
        g_tracer->print(EXCEPTION) << "Config file not loaded" << std::endl;
        config.set(g_params, "Params");
        config.writeToFile(configFileName);
        return false;
    }

    return true;
}

bool initProgram()
{
    std::string initString = "";

    initString = g_params.videoStreamChannel.toInitString();
    if (!g_videoStreamChannel->init(initString)) {
        g_tracer->print(EXCEPTION) << "UDP channel not init" << std::endl;
        return false;
    }

    return true;
}


void drawStrOnFrame(cv::Mat& Frame, std::string str)
{
    cv::rectangle(Frame, cv::Rect(0,0,150,30), cv::Scalar(0,0,0), cv::FILLED);
    cv::putText(Frame, str, cv::Point(5, 20),
                cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(255, 255, 255), 2);
}
