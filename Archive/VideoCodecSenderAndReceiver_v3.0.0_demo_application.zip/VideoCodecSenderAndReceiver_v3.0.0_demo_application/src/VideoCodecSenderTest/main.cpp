#include "VideoCodecSenderTestVersion.h"
#include "VideoCodecSenderTestConfig.h"

/**
 * @brief Loading configuration params from JSON file.
 * @return TRUE on success or FALSE.
 */
bool loadConfig();

/**
 * @brief Initialization of program variables and objects.
 * @return TRUE on success or FALSE.
 */
bool initProgram();

/**
 * @brief Video stream thread function.
 */
void videoStreamThreadFunction();

/**
 * @brief Print Statistic thread function.
 */
void printStatisticThreadFunction();

/**
 * @brief Function to draw string on frame
 * @param Frame on which to be drawn
 * @param str to be written
 */
void drawStrOnFrame(cv::Mat& Frame, std::string str);

int main(void)
{
    std::cout<<"=================================================" << std::endl;
    std::cout<<"Video Sender Test "<< SENDER_TEST_VERSION          << std::endl;
    std::cout<<"=================================================" << std::endl;
    std::cout<<"Submodule versions: "                              << std::endl;
    std::cout<<"Tracer:............"<< Tracer::getVersion()        << std::endl;
    std::cout<<"ConfigReader:......"<< ConfigReader::getVersion()  << std::endl;
    std::cout<<"UsefulDefines:....."<< UsefulDefines::getVersion() << std::endl;
    std::cout<<"UdpChannel:........"<< UdpChannel::getVersion()    << std::endl;
    std::cout<<"UdpSocket:........."<< UdpSocket::getVersion()     << std::endl;
    std::cout<<"VideoSource:......."<< g_videoSource->getVersion() << std::endl;
    std::cout<<"VideoCodec:........"<< g_videoCodec->getVersion()  << std::endl;
    std::cout<<"-------------------------------------------------" << std::endl;

    // Load configuration.
    if (!loadConfig()) {
        g_tracer->print(EXCEPTION)<< "Configuration file not loaded"<<std::endl;
        return -1;
    }

    // Init program parameters.
    if (!initProgram()) {
        g_tracer->print(EXCEPTION)<<"Program initialization problems"<<std::endl;
        return -1;
    }

    // Launch video strem thread.
    std::thread videoStreamThread(&videoStreamThreadFunction);
    // Launch video statistic thread.
    std::thread videoStatisticThread(&printStatisticThreadFunction);

    // Init frames.
    int frameId = 0;
    int frameWidth = g_params.videoSource.frameWidth;
    int frameHeight = g_params.videoSource.frameHeight;
    uint32_t fourccNV12 = (uint32_t)ValidFourccCodes::NV12;
    uint32_t fourccBGR24 = (uint32_t)ValidFourccCodes::BGR24;
    Frame sourceFrameNV12 = Frame(frameWidth, frameHeight, fourccNV12);
    Frame sourceFrameBGR = Frame(frameWidth, frameHeight, fourccBGR24);

    // Main loop.
    INIT_TIME_MEASUREMENT(capturingTime);
    INIT_TIME_MEASUREMENT(convertingTime);
    INIT_TIME_MEASUREMENT(showingTime);
    INIT_TIME_MEASUREMENT(mainCycleTime);
    while (true)
    {
        // Wait new video frame.
        if (!g_videoSource->GetFrame(sourceFrameBGR, g_params.videoSource.waitTimeoutMs)) {
            continue;
        }
        GET_TIME_MEASUREMENT(capturingTime, milliseconds);


        // Convert to NV12 pixel format.
        START_TIME_MEASUREMENT(convertingTime);
        g_pixelFormatConverter->convert(sourceFrameBGR, sourceFrameNV12);
        GET_TIME_MEASUREMENT(convertingTime, milliseconds);


        START_TIME_MEASUREMENT(showingTime)
        // Copy frame to video stream thread.
        sharedFrameNv12Mutex.lock();
        sourceFrameNV12.frameID = ++frameId;
        sharedFrameNv12 = sourceFrameNV12;
        sharedFrameNv12Flag.store(true);
        sharedFrameNv12Mutex.unlock();
        // Notify stream thread about new frame.
        std::unique_lock<std::mutex> lk(sharedFrameNv12CondVarMutex);
        sharedFrameNv12CondVarFlag.store(true);
        sharedFrameNv12CondVar.notify_one();
        lk.unlock();

        // Show input video.
        if (g_params.additional.showInputVideo) {
            // Draw timer data.
            cv::Mat display_frame = cv::Mat(cv::Size(g_params.videoSource.frameWidth, g_params.videoSource.frameHeight), CV_8UC3);
            memcpy(display_frame.data, sourceFrameBGR.data, g_params.videoSource.frameWidth * g_params.videoSource.frameHeight * 3);
            drawStrOnFrame(display_frame, std::to_string(frameId));
            cv::imshow("INPUT VIDEO", display_frame);

            // Wait keyboard events.
            switch (cv::waitKey(1))
            {
            case 27: // Exit.
                cv::destroyAllWindows();
                return 1;
                break;

            default:
                break;
            }
        }
        GET_TIME_MEASUREMENT(showingTime, milliseconds);


        GET_TIME_MEASUREMENT(mainCycleTime, milliseconds);
        // Wait according to stream FPS.
        std::this_thread::sleep_for(milliseconds((int)(1000.0 / g_params.videoSource.fps - mainCycleTime)));


        GET_TIME_MEASUREMENT(mainCycleTime, milliseconds);
        telemetryMutex.lock();
        telemetryInfo[frameId]["Capturing"] = capturingTime;
        telemetryInfo[frameId]["Converting"] = convertingTime;
        telemetryInfo[frameId]["Showing"] = showingTime;
        telemetryInfo[frameId]["MainCycle"] = mainCycleTime;
        telemetryMutex.unlock();

        // Reset cycle time.
        START_TIME_MEASUREMENT(mainCycleTime);
        START_TIME_MEASUREMENT(capturingTime);
    }

    return 1;
}



bool loadConfig()
{
    ConfigReader config;
    const std::string configFileName = "VideoCodecSenderTest.json";

    // Open config json file (if not exist - create new and exit)
    if(config.readFromFile(configFileName)) {
        // Read values and set to params
        if(!config.get(g_params, "Params")) {
            g_tracer->print(WARNING) << "Params were not read" << std::endl;
            return false;
        }
    }else {
        g_tracer->print(WARNING) << "Config file not loaded" << std::endl;
        config.set(g_params, "Params");
        config.writeToFile(configFileName);
        return false;
    }

    return true;
}

bool initProgram()
{
    std::string initString = "";

    initString = g_params.videoStreamChannel.toInitString();
    if (!g_videoStreamChannel->init(initString)) {
        g_tracer->print(EXCEPTION) << "UDP channel not init" << std::endl;
        return false;
    }

    // Init video source.
    while (!g_videoSource->Open(g_params.videoSource.source))
    {
        g_tracer->print(EXCEPTION) << "Video source"
                                   << g_params.videoSource.source
                                   << " not open." << std::endl;
        return false;
    }
    g_tracer->print(DEBUG) << "Video source " << g_params.videoSource.source
                           << " opened successfully." << std::endl;

    if (g_params.videoSource.fourcc != "")
    {
        if(g_videoSource->SetProperty(
                    VideoSourceProperty::VIDEO_SOURCE_PROP_FOURCC, cv::VideoWriter::fourcc(
                        g_params.videoSource.fourcc[0], g_params.videoSource.fourcc[1],
                        g_params.videoSource.fourcc[2], g_params.videoSource.fourcc[3])))
        {
            g_tracer->print(DEBUG) << "CAP_PROP_FOURCC: "
                                   << g_params.videoSource.fourcc << std::endl;
        }else
        {
            int fourcc = (int)g_videoSource->GetProperty(
                        vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FOURCC);
            std::string fourcc_str = cv::format("%c%c%c%c", fourcc & 255, (fourcc >> 8) & 255, (fourcc >> 16) & 255, (fourcc >> 24) & 255);
            g_tracer->print(WARNING) << "CAP_PROP_FOURCC: "
                                     << g_params.videoSource.fourcc
                                     << " => " << fourcc_str << std::endl;
            g_params.videoSource.fourcc = fourcc;
        }
    }else
    {
        int fourcc = (int)g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FOURCC);
        std::string fourcc_str = cv::format("%c%c%c%c", fourcc & 255, (fourcc >> 8) & 255, (fourcc >> 16) & 255, (fourcc >> 24) & 255);
        g_tracer->print(DEBUG) << "CAP_PROP_FOURCC: " << fourcc_str << std::endl;
    }

    // Get video frame size.
    if (g_params.videoSource.frameWidth == 0 || g_params.videoSource.frameHeight == 0)
    {
        g_params.videoSource.frameWidth = (int32_t)g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FRAME_WIDTH);
        g_params.videoSource.frameHeight = (int32_t)g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FRAME_HEIGHT);
        g_tracer->print(DEBUG) << "FRAME_WIDTH: " << g_params.videoSource.frameWidth << std::endl;
        g_tracer->print(DEBUG) << "FRAME_HEIGHT: " << g_params.videoSource.frameHeight << std::endl;
    }else
    {
        if(g_videoSource->SetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FRAME_WIDTH, g_params.videoSource.frameWidth) &&
                g_videoSource->SetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FRAME_HEIGHT, g_params.videoSource.frameHeight))
        {
            g_tracer->print(DEBUG) << "FRAME_WIDTH: " << g_params.videoSource.frameWidth << std::endl;
            g_tracer->print(DEBUG) << "FRAME_HEIGHT: " << g_params.videoSource.frameHeight << std::endl;
        }else
        {
            int newFrameWidth = (int32_t)g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FRAME_WIDTH);
            g_tracer->print(WARNING) << "FRAME_WIDTH: " << g_params.videoSource.frameWidth
                                     << " => " << newFrameWidth << std::endl;
            g_params.videoSource.frameWidth = newFrameWidth;

            int newFrameHeight = (int32_t)g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FRAME_HEIGHT);
            g_tracer->print(WARNING) << "FRAME_HEIGHT: " << g_params.videoSource.frameHeight
                                     << " => " << newFrameHeight << std::endl;
            g_params.videoSource.frameHeight = newFrameHeight;
        }
    }

    if (g_params.videoSource.fps != 0)
    {
        if (g_videoSource->SetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FPS, g_params.videoSource.fps))
        {
            g_tracer->print(DEBUG) << "PROP_FPS: " << g_params.videoSource.fps << std::endl;
        }else
        {
            double newFps = g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FPS);
            g_tracer->print(WARNING) << "PROP_FPS: " << g_params.videoSource.fps
                                     << " => " << newFps << std::endl;
            g_params.videoSource.fps = newFps;
        }
    }
    else
    {
        g_params.videoSource.fps = (int32_t)g_videoSource->GetProperty(vsource::VideoSourceProperty::VIDEO_SOURCE_PROP_FPS);
        g_tracer->print(DEBUG) << "VIDEO_SOURCE_PROP_FPS: " << g_params.videoSource.fps << std::endl;
    }

    return true;

}

void videoStreamThreadFunction()
{
    // Init video protocol parser.
    vsource::VideoDataProtocolParser videoProtocolParser;

    g_videoCodec->setProperty("FPS", g_params.videoCodec.fps);
    g_videoCodec->setProperty("GOP_SIZE", g_params.videoCodec.gopSize);
    g_videoCodec->setProperty("BIT_RATE", g_params.videoCodec.bandwidthMbps * 1000.0);

    int frameWidth = g_params.videoSource.frameWidth;
    int frameHeight = g_params.videoSource.frameHeight;
    uint32_t fourcc = (uint32_t)vsource::ValidFourccCodes::NV12;

    // Init images.
    vsource::Frame inputFrame = vsource::Frame(frameWidth, frameHeight, fourcc);

    // Encoding result data (in h264 or h265 format)
    vsource::Frame outputFrame;
    if (g_params.videoCodec.fourcc == "H264")
        outputFrame.fourcc = (uint32_t)vsource::ValidFourccCodes::H264;
    else if(g_params.videoCodec.fourcc == "H265")
        outputFrame.fourcc = (uint32_t)vsource::ValidFourccCodes::H265;
    else if(g_params.videoCodec.fourcc == "JPEG")
        outputFrame.fourcc = (uint32_t)vsource::ValidFourccCodes::JPEG;
    else return;

    uint32_t outputDataBufferSize = frameWidth * frameHeight * 3;
    uint8_t* outputDataBuffer = new uint8_t[outputDataBufferSize];

    // Thread loop.
    INIT_TIME_MEASUREMENT(waitingTime);
    INIT_TIME_MEASUREMENT(transcodingTime);
    INIT_TIME_MEASUREMENT(sendingTime);
    INIT_TIME_MEASUREMENT(streamCycleTime);
    while (true)
    {
        // Wait new video frame data from main thread.
        if (!sharedFrameNv12Flag.load())
        {
            std::unique_lock<std::mutex> lk(sharedFrameNv12CondVarMutex);
            while (!sharedFrameNv12CondVarFlag.load())
            {
                if (std::cv_status::timeout ==
                        sharedFrameNv12CondVar.wait_for(
                            lk, milliseconds(g_params.videoSource.waitTimeoutMs))){
                    break;
                }
            }
            sharedFrameNv12CondVarFlag.store(false);
            lk.unlock();
        }

        // Check new data flag.
        if (!sharedFrameNv12Flag.load())
            continue;

        // Lock frame data and copy.
        sharedFrameNv12Mutex.lock();
        inputFrame = sharedFrameNv12;
        sharedFrameNv12Flag.store(false);
        sharedFrameNv12Mutex.unlock();
        GET_TIME_MEASUREMENT(waitingTime, milliseconds);


        START_TIME_MEASUREMENT(transcodingTime);
        // Encode video.
        if (!g_videoCodec->transcode(inputFrame, outputFrame))
            continue;
        outputFrame.frameID = inputFrame.frameID;
        GET_TIME_MEASUREMENT(transcodingTime, milliseconds);


        START_TIME_MEASUREMENT(sendingTime);
        // Put frame data to protocol.
        uint32_t outputDataSize = 0;
        if (!videoProtocolParser.encode(outputFrame, outputDataBuffer, outputDataBufferSize, outputDataSize))
            continue;

        // Send data. Logic port 0, number of repetition 2.
        bool isOk = g_videoStreamChannel->sendData(
                    outputDataBuffer, outputDataSize, 0,
                    g_params.videoStreamChannel.resendsCount,
                    g_params.videoStreamChannel.bandwidthMbps,
                    g_params.videoStreamChannel.waitTimeoutMs);
        GET_TIME_MEASUREMENT(sendingTime, milliseconds);


        // Wait according to stream FPS.
        GET_TIME_MEASUREMENT(streamCycleTime, milliseconds);
        std::this_thread::sleep_for(milliseconds((int)((1000.0 / g_params.videoCodec.fps) - streamCycleTime)));


        GET_TIME_MEASUREMENT(streamCycleTime, milliseconds);
        if (isOk)
        {
            telemetryMutex.lock();
            telemetryInfo[inputFrame.frameID]["Waiting"] = waitingTime;
            telemetryInfo[inputFrame.frameID]["Transcoding"] = transcodingTime;
            telemetryInfo[inputFrame.frameID]["Sending"] = sendingTime;
            telemetryInfo[inputFrame.frameID]["StreamCycle"] = streamCycleTime;
            telemetryMutex.unlock();
        }

        START_TIME_MEASUREMENT(streamCycleTime);
        START_TIME_MEASUREMENT(waitingTime);
    }

    // Free memory.
    delete[] outputDataBuffer;
}

void printStatisticThreadFunction()
{
    TraceColor mainCycle = GREEN;
    TraceColor streamCycle = GREEN;
    TraceColor frameCapture = GREEN;
    TraceColor frameShow = GREEN;
    TraceColor frameConvert = GREEN;
    TraceColor streamWait = GREEN;
    TraceColor frameTranscode = GREEN;
    TraceColor frameSend = GREEN;

    int _mainCycleTimeMs = 0;
    int _frameCaptureTimeMs = 0;
    int _frameConvertTimeMs = 0;
    int _frameShowTimeMs = 0;

    int _streamCycleTimeMs = 0;
    int _streamWaitFrameTimeMs = 0;
    int _frameTranscodeTimeMs = 0;
    int _frameSendTimeMs = 0;

    size_t frameCount = 10;

    // Thread loop.
    while (true)
    {
        if (telemetryInfo.size() <= frameCount) {
            continue;
        }

        auto it = telemetryInfo.begin();

        bool isStartFind = false;
        if (it->second.find("MainCycle") != it->second.end() ) {
            isStartFind = true;

            _mainCycleTimeMs = it->second["MainCycle"];
            _frameCaptureTimeMs = it->second["Capturing"];
            _frameConvertTimeMs = it->second["Converting"];
            _frameShowTimeMs = it->second["Showing"];

        }

        bool isEndFind = false;
        if (it->second.find("StreamCycle") != it->second.end() ) {
            isEndFind = true;

            _streamCycleTimeMs = it->second["StreamCycle"];
            _streamWaitFrameTimeMs = it->second["Waiting"];
            _frameTranscodeTimeMs = it->second["Transcoding"];
            _frameSendTimeMs = it->second["Sending"];
        }

        if (_mainCycleTimeMs <= ((1000.0 / g_params.videoSource.fps) * 1.10))
            mainCycle = GREEN;
        else if (_mainCycleTimeMs <= ((1000.0 / g_params.videoSource.fps) * 1.20))
            mainCycle = YELLOW;
        else if (_mainCycleTimeMs > ((1000.0 / g_params.videoSource.fps) * 1.20))
            mainCycle = RED;

        if (_frameCaptureTimeMs <= ((1000.0 / g_params.videoSource.fps)))
            frameCapture = GREEN;
        else if (_frameCaptureTimeMs <= ((1000.0 / g_params.videoSource.fps) * 1.10))
            frameCapture = YELLOW;
        else if (_frameCaptureTimeMs > ((1000.0 / g_params.videoSource.fps) * 1.10))
            frameCapture = RED;

        if (_frameConvertTimeMs <= 5.0)
            frameConvert = GREEN;
        else if (_frameConvertTimeMs <= 10.0)
            frameConvert = YELLOW;
        else if (_frameConvertTimeMs > 10.0)
            frameConvert = RED;

        if (_frameShowTimeMs <= 3.0)
            frameShow = GREEN;
        else if (_frameShowTimeMs <= 5.0)
            frameShow = YELLOW;
        else if (_frameShowTimeMs > 5.0)
            frameShow = RED;

        if (_streamCycleTimeMs <= ((1000.0 / g_params.videoCodec.fps) * 1.10))
            streamCycle = GREEN;
        else if (_streamCycleTimeMs <= ((1000.0 / g_params.videoCodec.fps) * 1.20))
            streamCycle = YELLOW;
        else if (_streamCycleTimeMs > ((1000.0 / g_params.videoCodec.fps) * 1.20))
            streamCycle = RED;

        if (_streamWaitFrameTimeMs <= ((1000.0 / g_params.videoCodec.fps)))
            streamWait = GREEN;
        else if (_streamWaitFrameTimeMs <= ((1000.0 / g_params.videoCodec.fps) * 1.10))
            streamWait = YELLOW;
        else if (_streamWaitFrameTimeMs > ((1000.0 / g_params.videoCodec.fps) * 1.10))
            streamWait = RED;

        if (_frameTranscodeTimeMs <= 5.0)
            frameTranscode = GREEN;
        else if (_frameTranscodeTimeMs <= 8.0)
            frameTranscode = YELLOW;
        else if (_frameTranscodeTimeMs > 8.0)
            frameTranscode = RED;

        if (_frameSendTimeMs <= ((1000.0 / g_params.videoCodec.fps)) * 0.5)
            frameSend = GREEN;
        else if (_frameSendTimeMs <= ((1000.0 / g_params.videoCodec.fps)) * 0.9)
            frameSend = YELLOW;
        else if (_frameSendTimeMs > ((1000.0 / g_params.videoCodec.fps)) * 0.9)
            frameSend = RED;

        if (isStartFind && isEndFind)
        {
            g_tracer->print(WHITE, "FrameId") << it->first << ": ";
            g_tracer->print(mainCycle, "MainCycle") << "" << _mainCycleTimeMs << " ms = ";
            g_tracer->print(frameCapture, "Capturing") << "" << _frameCaptureTimeMs << " ms + ";
            g_tracer->print(frameConvert, "Converting") << "" << _frameConvertTimeMs << " ms + ";

            g_tracer->print(frameShow, "Showing") << "" << _frameShowTimeMs << " ms \t";
            g_tracer->print(streamCycle, "StreamCycle") << "" << _streamCycleTimeMs << " ms = ";
            g_tracer->print(streamWait, "Waiting") << "" << _streamWaitFrameTimeMs << " ms + ";
            g_tracer->print(frameTranscode, "Transcoding") << "" << _frameTranscodeTimeMs << " ms + ";
            g_tracer->print(frameSend, "Sending") << "" << _frameSendTimeMs << " ms " << std::endl;
            telemetryMutex.lock();
            telemetryInfo.erase(it);
            telemetryMutex.unlock();
        }else if (isStartFind && telemetryInfo.size() > frameCount)
        {
            g_tracer->print(WHITE, "FrameId") << it->first << ": ";
            g_tracer->print(mainCycle, "MainCycle") << "" << _mainCycleTimeMs << " ms = ";
            g_tracer->print(frameCapture, "Capturing") << "" << _frameCaptureTimeMs << " ms + ";
            g_tracer->print(frameConvert, "Converting") << "" << _frameConvertTimeMs << " ms + ";

            g_tracer->print(frameShow, "Showing") << "" << _frameShowTimeMs << " ms " << std::endl;
            telemetryMutex.lock();
            telemetryInfo.erase(it);
            telemetryMutex.unlock();
        }else if (!isStartFind && isEndFind)
        {
            telemetryMutex.lock();
            telemetryInfo.erase(it);
            telemetryMutex.unlock();
        }
    }
}

void drawStrOnFrame(cv::Mat& Frame, std::string str)
{
    cv::rectangle(Frame, cv::Rect(0,0,150,30), cv::Scalar(0,0,0), cv::FILLED);
    cv::putText(Frame, str, cv::Point(5, 20),
                cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(255, 255, 255), 2);
}


