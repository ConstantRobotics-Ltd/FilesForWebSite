#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <Windows.h>
#include <shobjidl.h>
#include <string>
#include <cstring>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <opencv2/opencv.hpp>


#include "MotionMagnificator.h"


// Global vars.
int g_frameWidth = 0;                                   /// Video frames width.
int g_frameHeight = 0;                                  /// Video frames height.
cv::VideoCapture g_videoSource;							/// Video source object.
cv::VideoWriter* g_sourceVideoWriter = nullptr;         /// Video writer for source video.
cv::VideoWriter* g_resultVideoWriter = nullptr;         /// Video writer for result video.
cv::VideoWriter* g_combinedVideoWriter = nullptr;       /// Video writer for result video.
cr::mmag::MotionMagnificator g_motionMagnificator;      /// Motion magnificator.


/**
@brief Prototype of function to process keyboard events.
*/
void KeyboardEventsFunction(int key);
/**
@brief Prototype of function to open video file.
*/
bool OpenVideoFileDialog();
/**
@brief Prototype of function to get current date and time string.
*/
std::string getDayTimeString();



// Entry point.
int main(void)
{
	// Dialog to enter camera num.
    int camera_num = -1;
	std::cout << "Enter camera num for live video or -1 for file dialog: ";
    std::cin >> camera_num;
	std::cout << std::endl;

	// Check camera num.
	double fps = 0.0;
    if (camera_num >= 0)
	{
		// Open camera.
        if (!g_videoSource.open(camera_num))
		{
            std::cout << "Camera " << camera_num << " not open. Exit..." << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(2));
			return -1;
		}
	}
	else
	{
		// Open video file.
		if (!OpenVideoFileDialog())
		{
			std::cout << "File not open. Exit..." << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(2));
			return -1;
		}
		// Get video fps.
        fps = g_videoSource.get(cv::CAP_PROP_FPS);
		if (fps < 1.0 || fps > 60.0)
			fps = 30.0;
	}

	// Get frames size.
    g_frameWidth = (int)g_videoSource.get(cv::CAP_PROP_FRAME_WIDTH);
    g_frameHeight = (int)g_videoSource.get(cv::CAP_PROP_FRAME_HEIGHT);

	// Create images.
    cv::Mat BGR_frame;

    // Init variables.
    cv::Mat resultFrame;

	// Create windows.
    cv::namedWindow("SOURCE VIDEO", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("SOURCE VIDEO", 5, 5);

    // Set initial parameters.
    g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS, 8);

	// Main loop.
	std::chrono::time_point<std::chrono::system_clock> startTime = std::chrono::system_clock::now();
	while (true)
	{
		// Capture next frame.
        g_videoSource >> BGR_frame;
        if (BGR_frame.empty())
		{
            g_videoSource.set(cv::CAP_PROP_POS_FRAMES, 1);
			continue;
		}

        // Motion magnification.
        std::chrono::time_point<std::chrono::system_clock> motionStartTime = std::chrono::system_clock::now();
        g_motionMagnificator.processFrame(BGR_frame, resultFrame);
        int32_t motionProcessingTime = (int32_t)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now() - motionStartTime).count();


        // Make combined video.
        cv::Mat combinedFrame;
        cv::hconcat(BGR_frame, resultFrame, combinedFrame);
		// Record video
        if (g_sourceVideoWriter != nullptr)
        {
            g_sourceVideoWriter->write(BGR_frame);
            g_resultVideoWriter->write(resultFrame);
            g_combinedVideoWriter->write(combinedFrame);
            cv::circle(BGR_frame, cv::Point(g_frameWidth - 15, 15), 10, cv::Scalar(0, 0, 255), cv::FILLED);
            cv::circle(resultFrame, cv::Point(g_frameWidth - 15, 15), 10, cv::Scalar(0, 0, 255), cv::FILLED);
        }

        // Draw processing time.
        cv::putText(BGR_frame,
                    "Processing time " + std::to_string(motionProcessingTime) + " ms",
                    cv::Point(5, 15),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(0, 0, 255));
        cv::putText(resultFrame,
                    "Processing time " + std::to_string(motionProcessingTime) + " ms",
                    cv::Point(5, 15),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(0, 0, 255));
        cv::putText(combinedFrame,
                    "Processing time " + std::to_string(motionProcessingTime) + " ms",
                    cv::Point(5, 15),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(0, 0, 255));

        // Draw parameters.
        cv::rectangle(BGR_frame, cv::Rect(0, g_frameHeight - 100, 400, 120), cv::Scalar(0, 0, 0), cv::FILLED);
        cv::putText(BGR_frame,
                    "[+Q  -A  ] CUTOFF_FREQ_LOW " + std::to_string(g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_LOW)) + " Hz",
                    cv::Point(5, g_frameHeight - 5),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(255, 255, 255));
        cv::putText(BGR_frame,
                    "[+W  -S  ] CUTOFF_FREQ_HIGH " + std::to_string(g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_HIGH)) + " Hz",
                    cv::Point(5, g_frameHeight - 25),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(255, 255, 255));
        cv::putText(BGR_frame,
                    "[+E  -D  ] CHROM_ATTENUATION " + std::to_string(g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CHROM_ATTENUATION)),
                    cv::Point(5, g_frameHeight - 45),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(255, 255, 255));
        cv::putText(BGR_frame,
                    "[+R  -F  ] ALPHA " + std::to_string(g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::ALPHA)),
                    cv::Point(5, g_frameHeight - 65),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(255, 255, 255));
        cv::putText(BGR_frame,
                    "[+Y  -H  ] LAP_PYRAMIDS_LEVELS " + std::to_string(g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS)),
                    cv::Point(5, g_frameHeight - 85),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(255, 255, 255));


		// Show images.
        cv::imshow("SOURCE VIDEO", BGR_frame);
        cv::imshow("RESULT VIDEO", resultFrame);

		// Process keyboard events.
		KeyboardEventsFunction(cv::waitKey(1));

		// Wait for video.
		if (fps > 0.0)
		{
			int32_t processingTime = (int32_t)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now() - startTime).count();
			int32_t waitTime = (int32_t)(1000.0 / fps) - processingTime;
			if (waitTime > 0)
				std::this_thread::sleep_for(std::chrono::milliseconds(waitTime));
		}
		startTime = std::chrono::system_clock::now();
	}

	return 1;
}



void KeyboardEventsFunction(int key)
{
	// Check returned value from cv::waitKey(...) function.
	switch (key) {

	case 27:// ESC - EXIT.
		std::cout << "EXIT" << std::endl;
        if (g_sourceVideoWriter != nullptr)
            g_sourceVideoWriter->release();
        if (g_resultVideoWriter != nullptr)
            g_resultVideoWriter->release();
        if (g_combinedVideoWriter != nullptr)
            g_combinedVideoWriter->release();
		exit(0);

    case 113:// Q - Cutoff frequency low +.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_LOW,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_LOW) + 0.05);
		break;

    case 97:// A - Cutoff frequency low -.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_LOW,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_LOW) - 0.05);
        break;

    case 119:// W - Cutoff frequency hight +.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_HIGH,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_HIGH) + 0.05);
        break;

    case 115:// S - Cutoff frequency hught -.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_HIGH,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CUTOFF_FREQ_HIGH) - 0.05);
        break;

    case 101:// E - Chrom attenuation +.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::CHROM_ATTENUATION,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CHROM_ATTENUATION) + 0.1);
        break;

    case 100:// D - Chrom attenuation -.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::CHROM_ATTENUATION,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::CHROM_ATTENUATION) - 0.1);
        break;

    case 114:// R - Alpha +.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::ALPHA,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::ALPHA) + 1);
        break;

    case 102:// F - Alpha -.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::ALPHA,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::ALPHA) - 1);
        break;

    case 121:// T - Analisis level +.
        if (g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS) < 8)
            g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS,
                                        g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS) + 1);
        break;

    case 104:// G - Analisis level -.
        g_motionMagnificator.setProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS,
                                       g_motionMagnificator.getProperty(cr::mmag::MotionMagnificatorProperty::LAP_PYRAMIDS_LEVELS) - 1);
        break;

    case 32:// SPACE - Start/stop video recording.
        if (g_sourceVideoWriter != nullptr) {
            g_sourceVideoWriter->release();
            g_sourceVideoWriter = nullptr;
		}
		else {
            std::string videoFileName = "source_" + getDayTimeString() + ".avi";
            g_sourceVideoWriter = new cv::VideoWriter(videoFileName, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'),
                                               30, cv::Size(g_frameWidth, g_frameHeight), true);
            assert(source_video_writer != 0);
		}//if...
        if (g_resultVideoWriter != nullptr) {
            g_resultVideoWriter->release();
            g_resultVideoWriter = nullptr;
        }
        else {
            std::string videoFileName = "result_" + getDayTimeString() + ".avi";
            g_resultVideoWriter = new cv::VideoWriter(videoFileName, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'),
                                               30, cv::Size(g_frameWidth, g_frameHeight), true);
            assert(result_video_writer != 0);
        }//if...
        if (g_combinedVideoWriter != nullptr) {
            g_combinedVideoWriter->release();
            g_combinedVideoWriter = nullptr;
        }
        else {
            std::string videoFileName = "combined_" + getDayTimeString() + ".avi";
            g_combinedVideoWriter = new cv::VideoWriter(videoFileName, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'),
                                               30, cv::Size(g_frameWidth * 2, g_frameHeight), true);
            assert(combined_video_writer != 0);
        }//if...
		break;

	default:
		return;
	}
}


// Function to open video file.
bool OpenVideoFileDialog() {

	IFileOpenDialog* pFileOpen = nullptr;
	HRESULT hr;
	PWSTR file;
	char* filename;

	hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
	if (SUCCEEDED(hr))
	{
		hr = CoCreateInstance(CLSID_FileOpenDialog,
			NULL, CLSCTX_ALL,
			IID_IFileOpenDialog,
			reinterpret_cast<void**>(&pFileOpen));
		if (SUCCEEDED(hr))
		{
			pFileOpen->SetTitle(L"OPEN VIDEO FILE");
			hr = pFileOpen->Show(NULL);
			if (SUCCEEDED(hr))
			{
				IShellItem* pItem;
				hr = pFileOpen->GetResult(&pItem);
				if (SUCCEEDED(hr))
				{
					hr = pItem->GetDisplayName(SIGDN_FILESYSPATH, &file);
					if (SUCCEEDED(hr))
					{
						pItem->Release();
						int count = WideCharToMultiByte(CP_ACP, 0, file, static_cast<int>(wcslen(file)), 0, 0, NULL, NULL);
						filename = new char[(size_t)count + 1];
						WideCharToMultiByte(CP_ACP, 0, file, count, filename, count + 1, NULL, NULL);
						filename[static_cast<size_t>(count)] = '\0';
						std::cout << filename << std::endl;
                        g_videoSource.open(filename);
                        if (!g_videoSource.isOpened())
							return false;
						return true;
					}
				}
				pItem->Release();
			}
		}
	}
	pFileOpen->Release();
	return false;

}


// Function to get current time string
std::string getDayTimeString()
{
	time_t rawtime;
	struct tm timeinfo;
	char buffer[80];

	time(&rawtime);
	localtime_s(&timeinfo, &rawtime);

	strftime(buffer, sizeof(buffer), "%d_%m_%Y_%H_%M_%S", &timeinfo);
	std::string str(buffer);

	return str;
}

