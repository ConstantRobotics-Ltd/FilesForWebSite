#include <iostream>
#include <chrono>
#include <opencv2/opencv.hpp>

#include "VSourceOpenCv.h"
#include "SimpleFileDialog.h"
#include "Gmd.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace cr::detector;
using namespace std::chrono;



// Global variables for video mask.
std::atomic<int> roiX0;
std::atomic<int> roiY0;
std::atomic<int> roiX1;
std::atomic<int> roiY1;
bool drawRoi = false;
int g_maskWidth = 0;
int g_maskHeight = 0;



// Mouse callback function that enables applying detection mask to event detector.
void applyDetectionMask(int event, int x, int y, int flags, void* userdata)
{
    auto detector = reinterpret_cast<Gmd*>(userdata);

    switch (event)
    {
    case EVENT_LBUTTONDOWN:
    {
        drawRoi = true;
        if (x < g_maskWidth)
        {
            roiX0.store(x);
        }
        else
        {
            roiX0.store(g_maskWidth - 1);
        }
        if (y < g_maskHeight)
        {
            roiY0.store(y);
        }
        else
        {
            roiY0.store(g_maskHeight - 1);
        }
        roiX1.store(roiX0.load());
        roiY1.store(roiY0.load());
        break;
    }
    case EVENT_RBUTTONDOWN: break;
    case EVENT_LBUTTONUP:
    {
        drawRoi = false;
        if (x < g_maskWidth)
        {
            roiX1.store(x);
        }
        else
        {
            roiX1.store(g_maskWidth - 1);
        }
        if (y < g_maskHeight)
        {
            roiY1.store(y);
        }
        else
        {
            roiY1.store(g_maskHeight - 1);
        }
        if (roiX1.load() > roiX0.load() && roiY1.load() > roiY0.load())
        {
            auto mask = Mat(Size(g_maskWidth,
                g_maskHeight), CV_8UC1, Scalar(0, 0, 0));
            rectangle(mask, Rect(roiX0, roiY0, roiX1 - roiX0 + 1,
                roiY1 - roiY0 + 1), Scalar(255, 255, 255), FILLED);
            auto maskFrame = Frame(mask.cols, mask.rows,
                Fourcc::GRAY, static_cast<size_t>(g_maskWidth
                    * g_maskHeight), mask.data);

            detector->setMask(maskFrame);
        }
        break;
    }
    case EVENT_MBUTTONDOWN:	break;
    case EVENT_MOUSEMOVE:
    {
        if (drawRoi)
        {
            if (x > roiX0.load() && y > roiY0.load())
            {
                if (x < g_maskWidth)
                    roiX1.store(x);
                else
                    roiX1.store(g_maskWidth - 1);
                if (y < g_maskHeight)
                    roiY1.store(y);
                else
                    roiY1.store(g_maskHeight - 1);
            }
        }
        break;
    }
    }
}



/// Params class.
class Params
{
public:
    /// Video source params.
    VSourceParams videoSource;
    /// Object detector params.
    ObjectDetectorParams objectDetector;

    JSON_READABLE(Params, videoSource, objectDetector)
};



int main(void)
{
    cout << "##########################################" << endl;
    cout << "#                                        #" << endl;
    cout << "#           Gmd v" << Gmd::getVersion() <<
            " demo app          #"<<endl;
    cout << "#                                        #" << endl;
    cout << "##########################################" << endl;
    cout << endl;

    // Init object detector.
    Gmd* gaussianMotionDetector = new Gmd();
    // Init video source.
    VSource* source = new VSourceOpenCv();
    // Init application params.
    Params params;

    // Load params.
    ConfigReader config = ConfigReader();
    const std::string configFileName = "GmdDemo.json";

    // Open config JSON file (if not exist - create new and exit).
    if(!config.readFromFile(configFileName))
    {
        cout << "ERROR: Can't open config file" << endl;
        // Get default params from video source.
        params.videoSource = source->getParams();
        // Set default file dialog.
        params.videoSource.source = "file dialog";
        // Get default params from gaussian motion detector.
        params.objectDetector = gaussianMotionDetector->getParams();
        // Put params to config reader.
        config.set(params, "Params");
        // Save params to file.
        config.writeToFile(configFileName);
        return -1;
    }

    // Read application params.
    if(!config.get(params, "Params"))
    {
        cout << "ERROR: Can't read params from file" << endl;
        // Get default params from video source.
        params.videoSource = source->getParams();
        // Set default file dialog.
        params.videoSource.source = "file dialog";
        // Get default params from video gaussian motion detector.
        params.objectDetector = gaussianMotionDetector->getParams();
        // Put params to config reader.
        config.set(params, "Params");
        // Save params to file.
        config.writeToFile(configFileName);
        return -1;
    }

    // Open file dialog.
    if (params.videoSource.source == "file dialog" ||
        params.videoSource.source == "dialog")
        params.videoSource.source = SimpleFileDialog::dialog();

    // Init video source.
    if (!source->initVSource(params.videoSource))
    {
        cout << "ERROR: Can't init video source" << endl;
        return -1;
    }

    // Init motion detector.
    if (!gaussianMotionDetector->initObjectDetector(params.objectDetector))
    {
        cout << "ERROR: Can't init gaussian motion detector!" << endl;
        return -1;
    }

    // Init frames.
    Frame srcFrame;
    Frame maskFrame;
    Mat srcImg;
    Mat dstImg;
    Mat maskImg;
    Mat maskImgGray;
    Mat mixImg;
    Mat displayImg;

    // Initial processing time, mks.
    float timeMsec = 5.0f;

    // Video writer for result video.
    VideoWriter* resultWriter = nullptr;
    // Video writer for result video.
    VideoWriter* maskWriter = nullptr;
    // Video writer for mix video.
    VideoWriter* mixWriter = nullptr;

    // Initialize window and mouse callback to enable applying detection mask.
    auto windowName = "Gmd v" + Gmd::getVersion();
    namedWindow(windowName);
    setMouseCallback(windowName, applyDetectionMask, gaussianMotionDetector);
    // Main loop.
    while (true)
    {
        // Capture next frame.
        if (!source->getFrame(srcFrame, 1000))
        {
            cout << "No input frame" << endl;
            gaussianMotionDetector->executeCommand(ObjectDetectorCommand::RESET);
            continue;
        }
        
        // Run gauss object detection.
        time_point<system_clock> startTime = system_clock::now();
        vector<Object> detectedObjects;
        if (gaussianMotionDetector->detect(srcFrame))
        {
            // Get detected objects.
            detectedObjects = gaussianMotionDetector->getObjects();
        }
        timeMsec = 0.9f * timeMsec
                         + 0.1f * static_cast<float>(duration_cast<
                         std::chrono::milliseconds>(system_clock::now() 
                         - startTime).count());
        // Init images.
        if (dstImg.empty())
        {
            dstImg = Mat(srcFrame.height, srcFrame.width, CV_8UC3, srcFrame.data);
            maskImgGray = Mat::zeros(srcFrame.height, srcFrame.width, CV_8UC1);
            mixImg = Mat::zeros(srcFrame.height * 2, srcFrame.width, CV_8UC3);
        }

        // Draw detected objects.
        for (int n = 0; n < detectedObjects.size(); ++n)
        {
            rectangle(dstImg, Rect(detectedObjects[n].x, detectedObjects[n].y,
                detectedObjects[n].width, detectedObjects[n].height),
                Scalar(0, 0, 255), 1);
            putText(dstImg, to_string(detectedObjects[n].id), 
                Point(detectedObjects[n].x, detectedObjects[n].y),
                1, 1, Scalar(0, 0, 255));
        }

        // Get motion mask.
        gaussianMotionDetector->getMotionMask(maskFrame);
        std::memcpy(maskImgGray.data, maskFrame.data, maskFrame.size);

        // Create mix image.
        cvtColor(maskImgGray, maskImg, COLOR_GRAY2BGR);
        vconcat(dstImg, maskImg, mixImg);
        // Resize mix video if necessary to fit display.
        if (mixImg.size().height > 960)
        {
            int dstHeight = 960;
            int dstWidth = (int)((float)mixImg.size().width * (float)dstHeight /
                (float)mixImg.size().height);
            resize(mixImg, displayImg, Size(dstWidth, dstHeight));
        }
        else
        {
            mixImg.copyTo(displayImg);
        }
        g_maskHeight = displayImg.rows / 2;
        g_maskWidth = displayImg.cols;
        // Record video.
        if (resultWriter != nullptr)
        {
            // Record videos.
            resultWriter->write(dstImg);
            maskWriter->write(maskImg);
            mixWriter->write(mixImg);

            // Show "RECORDING" message.
            putText(displayImg, "RECORDING: R to stop", cv::Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, "RECORDING: R to stop", cv::Point(6, 21),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(displayImg, "R to start recording", cv::Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, "R to start recording", cv::Point(6, 21),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }

        string str = "Processing time: " + to_string((int)timeMsec) + " msec";
        putText(displayImg, str, cv::Point(5, 40), FONT_HERSHEY_SIMPLEX, 0.6,
                    Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 41), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "SPACE to reset detector";
        putText(displayImg, str, cv::Point(5, 60), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                    cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 61), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        // Display parameters that can be changed by user.
        str = "S - ^, s - v | sensitivity - "
            + std::to_string(static_cast<int>(gaussianMotionDetector->
                getParam(ObjectDetectorParam::SENSITIVITY)));
        putText(displayImg, str, cv::Point(5, 80), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 81), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "C - ^, c - v | reset criteria - "
            + std::to_string(static_cast<int>(gaussianMotionDetector->
                getParam(ObjectDetectorParam::RESET_CRITERIA)));
        putText(displayImg, str, cv::Point(5, 100), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 101), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "D - ^, d - v | x,y detection criteria - "
            + std::to_string(static_cast<int>(gaussianMotionDetector->
                getParam(ObjectDetectorParam::X_DETECTION_CRITERIA)));
        putText(displayImg, str, cv::Point(5, 120), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 121), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "M - ^, m - v | max object width and height - "
            + std::to_string(static_cast<int>(gaussianMotionDetector->
                getParam(ObjectDetectorParam::MAX_OBJECT_WIDTH)));
        putText(displayImg, str, cv::Point(5, 140), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 141), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "W - ^, w - v | min object width and height - "
            + std::to_string(static_cast<int>(gaussianMotionDetector->
                getParam(ObjectDetectorParam::MIN_OBJECT_WIDTH)));
        putText(displayImg, str, cv::Point(5, 160), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(displayImg, str, cv::Point(6, 161), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "MOTION MASK";
        putText(displayImg, str, Point(5, displayImg.size().height - 10),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, displayImg.size().height - 9),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        // Draw ROI.
        rectangle(displayImg, Rect(roiX0, roiY0, roiX1 - roiX0 + 1, roiY1 - roiY0 + 1), Scalar(255, 255, 0), 1);

        // Show results.
        imshow(windowName, displayImg);

        // Process keyboard events.
        switch (waitKey(1))
        {
        // ESC - exit.
        case 27:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                mixWriter->release();
                maskWriter->release();
            }
            exit(0);
        }
        // SPACE - reset object detector.
        case 32:
        {
            gaussianMotionDetector->executeCommand(ObjectDetectorCommand::RESET);
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                resultWriter = nullptr;
                mixWriter->release();
                mixWriter = nullptr;
                maskWriter->release();
                maskWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                resultWriter = new VideoWriter(videoFileName,
                VideoWriter::fourcc('M','J','P','G'), 30, dstImg.size(), true);
                assert(resultWriter != 0);
                videoFileName = "mix_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                mixWriter = new VideoWriter(videoFileName,
                    VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, mixImg.size(), true);
                assert(mixWriter != 0);
                videoFileName = "mask_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                maskWriter = new VideoWriter(videoFileName,
                    VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, maskImg.size(), true);
                assert(mixWriter != 0);
            }
            break;
        }
        case 115:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::SENSITIVITY);
            param -= 5.0f;
            if (param < 5.0f)
                param = 5.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::SENSITIVITY, param);
        }
        break;
        case 83:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::SENSITIVITY);
            param += 5.0f;
            if (param > 255.0f)
                param = 255.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::SENSITIVITY, param);
        }
        break;
        case 100:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::X_DETECTION_CRITERIA);
            param -= 1.0f;
            if (param < 1.0f)
                param = 1.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::X_DETECTION_CRITERIA, param);
            gaussianMotionDetector->setParam(ObjectDetectorParam::Y_DETECTION_CRITERIA, param);
        }
        break;
        case 68:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::X_DETECTION_CRITERIA);
            param += 1.0f;
            if (param > 255.0f)
                param = 255.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::X_DETECTION_CRITERIA, param);
            gaussianMotionDetector->setParam(ObjectDetectorParam::Y_DETECTION_CRITERIA, param);
        }
        break;
        case 99:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::RESET_CRITERIA);
            param -= 1.0f;
            if (param < 1.0f)
                param = 1.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::RESET_CRITERIA, param);
        }
        break;
        case 67:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::RESET_CRITERIA);
            param += 1.0f;
            if (param > 50.0f)
                param = 50.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::RESET_CRITERIA, param);
        }
        break;
        case 109:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::MAX_OBJECT_WIDTH);
            param -= 2.0f;
            if (param < 1.0f)
                param = 1.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH, param);
            gaussianMotionDetector->setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT, param);
        }
        break;
        case 77:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::MAX_OBJECT_WIDTH);
            param += 2.0f;
            if (param > srcFrame.width)
                param = static_cast<float>(srcFrame.width);
            gaussianMotionDetector->setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH, param);
            gaussianMotionDetector->setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT, param);
        }
        break;
        case 119:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::MIN_OBJECT_WIDTH);
            param -= 1.0f;
            if (param < 1.0f)
                param = 1.0f;
            gaussianMotionDetector->setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH, param);
            gaussianMotionDetector->setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT, param);
        }
        break;
        case 87:
        {
            auto param = gaussianMotionDetector->getParam(ObjectDetectorParam::MIN_OBJECT_WIDTH);
            param += 1.0f;
            if (param >  srcFrame.width)
                param = static_cast<float>(srcFrame.width);
            gaussianMotionDetector->setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH, param);
            gaussianMotionDetector->setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT, param);        }
        break;
        }
    }

    return 1;
}
