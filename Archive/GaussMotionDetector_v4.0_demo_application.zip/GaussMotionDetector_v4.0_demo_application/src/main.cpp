/*
Gauss Motion Detector Demo Application v4.0
*/
#include <iostream>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <chrono>
#include <cstdlib>
#include <thread>
#include <fstream>
#include <Windows.h>
#include <shobjidl.h>
#include <mutex>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <opencv2/opencv.hpp>
#include <GaussMotionDetector.h>
#include "json.hpp"
using json = nlohmann::json;


// Common global variables.
int32_t frame_width = 0;                                    // Input frame width.
int32_t frame_height = 0;                                   // Input frame height.
std::string configuration_file_name = "Config_Params.json"; // File name for application params.
std::thread joystic_events_read_thread;                     // Thread for joystick.
cv::VideoCapture video_source;                              // Video capture object.
std::string video_source_init_string = "";                  // Init string of video source.
mdetector::GaussMotionDetector motion_detector;             // Motion detector object.


/**
 * @brief Function to load configuration params.
 * @return TRUE if params are loaded.
 */
bool Load_Configuration_Params();

/**
 * @brief Draw_Info_Function
 * @param frame Reference for video frame to draw info.
 */
void Draw_Info_Function(cv::Mat& frame);

/**
 * @brief Function to open video file.
 * @return TRUE if file open or FALSE.
 */
bool OpenVideoFileDialog();

/**
@brief Prototype of function to get current date and time string.
*/
std::string getDayTimeString();



// Entry point.
int main(void)
{
    std::cout << "###################################################" << std::endl;
    std::cout << "#                                                 #" << std::endl;
    std::cout << "#   Gauss Motion Detector Demo Application v4.0   #" << std::endl;
    std::cout << "#                                                 #" << std::endl;
    std::cout << "###################################################" << std::endl << std::endl;

    // Load conviguration params.
    if (!Load_Configuration_Params())
    {
        std::cout << "Configuration params not read" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(1));
        return -1;
    }

    // Check video source init string.
    double fps = 0.0;
    if (video_source_init_string.length() < 5)
    {
        if (!video_source.open(std::stoi(video_source_init_string)))
        {
            std::cout << "Camera not open" << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));
            return -1;
        }
    }
    else
    {
        if (video_source_init_string == "open file dialog")
        {
            if (!OpenVideoFileDialog())
            {
                std::cout << "Video file not open" << std::endl;
                std::this_thread::sleep_for(std::chrono::seconds(1));
                return -1;
            }
            // Get video FPS.
            fps = video_source.get(cv::CAP_PROP_FPS);
            if (fps <= 1.0 || fps >= 60.0)
                fps = 30.0;
        }
        else
        {
            if (!video_source.open(video_source_init_string))
            {
                std::cout << "Video file not open" << std::endl;
                std::this_thread::sleep_for(std::chrono::seconds(1));
                return -1;
            }
            // Get video FPS.
            fps = video_source.get(cv::CAP_PROP_FPS);
            if (fps <= 1.0 || fps >= 60.0)
                fps = 30.0;
        }
    }

    // Set frame size variables.
    frame_width = (int32_t)video_source.get(cv::CAP_PROP_FRAME_WIDTH);
    frame_height = (int32_t)video_source.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Create windows.
    cv::namedWindow("INPUT VIDEO", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("INPUT VIDEO", 5, 5);
    cv::namedWindow("MOTION MASK", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("MOTION MASK", frame_width + 10, 5);

    // Init images.
    cv::Mat input_bgr_frame = cv::Mat(cv::Size(frame_width, frame_height), CV_8UC3);
    cv::Mat input_gray_frame = cv::Mat(cv::Size(frame_width, frame_height), CV_8UC1);
    cv::Mat motion_mask = cv::Mat(cv::Size(frame_width, frame_height), CV_8UC1);

    // Variables for video writer.
    cv::VideoWriter* video_writer = nullptr;


    // Main loop.
    std::chrono::time_point<std::chrono::system_clock> start_time = std::chrono::system_clock::now();
    while (true)
    {
        // Wait new video frame.
        video_source >> input_bgr_frame;
        if (input_bgr_frame.empty())
        {
            // Set initial frame position if it is video file.
            if (video_source_init_string.length() >= 5)
                video_source.set(cv::CAP_PROP_POS_FRAMES, 1);
            continue;
        }


        std::chrono::time_point<std::chrono::system_clock> start_processing_time = std::chrono::system_clock::now();
        // Convert to grayscale.
        cv::cvtColor(input_bgr_frame, input_gray_frame, cv::COLOR_BGR2GRAY);

        // Process frame.
        motion_detector.Process_Frame(input_gray_frame.data, frame_width, frame_height);

        int processing_time_ms = (int)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now() - start_processing_time).count();

        // Get mption mask.
        motion_detector.Get_Motion_Mask_Image(motion_mask.data);

        // Get tracks.
        std::vector<mdetector::GaussMotionDetectorTrack> tracks = motion_detector.Get_Tracks();

        // Draw tracks.
        for (int i = 0; i < (int)tracks.size(); ++i)
        {
            // Draw rectangle.
            cv::rectangle(input_bgr_frame, cv::Rect(tracks[i].object.x0, tracks[i].object.y0,
            tracks[i].object.x1 - tracks[i].object.x0 + 1,
            tracks[i].object.y1 - tracks[i].object.y0 + 1), cv::Scalar(0, 0, 255));
            // Draw ID.
            cv::putText(
                        input_bgr_frame,
                        std::to_string(tracks[i].track_ID),
                        cv::Point(tracks[i].object.x0, tracks[i].object.y0 - 5),
                        cv::FONT_HERSHEY_SIMPLEX,
                        0.5,
                        cv::Scalar(255, 255, 0));
        }

        // Draw processing time.
        cv::putText(input_bgr_frame,
                    "Processing time " + std::to_string(processing_time_ms) + " ms",
                    cv::Point(frame_width - 200, 15),
                    cv::FONT_HERSHEY_SIMPLEX,
                    0.5,
                    cv::Scalar(0, 0, 255));

        // Write video.
        if (video_writer != nullptr)
        {
            video_writer->write(input_bgr_frame);
            cv::putText(input_bgr_frame,
                        "RECORDING",
                        cv::Point(5, 15),
                        cv::FONT_HERSHEY_SIMPLEX,
                        0.5,
                        cv::Scalar(0, 0, 255));
        }

        // Show video.
        cv::imshow("INPUT VIDEO", input_bgr_frame);
        cv::imshow("MOTION MASK", motion_mask);

        // Keyboard ivent processing.
        switch (cv::waitKey(1))
        {
        case 27: // ESC - Exit
            cv::destroyAllWindows();
            // Close video writer.
            if (video_writer != nullptr)
                video_writer->release();
            return -1;
        
        case 32: // SPACE - Reset
            motion_detector.Reset();
            break;

        case 114:// R - Start/stop video recording.
            if (video_writer != nullptr) {
                video_writer->release();
                video_writer = nullptr;
            }
            else {
                std::string videoFileName = "record_" + getDayTimeString() + ".avi";
                video_writer = new cv::VideoWriter(videoFileName, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, cv::Size(frame_width, frame_height), true);
                assert(video_writer != 0);
            }//if...
            break;

        default:
            break;
        }

        // Wait according to FPS if it video file.
        double cycle_time_mks = 1000000.0 / fps;
        if (video_source_init_string.length() >= 5)
        {
            while ((int32_t)std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start_time).count() < cycle_time_mks)
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
        }
        start_time = std::chrono::system_clock::now();

    }

    return 1;
}


// Function to load configuration params.
bool Load_Configuration_Params()
{
    json jsonConf;

    // Open JSON file.
    std::ifstream in(configuration_file_name);
    if (!in.is_open())
        return false;

    // Parse JSON.
    try {
        jsonConf = json::parse(in);
    }
    catch (json::parse_error& e)
    {
        return false;
    }

    // Read and set params params.
    try
    {
        json channelJson = jsonConf.at("Config_Params");
        
        // Read video source init string.
        video_source_init_string = channelJson.at("video_source_init_string").get<std::string>();

        // Read motion detecto params.
        double pixel_deviation = channelJson.at("pixel_deviation").get<double>();
        double alpha_coeff = channelJson.at("alpha_coeff").get<double>();
        int32_t max_object_width = channelJson.at("max_object_width").get<int32_t>();
        int32_t min_object_width = channelJson.at("min_object_width").get<int32_t>();
        int32_t max_object_height = channelJson.at("max_object_height").get<int32_t>();
        int32_t min_object_height = channelJson.at("min_object_height").get<int32_t>();
        double min_object_velocity = channelJson.at("min_object_velocity").get<double>();
        double max_object_velocity = channelJson.at("max_object_velocity").get<double>();
        int32_t num_threads = channelJson.at("num_threads").get<int32_t>();
        int32_t track_detection_criterion = channelJson.at("track_detection_criterion").get<int32_t>();
        int32_t track_reset_criterion = channelJson.at("track_reset_criterion").get<int32_t>();
        int32_t min_distance_between_objects = channelJson.at("min_distance_between_objects").get<int32_t>();
        int32_t scale_factor = channelJson.at("scale_factor").get<int32_t>();
        int32_t num_gauss_elements_in_pixel_model = channelJson.at("num_gauss_elements_in_pixel_model").get<int32_t>();

        // Set motion detector parameters.
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::PIXEL_DEVIATION, pixel_deviation);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::ALPHA_COEFF, alpha_coeff);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::PIXEL_DEVIATION, pixel_deviation);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MAX_OBJECT_WIDTH, max_object_width);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MIN_OBJECT_WIDTH, min_object_width);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MAX_OBJECT_HEIGHT, max_object_height);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MIN_OBJECT_HEIGHT, min_object_height);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MIN_OBJECT_VELOCITY, min_object_velocity);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MAX_OBJECT_VELOCITY, max_object_velocity);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::NUM_THREADS, num_threads);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::TRACK_DETECTION_CRITERION, track_detection_criterion);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::TRACK_RESET_CRITERION, track_reset_criterion);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::MIN_DISTANCE_BETWEEN_OBJECTS, min_distance_between_objects);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::SCALE_FACTOR, scale_factor);
        motion_detector.Set_Property(mdetector::GaussMotionDetectorProperty::NUM_GAUSSES, num_gauss_elements_in_pixel_model);
    }
    catch (const std::exception&)
    {
        in.close();
        return false;
    }

    in.close();

    return true;
}


// Funtion to open video file.
bool OpenVideoFileDialog()
{
    IFileOpenDialog* pFileOpen = nullptr;
    HRESULT hr;
    PWSTR file;
    char* filename;

    hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
    if (SUCCEEDED(hr))
    {
        hr = CoCreateInstance(CLSID_FileOpenDialog,
            NULL, CLSCTX_ALL,
            IID_IFileOpenDialog,
            reinterpret_cast<void**>(&pFileOpen));
        if (SUCCEEDED(hr))
        {
            pFileOpen->SetTitle(L"OPEN VIDEO FILE");
            hr = pFileOpen->Show(NULL);
            if (SUCCEEDED(hr))
            {
                IShellItem* pItem;
                hr = pFileOpen->GetResult(&pItem);
                if (SUCCEEDED(hr))
                {
                    hr = pItem->GetDisplayName(SIGDN_FILESYSPATH, &file);
                    if (SUCCEEDED(hr))
                    {
                        pItem->Release();
                        int count = WideCharToMultiByte(CP_ACP, 0, file, static_cast<int>(wcslen(file)), 0, 0, NULL, NULL);
                        filename = new char[(size_t)count + 1];
                        WideCharToMultiByte(CP_ACP, 0, file, count, filename, count + 1, NULL, NULL);
                        filename[static_cast<size_t>(count)] = '\0';
                        std::cout << filename << std::endl;
                        video_source.open(filename);
                        if (!video_source.isOpened())
                            return false;
                        return true;
                    }
                }
                pItem->Release();
            }
        }
    }
    pFileOpen->Release();
    return false;
}



// Function to get current time string
std::string getDayTimeString()
{
    time_t rawtime;
    struct tm timeinfo;
    char buffer[80];

    time(&rawtime);
    localtime_s(&timeinfo, &rawtime);

    strftime(buffer, sizeof(buffer), "%d_%m_%Y_%H_%M_%S", &timeinfo);
    std::string str(buffer);

    return str;
}
