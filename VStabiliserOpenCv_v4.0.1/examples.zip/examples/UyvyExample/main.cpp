#include <iostream>
#include <opencv2/opencv.hpp>
#include <VStabiliserOpenCv.h>

// Function to convert UYVY format to YUV pixel format.
void UYVY_to_YUV(cv::Mat& src, cv::Mat& dst)
{
    size_t p = 0;
    size_t dst_size = src.size().width * src.size().height * 3;
    for (size_t i = 0; i < dst_size; i = i + 6)
    {
        dst.data[i] = src.data[p + 1];
        dst.data[i + 1] = src.data[p];
        dst.data[i + 2] = src.data[p + 2];
        dst.data[i + 3] = src.data[p + 3];
        dst.data[i + 4] = src.data[p];
        dst.data[i + 5] = src.data[p + 2];
        p = p + 4;
    }
}

// Function to convert YUV to UYVY pixel format.
void YUV_to_UYVY(cv::Mat& src, cv::Mat& dst)
{
    size_t p = 0;
    size_t src_size = src.size().width * src.size().height * 3;
    for (size_t i = 0; i < src_size; i = i + 6)
    {

        dst.data[p + 1] = src.data[i];
        dst.data[p] = src.data[i + 1];
        dst.data[p + 2] = src.data[i + 2];
        dst.data[p + 3] = src.data[i + 3];
        p = p + 4;
    }
}

// Entry point.
int main(void)
{
    // Init video source.
    cv::VideoCapture cap;
    if (!cap.open("test.mp4"))
        return -1;

    // Get video frame size.
    int width = (int)cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = (int)cap.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Init images.
    cv::Mat opencvSrcBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvSrcYuvFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstYuvFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvSrcUyvyFrame(cv::Size(width, height), CV_8UC2);
    cv::Mat opencvDstUyvyFrame(cv::Size(width, height), CV_8UC2);
    cr::video::Frame srcUyvyFrame(width, height, cr::video::Fourcc::UYVY);
    cr::video::Frame dstUyvyFrame(width, height, cr::video::Fourcc::UYVY);

    // Create video stabilizer object.
    cr::vstab::VStabiliserOpenCv videoStabilizer;

    // Set video stabilizer parameters.
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::SCALE_FACTOR, 2);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::X_OFFSET_LIMIT, 150);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::Y_OFFSET_LIMIT, 150);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::TYPE, 1);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        cap >> opencvSrcBgrFrame;
        if (opencvSrcBgrFrame.empty())
        {
            // If we have video we can set initial video position.
            cap.set(cv::CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR pixel format to YUV.
        cv::cvtColor(opencvSrcBgrFrame, opencvSrcYuvFrame, cv::COLOR_BGR2YUV);

        // Convert YUV pixel format to UYVY.
        YUV_to_UYVY(opencvSrcYuvFrame, opencvSrcUyvyFrame);

        // Copy video frame data from OpenCV image to image.
        memcpy(srcUyvyFrame.data, opencvSrcUyvyFrame.data, srcUyvyFrame.size);

        // Stabilise frame.   
        if (!videoStabilizer.stabilise(srcUyvyFrame, dstUyvyFrame))
            std::cout << "Stabilisation not calculated" << std::endl;

        // Copy image to OpenCV image.
        memcpy(opencvDstUyvyFrame.data, dstUyvyFrame.data, dstUyvyFrame.size);

        // Convert UYVY pixel format to YUV.
        UYVY_to_YUV(opencvDstUyvyFrame, opencvDstYuvFrame);

        // Convert YUV pixel fornat to BGR.
        cv::cvtColor(opencvDstYuvFrame, opencvDstBgrFrame, cv::COLOR_YUV2BGR);

        // Show video.
        cv::imshow("SOURCE VIDEO", opencvSrcBgrFrame);
        cv::imshow("RESULT VIDEO", opencvDstBgrFrame);

        // Process keyboard events.
        switch (cv::waitKey(1))
        {
        case 27: // ESC - exit.
            exit(0);
        case 32: // SPACE - reset video stabilizer.
            videoStabilizer.executeCommand(cr::vstab::VStabiliserCommand::RESET);
            break;
        }
    }

    return 1;
}
