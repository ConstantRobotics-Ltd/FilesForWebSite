#include <iostream>
#include <opencv2/opencv.hpp>
#include <VStabiliserOpenCv.h>

// Entry point.
int main(void)
{
    // Init video source.
    cv::VideoCapture cap;
    if (!cap.open("test.mp4"))
        return -1;

    // Get video frame size.
    int width = (int)cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = (int)cap.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Init images.
    cv::Mat opencvSrcBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvSrcRgbFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstRgbFrame(cv::Size(width, height), CV_8UC3);
    cr::video::Frame srcRgbFrame(width, height, cr::video::Fourcc::RGB24);
    cr::video::Frame dstRgbFrame(width, height, cr::video::Fourcc::RGB24);

    // Create video stabilizer object.
    cr::vstab::VStabiliserOpenCv videoStabilizer;

    // Set video stabilizer parameters.
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::SCALE_FACTOR, 2);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::X_OFFSET_LIMIT, 150);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::Y_OFFSET_LIMIT, 150);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        cap >> opencvSrcBgrFrame;
        if (opencvSrcBgrFrame.empty())
        {
            // If we have video we can set initial video position.
            cap.set(cv::CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR pixel format to RGB.
        cv::cvtColor(opencvSrcBgrFrame, opencvSrcRgbFrame, cv::COLOR_BGR2RGB);

        // Copy video frame data from OpenCV image to image.
        memcpy(srcRgbFrame.data, opencvSrcRgbFrame.data, srcRgbFrame.size);

        // Stabilise frame.   
        if (!videoStabilizer.stabilise(srcRgbFrame, dstRgbFrame))
            std::cout << "Stabilisation not calculated" << std::endl;

        // Copy image to OpenCV image.
        memcpy(opencvDstRgbFrame.data, dstRgbFrame.data, dstRgbFrame.size);

        // Convert RGB pixel format to BGR.
        cv::cvtColor(opencvDstRgbFrame, opencvDstBgrFrame, cv::COLOR_BGR2RGB);

        // Show video.
        cv::imshow("SOURCE VIDEO", opencvSrcBgrFrame);
        cv::imshow("RESULT VIDEO", opencvDstBgrFrame);

        // Process keyboard events.
        switch (cv::waitKey(1))
        {
        case 27: // ESC - exit.
            exit(0);
        case 32: // SPACE - reset video stabilizer.
            videoStabilizer.executeCommand(cr::vstab::VStabiliserCommand::RESET);
            break;
        }
    }

    return 1;
}
