# Basic example of wrapped cr::vstab::VStabiliserOpenCv into Python
# by using extern C wrapper and ctypes Python library.
import ctypes
import cv2
import numpy as np

# Import cpp library as .dll file. Adjust path according to your build folder.
c_lib_path = "build/bin/CWrapperVStabiliserOpenCv.dll"
c_library = ctypes.CDLL(c_lib_path)

# Prepare proper types according to ctypes library and C functions args.
channels_number = 3
stabilizer_type = ctypes.POINTER(ctypes.c_char)
image_array_type = np.ctypeslib.ndpointer(dtype=np.uint8, ndim=channels_number,
                                           flags='C_CONTIGUOUS')
param_array_type = np.ctypeslib.ndpointer(dtype=np.float32, ndim=1,
                                           flags='C_CONTIGUOUS')
int_type = ctypes.c_int
float_type = ctypes.c_float
float_pointer_type = ctypes.POINTER(ctypes.c_float)

# Define restype and argtypes for all functions.
c_library.createVStabiliserOpenCv.restype = stabilizer_type
c_library.deleteVStabiliserOpenCv.argtypes = [stabilizer_type]
c_library.stabilise.argtypes = [stabilizer_type, int_type, int_type,
                                int_type, int_type, image_array_type,
                                image_array_type]
c_library.initVStabiliser.argtypes = [stabilizer_type, param_array_type]
c_library.setParam.argtypes = [stabilizer_type, int_type, float_type]
c_library.getParam.argtypes = [stabilizer_type,int_type, float_pointer_type]
c_library.executeCommand.argtypes = [stabilizer_type,int_type]
c_library.getOffsets.argtypes = [stabilizer_type, float_pointer_type, 
                                float_pointer_type, float_pointer_type]

def main():
    # Create instance of VStabiliserOpenCv class,
    #  it will be passed to all functions.
    VStabiliserOpenCv = c_library.createVStabiliserOpenCv()

    # Create OpenCV video capture object to load images for stabilisation.
    video_capture = cv2.VideoCapture('video/test.mp4')
    # Prepare input image informations.
    width = int(video_capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video_capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    # Fourcc according to cr::video::Fourcc enum class.
    bgr_fourcc = 1
    data_size = width * height * channels_number

    # Initialize input and ouput images.
    input_frame_ndarray = np.zeros((height, width, channels_number),
                                   dtype=np.uint8)
    output_frame_ndarray = np.zeros((height, width, channels_number),
                                    dtype=np.uint8)

    while True:
        ret, input_frame_ndarray = video_capture.read()
        if not ret:
            break

        c_library.stabilise(VStabiliserOpenCv, width, height, data_size, 
                            bgr_fourcc, input_frame_ndarray,
                            output_frame_ndarray)

        combined_image = cv2.vconcat([input_frame_ndarray,
                                       output_frame_ndarray])
        cv2.imshow("VStabiliserOpenCv",  cv2.resize(combined_image, None,
                                                    fx=0.5, fy=0.5))
        # Press 'q' to exit the loop
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Remember to destroy VStabiliserOpenCv object after calculations.
    c_library.deleteVStabiliserOpenCv(VStabiliserOpenCv)

    test_parameters()

def test_parameters():
     # Create new VStabiliserOpenCv object for testing parameters.
    VStabiliserOpenCv = c_library.createVStabiliserOpenCv()

    # Create array with test values of parameters.
    params_values = [1.0, 200.0, 200.0, 10.0, 0.95, 0.95, 1.0, 1.0, 0, 0,
              0.0, 0, 0, 0.0, 0.0, 2.5, 1, 25.0, 0, 0]
    # Create a NumPy array and fill it with the values.
    params_array = np.array(params_values, dtype=np.float32)

    # Test initVstabiliser with given parameters array.
    c_library.initVStabiliser(VStabiliserOpenCv, params_array)

    # Test set and get param methods.
    c_library.setParam(VStabiliserOpenCv, 16, 1.0)
    # Input parameters have to be ctypes.c_float type to pass them by ref.
    test_param = ctypes.c_float(-1.0)
    c_library.getParam(VStabiliserOpenCv, 18, ctypes.byref(test_param))

    # Test getOffsets method.
    dx = dy = da = ctypes.c_float(-1.0)
    c_library.getOffsets(VStabiliserOpenCv, ctypes.byref(dx), 
                        ctypes.byref(dy), ctypes.byref(da))
    # Test executing commands.
    c_library.executeCommand(VStabiliserOpenCv, 1)
    c_library.deleteVStabiliserOpenCv(VStabiliserOpenCv)

if __name__ == "__main__":
    main()

################         LOOK UP TABLE FOR ENUMS           ################
# Following numbers corresponds to given VStabiliser lib enums
#  VStabiliserParam:            Fourcc:             VStabiliserCommand:
# 1 -  SCALE_FACTOR             1 - RGB24           1 - RESET
# 2 -  X_OFFSET_LIMIT           2 - BGR24           2 - ON
# 3 -  Y_OFFSET_LIMIT           3 - YUYV            3 - OFF
# 4 -  A_OFFSET_LIMIT           4 - UYVY
# 5 -  X_FILTER_COEFF           5 - GRAY
# 6 -  Y_FILTER_COEFF           6 - YUV24
# 7 -  A_FILTER_COEFF           7 - NV12
# 8 -  MODE                     8 - NV21
# 9 -  TRANSPARENT_BORDER       9 - YU12
# 10 - CONST_X_OFFSET          10 - JPEG
# 11 - CONST_Y_OFFSET          11 - H264
# 12 - CONST_A_OFFSET          12 - HEVC
# 13 - INSTANT_X_OFFSET
# 14 - INSTANT_Y_OFFSET
# 15 - INSTANT_A_OFFSET
# 16 - TYPE
# 17 - CUT_FREQUENCY_HZ
# 18 - FPS
# 19 - PROCESSING_TIME_MKS
# 20 - LOG_MODE