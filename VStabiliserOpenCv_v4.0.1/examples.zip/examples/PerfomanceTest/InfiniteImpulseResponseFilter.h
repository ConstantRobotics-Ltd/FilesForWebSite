#pragma once
#include <chrono>
#include <cmath>
#include "VStabiliser.h"



namespace cr
{
namespace vstab
{
    /**
    * @brief Infinite Impuls Response Filter Class.
    */
    class InfiniteImpulsResponseFilter {
    public:

        /**
         * @brief InfiniteImpulsResponseFilter Default class constructor.
         */
        InfiniteImpulsResponseFilter();

        /**
         * @brief InfiniteImpulsResponseFilter Class constructor.
         * @param cutoffFrequency Cutoff frequency of the filter.
         * @param samplingRate Sampling rate of the filter.
         */
        InfiniteImpulsResponseFilter(float cutoffFrequency, float samplingRate);
        
        /**
         * @brief Set param.
         * @param id Param ID.
         * @param value Param value.
         * @return TRUE if param was accepted or FALSE if not.
         */
        bool setParam(cr::vstab::VStabiliserParam id, float value);

        /**
         * @brief Filter new input of a signal.
         * @param inputSignal input signal value.
         * @return filtered output.
         */
        double calculateFilteredValues(double inputSignal);

    private:

        /// Cutoff frequency of the filter.
        float m_cutoffFrequency;
        /// Sampling rate of the system.
        float m_samplingRate{ 30.0f };
        /// Feedforward coefficient B0.
        float m_feedforwardCoeffB0{ 0.0f };
        /// Feedforward coefficient B1.
        float m_feedforwardCoeffB1{ 0.0f };
        /// Feedforward coefficient B2.
        float m_feedforwardCoeffB2{ 0.0f };
        /// Feedback coefficient A1.
        float m_feedbackCoeffA1{ 0.0f };
        /// Feedback coefficient A2.
        float m_feedbackCoeffA2{ 0.0f };
        /// Previous input Z1.
        float m_inputZ1{ 0.0f };
        /// Previous input Z2.
        float m_inputZ2{ 0.0f };
        /// Previous output H1.
        float m_transmittanceH1{ 0.0f };
        /// Previous output H2.
        float m_transmittanceH2{ 0.0f };
        // Quality factor from Butterworths technique.
        const float m_qualityFactor{ 0.70710678118f };

        /**
         * @brief Determine Coefficients by using butterworth method.
         */
        void calculateCoefficients();
    };
}
}