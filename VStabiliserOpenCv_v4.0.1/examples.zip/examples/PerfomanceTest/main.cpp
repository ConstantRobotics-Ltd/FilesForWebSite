#include <iostream>
#include <opencv2/opencv.hpp>
#include <chrono>
#include "VStabiliserOpenCv.h"

using namespace std;
using namespace cv;


std::pair<cv::Mat, std::vector<cv::Point>>  prepareInitialDummyImage(
    cv::Scalar imageColor = cv::Scalar(0, 0, 0), int imageWidth = 1024, 
    cv::Scalar stampColor = cv::Scalar(255, 255, 255), int stampWidth = 30, 
    int numSquaresX = 3, int numSquaresY = 3)
{
    // Create image with set color (default black image).
    cv::Mat image(imageWidth, imageWidth, CV_8UC3, imageColor);
    // Create vector of squares corners coordinates.
    std::vector<cv::Point> squaresCorners;
    // Calculate the step size between squares in both X and Y directions
    int distanceX = (imageWidth - numSquaresX * stampWidth) / (numSquaresX + 1);
    int distanceY = (imageWidth - numSquaresY * stampWidth) / (numSquaresY + 1);

    // Draw squares on the image and fill squares corners.
    for (int y = 0; y < numSquaresY; ++y) 
    {
        for (int x = 0; x < numSquaresX; ++x) 
        {
            int startX = (x + 1) * distanceX + x * stampWidth;
            int startY = (y + 1) * distanceY + y * stampWidth;
            auto newCorner = cv::Point(startX, startY);
            cv::rectangle(image, newCorner, newCorner + cv::Point(stampWidth,
                                                   stampWidth), stampColor, -1);
            squaresCorners.push_back(newCorner);
        }
    }
    return std::make_pair(image, squaresCorners);
}



void shakeImage(cv::Mat &shakenImage, std::vector<cv::Point> squaresCorners, 
    int frameCount, int diagonalFrequency,
    int diagonalAmplitude, int shakingFrequency, int shakingAmplitude, int fps,
    cv::Scalar imageColor = cv::Scalar(128, 128, 128), int stampWidth = 30)
{
    // Clean shaken image.
    shakenImage = cv::Mat(shakenImage.rows, shakenImage.cols, shakenImage.type(),
                                                                    imageColor);
    
    // Calculate diagonal deltas based on the current frame number.
    double diagonalPhaseShift = 2.0 * CV_PI * ((double)diagonalFrequency / 100.0) * (double)frameCount / (float)fps;
    double dx_diagonal = -(double)diagonalAmplitude * std::sin(diagonalPhaseShift);
    double dy_diagonal = (double)diagonalAmplitude * std::sin(diagonalPhaseShift);

    // Calculate deltas with shaking.
    double shakingPhaseShift = 2.0 * CV_PI * (double)shakingFrequency * (double)frameCount / (double)fps;
    double dx = dx_diagonal - shakingAmplitude * std::sin(shakingPhaseShift);
    double dy = dy_diagonal + shakingAmplitude * std::cos(shakingPhaseShift);

    // Draw squares with new positions.
    for (size_t i = 0; i < squaresCorners.size(); ++i) {
        cv::Point newCorner = squaresCorners[i] + cv::Point(static_cast<int>(
            std::round(dx)), static_cast<int>(std::round(dy)));
        cv::rectangle(shakenImage, newCorner, newCorner + cv::Point(stampWidth,
            stampWidth), cv::Scalar(255, 255, 255), -1);
    }
}



int main(void)
{
    int diagonalFrequency = 50;
    int diagonalAmplitude = 50;
    int fps = 30;
    int cutoffFrequency = 200;
    int shakingFrequency = 250;
    int shakingAmplitude = 4;

    int cutoffFrequencyPrev = 30;
    int fpsPrev = 30;

    // Init window.
    cv::namedWindow("VStabiliserOpenCvPerformanceTest", cv::WINDOW_AUTOSIZE);
    // Create shaking diagonal frequency trackbar.
    cv::createTrackbar("CaHz(x100)", "VStabiliserOpenCvPerformanceTest",
                                                        &diagonalFrequency, 1000);
    // Create shaking diagonal amplitude trackbar.
    cv::createTrackbar("caA(pxl)", "VStabiliserOpenCvPerformanceTest",
                                                         &diagonalAmplitude, 60);
    // Create fps trackbar.
    cv::createTrackbar("fps(1/s)", "VStabiliserOpenCvPerformanceTest", &fps,
                                                                           100);
    // Create cutoff frequency trackbar.
    cv::createTrackbar("cHz(x100)", "VStabiliserOpenCvPerformanceTest",
                                                        &cutoffFrequency, 4000);

    // Create shaking  frequency trackbar.
    cv::createTrackbar("sHz(x100)", "VStabiliserOpenCvPerformanceTest",
        &shakingFrequency, 10000);
    // Create shaking  amplitude trackbar.
    cv::createTrackbar("sA(pxl)", "VStabiliserOpenCvPerformanceTest",
        &shakingAmplitude, 60);

    // Get initial image and shaking squares corners values.
    auto initValues = prepareInitialDummyImage();
    auto shakenImage = initValues.first;
    auto squaresCorners = initValues.second;
    int frameCount = 0;

    // Prepare frames.
    cr::video::Frame srcFrame(shakenImage.cols, shakenImage.rows, cr::video::
                                                                 Fourcc::BGR24);
    cr::video::Frame dstFrame(shakenImage.cols, shakenImage.rows, cr::video::
                                                                 Fourcc::BGR24);
    cv::Mat stabilisedImage(shakenImage);

    // Create video stabilizer object.
    auto* videoStabilizer = new cr::vstab::VStabiliserOpenCv();
    videoStabilizer->setParam(cr::vstab::VStabiliserParam::TYPE, 1);
    videoStabilizer->setParam(cr::vstab::VStabiliserParam::TRANSPARENT_BORDER, 0);
    auto m_startTime = std::chrono::steady_clock::now();

    while (true)
    {
        // Set params to video Stabiliser according to sliders.
        if (cutoffFrequencyPrev != cutoffFrequency)
        {
            videoStabilizer->setParam(cr::vstab::VStabiliserParam::
                                      CUT_FREQUENCY_HZ, cutoffFrequency/100.0f);
            cutoffFrequencyPrev = cutoffFrequency;
        }
        if (fpsPrev != fps)
        {
            videoStabilizer->setParam(cr::vstab::VStabiliserParam::FPS, fps);
            fpsPrev = fps;
        }

         //Calculate elapsed time to wait and display exact FPS result.
//        auto elapsedTime =
//            static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>
//                (std::chrono::steady_clock::now() - m_startTime).count());
//        if (fps > 0)
//        {
//            int waitTimeMks = 1000 / fps - elapsedTime;
//            if (waitTimeMks > 0)
//            {
//                std::this_thread::sleep_for(std::chrono::microseconds(waitTimeMks));
//            }
//        }

        shakeImage(shakenImage, squaresCorners, frameCount, diagonalFrequency,
            diagonalAmplitude, shakingFrequency, shakingAmplitude, fps);

        // Put frame number on frame.
        cv::putText(shakenImage, to_string(frameCount), cv::Point(50, 50),
                    FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 0, 255), 3);

        // Perform stabilisation.
        std::memcpy(srcFrame.data, shakenImage.data, srcFrame.size);
        if (!videoStabilizer->stabilise(srcFrame, dstFrame))
            std::cout << "Stabilisation not calculated" << std::endl;
        std::memcpy(stabilisedImage.data, dstFrame.data, dstFrame.size);
        
        cv::imshow("RESULT VIDEO", stabilisedImage);
        cv::imshow("VStabiliserOpenCvPerformanceTest", shakenImage);
        frameCount++;
        m_startTime = std::chrono::steady_clock::now();

        // Process keyboard events.
        switch (cv::waitKey(30))
        {
            // ESC - exit.
            case 27:
            {
                std::cout << "Exit application\n";
                return -1;
            }
        }
    }
    return 1;
}
