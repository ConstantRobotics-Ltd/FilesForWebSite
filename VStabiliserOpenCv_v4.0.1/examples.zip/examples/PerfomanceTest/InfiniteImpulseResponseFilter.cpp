#pragma once
#include "InfiniteImpulseResponseFilter.h"



cr::vstab::InfiniteImpulsResponseFilter::InfiniteImpulsResponseFilter()
{
    // Create default coefficients.
    calculateCoefficients();
}

cr::vstab::InfiniteImpulsResponseFilter::InfiniteImpulsResponseFilter(
                                      float cutoffFrequency, float samplingRate)
{
    m_cutoffFrequency = cutoffFrequency;
    m_samplingRate = samplingRate;
    // Create coefficients with initial values from constructor.
    calculateCoefficients();
}


bool cr::vstab::InfiniteImpulsResponseFilter::setParam(
                                    cr::vstab::VStabiliserParam id, float value)
{
    switch (id)
    {
    case VStabiliserParam::CUT_FREQUENCY_HZ:
    {
        m_cutoffFrequency = value;
        // Update coefficients.
        calculateCoefficients();
        return true;
    }
    case VStabiliserParam::FPS:
    {
        m_samplingRate = value;
        // Update coefficients.
        calculateCoefficients();
        return true;
    }
    default:
        return false;
    }
}



double cr::vstab::InfiniteImpulsResponseFilter::calculateFilteredValues(
                                                             double inputSignal)
{
    double outputTransmittance = (m_feedforwardCoeffB0 * inputSignal +
        m_feedforwardCoeffB1 * m_inputZ1 + m_feedforwardCoeffB2 * m_inputZ2 -
        m_feedbackCoeffA1 * m_transmittanceH1 - m_feedbackCoeffA2 *
        m_transmittanceH2);

    m_inputZ2 = m_inputZ1;
    m_inputZ1 = static_cast<float>(inputSignal);
    m_transmittanceH2 = m_transmittanceH1;
    m_transmittanceH1 = static_cast<float>(outputTransmittance);
    return outputTransmittance;
}



void cr::vstab::InfiniteImpulsResponseFilter::calculateCoefficients()
{
    float omega;
    if (m_samplingRate <= 0.0f)
    {
        omega = 2.0f * 3.14f * m_cutoffFrequency;
    }
    else
    {
        omega = 2.0f * 3.14f * m_cutoffFrequency / m_samplingRate;
    }

    // Check if omega didn't cross PI value, which would lead to alpha < 0.
    if (omega > 3.14f)
    {
        omega = 0;
    }
    float alpha = sin(omega) / (2.0f * m_qualityFactor);
    float cosOmega = cos(omega);

    m_feedforwardCoeffB0 = (1.0f - cosOmega) / 2.0f;
    m_feedforwardCoeffB1 = 1.0f - cosOmega;
    m_feedforwardCoeffB2 = (1.0f - cosOmega) / 2.0f;
    m_feedbackCoeffA1 = -2.0f * cosOmega;
    m_feedbackCoeffA2 = 1.0f - alpha;

    // Apply gain compensation.
    float gain = 1.0f / ((1.0f + alpha) * (1.0f + alpha));
    m_feedforwardCoeffB0 *= gain;
    m_feedforwardCoeffB1 *= gain;
    m_feedforwardCoeffB2 *= gain;

    // Normalize the coefficients to make the filter stable.
    float normalizationFactor = 1.0f / (1.0f + alpha);
    m_feedbackCoeffA1 *= normalizationFactor;
    m_feedbackCoeffA2 *= normalizationFactor;
}
