#include <iostream>
#include <opencv2/opencv.hpp>
#include <VStabiliserOpenCv.h>

// Entry point.
int main(void)
{
    // Init video source.
    cv::VideoCapture cap;
    if (!cap.open("test.mp4"))
        return -1;

    // Get video frame size.
    int width = (int)cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = (int)cap.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Init images.
    cv::Mat opencvSrcBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvSrcYuvFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstYuvFrame(cv::Size(width, height), CV_8UC3);
    cr::video::Frame srcYuvFrame(width, height, cr::video::Fourcc::YUV24);
    cr::video::Frame dstYuvFrame(width, height, cr::video::Fourcc::YUV24);

    // Create video stabilizer object.
    cr::vstab::VStabiliserOpenCv videoStabilizer;

    // Set video stabilizer parameters.
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::SCALE_FACTOR, 2);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::X_OFFSET_LIMIT, 150);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::Y_OFFSET_LIMIT, 150);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        cap >> opencvSrcBgrFrame;
        if (opencvSrcBgrFrame.empty())
        {
            // If we have video we can set initial video position.
            cap.set(cv::CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR pixel format to YUV.
        cv::cvtColor(opencvSrcBgrFrame, opencvSrcYuvFrame, cv::COLOR_BGR2YUV);

        // Copy video frame data from OpenCV image to image.
        memcpy(srcYuvFrame.data, opencvSrcYuvFrame.data, srcYuvFrame.size);

        // Stabilise frame.   
        if (!videoStabilizer.stabilise(srcYuvFrame, dstYuvFrame))
            std::cout << "Stabilisation not calculated" << std::endl;

        // Copy image to OpenCV image.
        memcpy(opencvDstYuvFrame.data, dstYuvFrame.data, dstYuvFrame.size);

        // Convert YUV pixel fornat to BGR.
        cv::cvtColor(opencvDstYuvFrame, opencvDstBgrFrame, cv::COLOR_YUV2BGR);

        // Show video.
        cv::imshow("SOURCE VIDEO", opencvSrcBgrFrame);
        cv::imshow("RESULT VIDEO", opencvDstBgrFrame);

        // Process keyboard events.
        switch (cv::waitKey(1))
        {
        case 27: // ESC - exit.
            exit(0);
        case 32: // SPACE - reset video stabilizer.
            videoStabilizer.executeCommand(cr::vstab::VStabiliserCommand::RESET);
            break;
        }
    }

    return 1;
}
