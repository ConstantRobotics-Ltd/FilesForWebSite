#include <iostream>
#include <opencv2/opencv.hpp>
#include <VStabiliserOpenCv.h>

// Function to convert YUV to NV21.
void YUV_to_NV21(cv::Mat& yuv, cv::Mat& nv21)
{
    // Init variables.
    int width = yuv.size().width;
    int height = yuv.size().height;

    // Copy gray data.
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x)
            nv21.data[y * width + x] = yuv.data[y * width * 3 + x * 3];

    // Copy UV data.
    int i = height;
    for (int y = 0; y < height; y = y + 2)
    {
        for (int x = 0; x < width; x = x + 2)
        {
            nv21.data[i * width + x] = yuv.data[y * width * 3 + x * 3 + 2];
            nv21.data[i * width + x + 1] =  yuv.data[y * width * 3 + x * 3 + 1];
        }
        ++i;
    }
}



// Function to convert NV21 to YUV.
void NV21_to_YUV(cv::Mat& nv21, cv::Mat& yuv)
{
    // Init variables.
    int width = yuv.size().width;
    int height = yuv.size().height;

    // Copy data.
    int i = height;
    for (int y = 0; y < height; y = y + 2)
    {
        for (int x = 0; x < width; x = x + 2)
        {
            // Copy Y data.
            yuv.data[y * width * 3 + x * 3] = nv21.data[y * width + x];
            yuv.data[y * width * 3 + x * 3 + 3] = nv21.data[y * width + x + 1];
            yuv.data[(y + 1) * width * 3 + x * 3] = nv21.data[(y + 1) * width + x];
            yuv.data[(y + 1) * width * 3 + x * 3 + 3] = nv21.data[(y + 1) * width + x + 1];

            // Copy U data.
            yuv.data[y * width * 3 + x * 3 + 1] =       nv21.data[i * width + x + 1];
            yuv.data[y * width * 3 + x * 3 + 4] =       nv21.data[i * width + x + 1];
            yuv.data[(y + 1) * width * 3 + x * 3 + 1] = nv21.data[i * width + x + 1];
            yuv.data[(y + 1) * width * 3 + x * 3 + 4] = nv21.data[i * width + x + 1];

            // Copy V data.
            yuv.data[y * width * 3 + x * 3 + 2] =         nv21.data[i * width + x];
            yuv.data[y * width * 3 + x * 3 + 5] =         nv21.data[i * width + x];
            yuv.data[(y + 1) * width * 3 + x * 3 + 2] =   nv21.data[i * width + x];
            yuv.data[(y + 1) * width * 3 + x * 3 + 5] =   nv21.data[i * width + x];
        }
        ++i;
    }
}

// Entry point.
int main(void)
{
    // Init video source.
    cv::VideoCapture cap;
    if (!cap.open("test.mp4"))
        return -1;

    // Get video frame size.
    int width = (int)cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = (int)cap.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Init images.
    cv::Mat opencvSrcBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstBgrFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvSrcYuvFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvDstYuvFrame(cv::Size(width, height), CV_8UC3);
    cv::Mat opencvSrcNv21Frame(cv::Size(width, height + height / 2), CV_8UC1);
    cv::Mat opencvDstNv21Frame(cv::Size(width, height + height / 2), CV_8UC1);
    cr::video::Frame srcNv21Frame(width, height, cr::video::Fourcc::NV21);
    cr::video::Frame dstNv21Frame(width, height, cr::video::Fourcc::NV21);

    // Create video stabilizer object.
    cr::vstab::VStabiliserOpenCv videoStabilizer;

    // Set video stabilizer parameters.
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::SCALE_FACTOR, 2);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::X_OFFSET_LIMIT, 150);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::Y_OFFSET_LIMIT, 150);
    videoStabilizer.setParam(cr::vstab::VStabiliserParam::TYPE, 0);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        cap >> opencvSrcBgrFrame;
        if (opencvSrcBgrFrame.empty())
        {
            // If we have video we can set initial video position.
            cap.set(cv::CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR pixel format to YUV.
        cv::cvtColor(opencvSrcBgrFrame, opencvSrcYuvFrame, cv::COLOR_BGR2YUV);

        // Convert YUV pixel format to UYVY.
        YUV_to_NV21(opencvSrcYuvFrame, opencvSrcNv21Frame);

        // Copy video frame data from OpenCV image to image.
        memcpy(srcNv21Frame.data, opencvSrcNv21Frame.data, srcNv21Frame.size);

        // Stabilise frame.   
        if (!videoStabilizer.stabilise(srcNv21Frame, dstNv21Frame))
            std::cout << "Stabilisation not calculated" << std::endl;


        // Copy image to OpenCV image.
        memcpy(opencvDstNv21Frame.data, dstNv21Frame.data, dstNv21Frame.size);

        // Convert UYVY pixel format to YUV.
        NV21_to_YUV(opencvDstNv21Frame, opencvDstYuvFrame);

        // Convert YUV pixel fornat to BGR.
        cv::cvtColor(opencvDstYuvFrame, opencvDstBgrFrame, cv::COLOR_YUV2BGR);

        // Show video.
        cv::imshow("SOURCE VIDEO", opencvSrcBgrFrame);
        cv::imshow("RESULT VIDEO", opencvDstBgrFrame);

        // Process keyboard events.
        switch (cv::waitKey(1))
        {
        case 27: // ESC - exit.
            exit(0);
        case 32: // SPACE - reset video stabilizer.
            videoStabilizer.executeCommand(cr::vstab::VStabiliserCommand::RESET);
            break;
        }
    }

    return 1;
}
