#include <iostream>
#include <chrono>
#include <opencv2/opencv.hpp>
#include "SimpleFileDialog.h"
#include "MotionMagnificator.h"
#include "MotionMagnificatorConfig.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace std::chrono;



/// ROI (Detection mask) top-left X coordinate.
int g_roiX0{0};
/// ROI (Detection mask) top-left Y coordinate.
int g_roiY0{0};
/// ROI (Detection mask) bottom-right X coordinate.
int g_roiX1{0};
/// ROI (Detection mask) bottom-right Y coordinate.
int g_roiY1{0};
/// Draw ROI (Detection mask) flag.
bool g_drawRoi{false};
/// Motion magnificator.
MotionMagnificator g_magnificator;
/// Frame width.
int g_width{0};
/// Frame height.
int g_height{0};
// Level.
int g_level{0};
// Display image.
Mat g_displayImg;



/// Callback function for level changing.
void levelCallback(int, void*)
{
    g_magnificator.setParam(VFilterParam::LEVEL, (float)g_level);
}



/// Mouse callback function to apply detection mask.
void applyDetectionMask(int event, int x, int y, int flags, void* userdata)
{
    switch (event)
    {
    case cv::EVENT_LBUTTONDOWN:
    {
        g_drawRoi = true;
        g_roiX0 = x;
        g_roiY0 = y;
        g_roiX1 = g_roiX0;
        g_roiY1 = g_roiY0;
        break;
    }
    case cv::EVENT_RBUTTONDOWN: break;
    case cv::EVENT_LBUTTONUP:
    {
        g_drawRoi = false;
        g_roiX1 = x;
        g_roiY1 = y;
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
        {
            // Create mask image.
            Frame maskFrame(g_displayImg.size().width,
                            g_displayImg.size().height, Fourcc::GRAY);
            Mat maskImg(g_displayImg.size().height, g_displayImg.size().width,
                        CV_8UC1, maskFrame.data);
            rectangle(maskImg, Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                                    g_roiY1 - g_roiY0 + 1),
                      Scalar(255, 255, 255), FILLED);

            // Set mask image.
            g_magnificator.setMask(maskFrame);
        }
        break;
    }
    case cv::EVENT_MBUTTONDOWN:	break;
    case cv::EVENT_MOUSEMOVE:
    {
        if (g_drawRoi && x > g_roiX0 && y > g_roiY0)
        {
            g_roiX1 = x;
            g_roiY1 = y;
        }
        break;
    }
    }
}



void choseDeviceForOpenCL()
{
    // Print GPU devices.
    cout << "OpenCL was found. Available GPU devices for OpenCL implementation: \n";
    std::vector<std::vector<std::string>> devices = MotionMagnificator::getDevices();
    for (size_t i = 0; i < devices.size(); i++)
    {
        std::cout << "Platform " << i << ":" << std::endl;
        for (size_t j = 0; j < devices[i].size(); j++)
        {
            std::cout << "    Device nr  " << j << ": " << devices[i][j] << std::endl;
        }
    }

    cout << "Enter platform number: ";
    int platformNumber;
    cin >> platformNumber;
    g_magnificator.setParam(cr::video::VFilterParam::CUSTOM_1, (float)platformNumber);

    cout << "Enter device number: ";
    int deviceNumber;
    cin >> deviceNumber;
    g_magnificator.setParam(cr::video::VFilterParam::CUSTOM_2, (float)deviceNumber);

    cout << "Enter number of GPU threads (0 - for auto detection): ";
    int globalWorkSize;
    cin >> globalWorkSize;
    g_magnificator.setParam(cr::video::VFilterParam::CUSTOM_3, (float)globalWorkSize);
}


int main(void)
{
    cout << "=================================================" << endl;
    cout << "MotionMagnificator v" << MotionMagnificator::getVersion() <<
            " demo application" << endl;
    cout << "=================================================" << endl << endl;

    int type;
	std::string str = "Select platform | 0 - CPU, one thread | ";
#if OPENMP_FOUND_FLAG
	str += "1 - CPU, multi threads with OpenMP | ";
#endif
#if OPENCL_FOUND_FLAG
	str += "2 - GPU with OpenCL | ";
#endif
    cout << str << ": ";
	cin >> type;
	g_magnificator.setParam(VFilterParam::TYPE, (float)type);
    switch (type)
    {
    case 1:
#if OPENMP_FOUND_FLAG
		// Set number of threads.
		int numThreads;
		str = "Set number of threads: ";
		cout << str;
		cin >> numThreads;
		g_magnificator.setParam(VFilterParam::CUSTOM_3, (float)numThreads);
#endif
	break;
	case 2:
#if OPENCL_FOUND_FLAG
        choseDeviceForOpenCL();
#endif
	break;
    }

    // Chose source.
    std::string source;
    std::cout << "Open file dialog? (y/n) ";
    std::string answer;
	std::cin >> answer;
    if (answer == "y" || answer == "Y")
    {
        source = SimpleFileDialog::dialog();
    }
    else
    {
        std::cout << "Enter video source init string (camera num, rtsp string, video file) : ";
	    std::cin >> source;
    }

    // Open video source.
    VideoCapture videoSource;
    if (source.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(source)))
        {
            cout << "ERROR: Camera not open" << endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(source))
        {
            cout << "ERROR: Video source not open" << endl;
            return -1;
        }
    }

    // Get frame size.
    g_width = static_cast<int>(videoSource.get(CAP_PROP_FRAME_WIDTH));
    g_height = static_cast<int>(videoSource.get(CAP_PROP_FRAME_HEIGHT));

    // Init frames.
    Frame yuvFrame(g_width, g_height, Fourcc::YUV24);
    Mat bgrImg;

    // Initial processing time, mks.
    float timeMsec = 5.0f;

    // Video writer for result video.
    VideoWriter* resultWriter = nullptr;

    // Create window.
    string wndName = "MotionMagnificator v" + MotionMagnificator::getVersion();
    namedWindow(wndName, WINDOW_AUTOSIZE);
    // Register mouse callback.
    setMouseCallback(wndName, applyDetectionMask);
    // Create trackbar.
    createTrackbar("Level", wndName, &g_level, 100, &levelCallback);
    // Set initial trackbar position.
    setTrackbarPos("Level", wndName, (int)g_magnificator.getParam(VFilterParam::LEVEL));

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        videoSource >> bgrImg;
        if (bgrImg.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR to YUV.
        Mat yuvImg(g_height, g_width, CV_8UC3, yuvFrame.data);
        cvtColor(bgrImg, yuvImg, COLOR_BGR2YUV);

        // Motion magnification.

        if (!g_magnificator.processFrame(yuvFrame))
        {
            cout << "Motion Magnificator error!" << endl;
            continue;
        }
        timeMsec = 0.9f * timeMsec + 0.1f * g_magnificator.getParam(
            VFilterParam::PROCESSING_TIME_MCSEC);

        // Convert result YUV image to BGR to display.
        cvtColor(yuvImg, bgrImg, COLOR_YUV2BGR);

        // Resize mix video if necessary to fit display.
        if (g_height > 720)
        {
            int dstHeight = 720;
            int dstWidth = (int)((float)g_width * (float)dstHeight / (float)g_height);
            resize(bgrImg, g_displayImg, Size(dstWidth, dstHeight));
        }
        else
        {
            bgrImg.copyTo(g_displayImg);
        }

        int position = 20;
        // Record video.
        if (resultWriter != nullptr)
        {
            // Record videos.
            resultWriter->write(bgrImg);

            // Show "RECORDING" message.
            putText(g_displayImg, "RECORDING: R to stop", Point(5, position),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "RECORDING: R to stop", Point(6, position + 1),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(g_displayImg, "R to start recording", Point(5, position),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "R to start recording", Point(6, position + 1),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }
        position += 20;
        string str = "Processing time: " + to_string((int)timeMsec) + " msec";
        putText(g_displayImg, str, Point(5, position), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, position + 1), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, LINE_AA);
        position += 20;
        if (g_magnificator.getParam(VFilterParam::MODE) == 0.0f)
        {
            // Show "RECORDING" message.
            putText(g_displayImg, "DISABLED: E to enable", Point(5, position),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "DISABLED: E to enable", Point(6, position + 1),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(g_displayImg, "ENABLED: E to disable", Point(5, position),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "ENABLED: E to disable", Point(6, position + 1),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }
        position += 20;
        str = "SPACE to reset magnificator";
        putText(g_displayImg, str, Point(5, position), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, position + 1), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, LINE_AA);
        position += 20;

        if ((int)g_magnificator.getParam(cr::video::VFilterParam::TYPE) == 1)
        {
            str = "Number of threads (n - , N +): " + to_string((int)g_magnificator.getParam(cr::video::VFilterParam::CUSTOM_3));
            putText(g_displayImg, str, Point(5, position), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, str, Point(6, position + 1), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, LINE_AA);
        }
        else if ((int)g_magnificator.getParam(cr::video::VFilterParam::TYPE) == 2)
        {
            str = "Number of GPU threads (n - , N +): " + to_string((int)g_magnificator.getParam(cr::video::VFilterParam::CUSTOM_3));
            putText(g_displayImg, str, Point(5, position), FONT_HERSHEY_SIMPLEX, 0.6,
                Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, str, Point(6, position + 1), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, LINE_AA);
        }
        

        // Draw ROI of detection area.
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
            rectangle(g_displayImg,
                Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                    g_roiY1 - g_roiY0 + 1),
                Scalar(255, 255, 0), 1);

        // Show results.
        imshow(wndName, g_displayImg);

        // Process keyboard events.
        switch (waitKey(1))
        {
            // ESC - exit.
        case 27:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
            }
            exit(0);
        }
        // SPACE - reset motion magnificator.
        case 32:
        {
            g_magnificator.executeCommand(VFilterCommand::RESET);
            break;
        }
        // R - Start/stop video recording.
        case 82:
        case 114:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                resultWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                resultWriter = new VideoWriter(videoFileName,
                VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, bgrImg.size(), true);
                assert(resultWriter != 0);
            }
            break;
        }
        // E - Enable/disable magnificator.
        case 69:
        case 101:
        {
            if (g_magnificator.getParam(VFilterParam::MODE) == 0.0f)
            {
                g_magnificator.executeCommand(VFilterCommand::ON);
            }
            else
            {
                g_magnificator.executeCommand(VFilterCommand::OFF);
            }
            break;
        }
        case 84:
        case 110:
        {   
            if ((int)g_magnificator.getParam(cr::video::VFilterParam::TYPE) == 1)
            {
                float number = g_magnificator.getParam(VFilterParam::CUSTOM_3);
                number -= 2.0f;
			    g_magnificator.setParam(VFilterParam::CUSTOM_3, number);
            }
            else if ((int)g_magnificator.getParam(cr::video::VFilterParam::TYPE) == 2)
            {
                float number = g_magnificator.getParam(VFilterParam::CUSTOM_3);
                number -= 64.0f;
			    g_magnificator.setParam(VFilterParam::CUSTOM_3, number);
            }

            break;
        }
        case 78:
        {
            if ((int)g_magnificator.getParam(cr::video::VFilterParam::TYPE) == 1)
            {
                float number = g_magnificator.getParam(VFilterParam::CUSTOM_3);
                number += 2.0f;
			    g_magnificator.setParam(VFilterParam::CUSTOM_3, number);
            }
            else if ((int)g_magnificator.getParam(cr::video::VFilterParam::TYPE) == 2)
            {
                float number = g_magnificator.getParam(VFilterParam::CUSTOM_3);
                number += 64.0f;
			    g_magnificator.setParam(VFilterParam::CUSTOM_3, number);
            }

            break;
        }
        break;
        }
    }

    return 1;
}