#include <iostream>
#include <chrono>
#include <opencv2/opencv.hpp>
#include "SimpleFileDialog.h"
#include "Ged.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace cr::detector;
using namespace std::chrono;



/// ROI (Detection mask) top-left X coordinate.
int g_roiX0{0};
/// ROI (Detection mask) top-left Y coordinate.
int g_roiY0{0};
/// ROI (Detection mask) bottom-right X coordinate.
int g_roiX1{0};
/// ROI (Detection mask) bottom-right Y coordinate.
int g_roiY1{0};
/// Draw ROI (Detection mask) flag.
bool g_drawRoi{false};
/// Event detector.
Ged g_detector;
/// Display image.
Mat g_displayImg;



/// Mouse callback function to apply detection mask.
void applyDetectionMask(int event, int x, int y, int flags, void* userdata)
{
    // We have mixed video (source + mask). So, we have to limit coordinate
    // of detection ROI.
    if (y > g_displayImg.size().height / 2)
        y = g_displayImg.size().height / 2;

    switch (event)
    {
    case cv::EVENT_LBUTTONDOWN:
    {
        g_drawRoi = true;
        g_roiX0 = x;
        g_roiY0 = y;
        g_roiX1 = x;
        g_roiY1 = y;
        break;
    }
    case cv::EVENT_RBUTTONDOWN: break;
    case cv::EVENT_LBUTTONUP:
    {
        g_drawRoi = false;
        g_roiX1 = x;
        g_roiY1 = y;
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
        {
            // Create maks image.
            Frame maskFrame(g_displayImg.size().width,
                            g_displayImg.size().height / 2, Fourcc::GRAY);
            Mat maskImg(g_displayImg.size().height / 2, g_displayImg.size().width,
                        CV_8UC1, maskFrame.data);
            rectangle(maskImg, Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                                    g_roiY1 - g_roiY0 + 1),
                      Scalar(255, 255, 255), FILLED);

            // Set detection mask.
            g_detector.setMask(maskFrame);
        }
        break;
    }
    case cv::EVENT_MBUTTONDOWN:	break;
    case cv::EVENT_MOUSEMOVE:
    {
        if (g_drawRoi && x > g_roiX0 && y > g_roiY0)
        {
            g_roiX1 = x;
            g_roiY1 = y;
        }
        break;
    }
    }
}



/// Params class.
class Params
{
public:
    /// Video source init string.
    string videoSource{"file dialog"};
    /// Frame buffer size.
    int frameBufferSize{30};
    /// Minimum object width to be detected, pixels. To be detected object's
    /// width must be >= minObjectWidth.
    int minObjectWidth{2};
    /// Maximum object width to be detected, pixels. To be detected object's
    /// width must be <= maxObjectWidth.
    int maxObjectWidth{128};
    /// Minimum object height to be detected, pixels. To be detected object's
    /// height must be >= minObjectHeight.
    int minObjectHeight{2};
    /// Maximum object height to be detected, pixels. To be detected object's
    /// height must be <= maxObjectHeight.
    int maxObjectHeight{128};
    /// Detection sensitivity. Depends on implementation. Default from 0 to 1.
    float sensitivity{10.0f};
    /// Frame scaling factor for processing purposes. Reduce the image size by
    /// scaleFactor times horizontally and vertically for faster processing.
    int scaleFactor{1};
    /// Num threads. Number of threads for parallel computing.
    int numThreads{1};

    JSON_READABLE(Params, videoSource, frameBufferSize, minObjectWidth,
                  maxObjectWidth, minObjectHeight, maxObjectHeight, sensitivity,
                  scaleFactor, numThreads)
};



// Entry point.
int main(void)
{
    cout << "##################################" << endl;
    cout << "#                                #" << endl;
    cout << "#  Ged v" << Ged::getVersion() << " demo application   #" << endl;
    cout << "#                                #" << endl;
    cout << "##################################" << endl << endl;

    // Load params.
    Params jsonParams;
    ConfigReader config = ConfigReader();
    const string configFileName = "GedDemo.json";

    // Open config JSON file (if not exist - create new and exit).
    if(!config.readFromFile(configFileName))
    {
        cout << "Can't open config file" << endl;
        // Set default file dialog.
        jsonParams.videoSource = "file dialog";
        // Put params to config reader.
        config.set(jsonParams, "Params");
        // Save params to file.
        config.writeToFile("GedDemo.json");
        return -1;
    }

    // Read application params.
    if(!config.get(jsonParams, "Params"))
    {
        cout << "Can't read params from file" << endl;
        // Set default file dialog.
        jsonParams.videoSource = "file dialog";
        // Put params to config reader.
        config.set(jsonParams, "Params");
        // Save params to file.
        config.writeToFile("GedDemo.json");
        return -1;
    }

    // Open file dialog.
    if (jsonParams.videoSource == "file dialog" ||
        jsonParams.videoSource == "dialog")
    {
        jsonParams.videoSource = SimpleFileDialog::dialog();
        cout << "Video file: " << jsonParams.videoSource << endl;
    }

    // Init video source.
    VideoCapture videoSource;
    if (jsonParams.videoSource.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(jsonParams.videoSource)))
        {
            cout << "Camera not open" << endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(jsonParams.videoSource))
        {
            cout << "Video source not open" << endl;
            return -1;
        }
    }

    // Copy params from config file to parameters structire.
    ObjectDetectorParams detectorParams;
    g_detector.getParams(detectorParams);
    detectorParams.frameBufferSize = jsonParams.frameBufferSize;
    detectorParams.minObjectWidth = jsonParams.minObjectWidth;
    detectorParams.maxObjectWidth = jsonParams.maxObjectWidth;
    detectorParams.minObjectHeight = jsonParams.minObjectHeight;
    detectorParams.maxObjectHeight = jsonParams.maxObjectHeight;
    detectorParams.sensitivity = jsonParams.sensitivity;
    detectorParams.scaleFactor = jsonParams.scaleFactor;
    detectorParams.numThreads = detectorParams.numThreads;

    // Init motion detector.
    if (!g_detector.initObjectDetector(detectorParams))
    {
        cout << "Can't init detector" << endl;
        return -1;
    }

    // Init frames.
    Frame maskFrame;
    Mat bgrImg;
    Mat mixImg;

    // Initial processing time, mks.
    float timeMsec = 5.0f;

    // Video writer for result video.
    VideoWriter* resultWriter = nullptr;
    // Video writer for result video.
    VideoWriter* maskWriter = nullptr;
    // Video writer for mix video.
    VideoWriter* mixWriter = nullptr;

    // Create window..
    string windowName = "Ged v" + Ged::getVersion();
    namedWindow(windowName);
    // Register mouse callback function for ROI control.
    setMouseCallback(windowName, applyDetectionMask);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        videoSource >> bgrImg;
        if (bgrImg.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Create Frame object.
        Frame bgrFrame;
        bgrFrame.width = bgrImg.size().width;
        bgrFrame.height = bgrImg.size().height;
        bgrFrame.size = bgrFrame.width * bgrFrame.height * 3;
        bgrFrame.data = bgrImg.data;
        bgrFrame.fourcc = Fourcc::BGR24;

        // Detect objects.
        if (!g_detector.detect(bgrFrame))
        {
            cout << "Can't detect objects" << endl;
            continue;
        }

        // Get current params.
        g_detector.getParams(detectorParams);

        // Update processing time.
        timeMsec = 0.9f * timeMsec +
                   0.1f * (float)detectorParams.processingTimeMks / 1000.0f;

        // Draw detected objects.
        for (int n = 0; n < detectorParams.objects.size(); ++n)
        {
            rectangle(bgrImg, Rect(detectorParams.objects[n].x - 5, detectorParams.objects[n].y - 5,
                                   detectorParams.objects[n].width + 10, detectorParams.objects[n].height + 10),
                      Scalar(0, 0, 255), 2);
            putText(bgrImg, to_string(detectorParams.objects[n].id),
                    Point(detectorParams.objects[n].x - 5, detectorParams.objects[n].y - 7),
                    1, 1, Scalar(0, 0, 255));
        }

        // Get binary mask image.
        if (maskFrame.size == 0)
            maskFrame = Frame(bgrFrame.width, bgrFrame.height, Fourcc::GRAY);
        g_detector.getMotionMask(maskFrame);

        // Create mask image.
        Mat maskImgGray(maskFrame.height, maskFrame.width, CV_8UC1, maskFrame.data);
        Mat maskImg;
        cvtColor(maskImgGray, maskImg, COLOR_GRAY2BGR);

        // Create mix image.
        if (mixImg.empty())
            mixImg = Mat(maskFrame.height, maskFrame.width * 2, CV_8UC3);
        vconcat(bgrImg, maskImg, mixImg);

        // Create display image.
        if (mixImg.size().height > 720)
        {
            int dstHeight = 720;
            int dstWidth = (int)((float)mixImg.size().width * (float)dstHeight /
                                  (float)mixImg.size().height);
            resize(mixImg, g_displayImg, Size(dstWidth, dstHeight));
        }
        else
        {
            bgrImg.copyTo(g_displayImg);
        }

        // Record video.
        if (resultWriter != nullptr)
        {
            // Record videos.
            resultWriter->write(bgrImg);
            maskWriter->write(maskImg);
            mixWriter->write(mixImg);

            // Show "RECORDING" message.
            putText(g_displayImg, "RECORDING: R to stop", Point(5, 20),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "RECORDING: R to stop", Point(6, 21),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }
        else
        {
            putText(g_displayImg, "R to start recording", Point(5, 20),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "R to start recording", Point(6, 21),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }

        string str = "Processing time: " + to_string((int)timeMsec) + " msec";
        putText(g_displayImg, str, Point(5, 40), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, 41), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, LINE_AA);

        str = "SPACE to reset detector";
        putText(g_displayImg, str, Point(5, 60), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, 61), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, LINE_AA);

        // Display parameters that can be changed by user.
        str = "S - ^, s - v | sensitivity - "
            + std::to_string(static_cast<int>(detectorParams.sensitivity));
        putText(g_displayImg, str, cv::Point(5, 80), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, 81), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "M - ^, m - v | max object size - "
            + std::to_string(static_cast<int>(detectorParams.maxObjectWidth));
        putText(g_displayImg, str, cv::Point(5, 100), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, 101), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "W - ^, w - v | min object size - "
            + std::to_string(static_cast<int>(detectorParams.minObjectWidth));
        putText(g_displayImg, str, cv::Point(5, 120), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, 121), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "MOTION MASK";
        putText(g_displayImg, str, Point(5, g_displayImg.size().height - 10),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, g_displayImg.size().height - 9),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        str = "SOURCE";
        putText(g_displayImg, str, Point(5, g_displayImg.size().height / 2 - 10),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, g_displayImg.size().height / 2 - 9),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        // Draw ROI.
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
            rectangle(g_displayImg,
                      Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                           g_roiY1 - g_roiY0 + 1),
                      Scalar(255, 255, 0), 1);

        // Show results.
        imshow(windowName, g_displayImg);

        // Process keyboard events.
        switch (waitKey(1))
        {
            // ESC - exit.
        case 27:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                mixWriter->release();
                maskWriter->release();
            }
            exit(0);
        }
        // SPACE - reset object detector.
        case 32:
        {
            g_detector.executeCommand(ObjectDetectorCommand::RESET);
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                resultWriter = nullptr;
                mixWriter->release();
                mixWriter = nullptr;
                maskWriter->release();
                maskWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                resultWriter = new VideoWriter(videoFileName,
                    VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, bgrImg.size(), true);
                assert(resultWriter != 0);
                videoFileName = "mix_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                mixWriter = new VideoWriter(videoFileName,
                    VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, mixImg.size(), true);
                assert(mixWriter != 0);
                videoFileName = "mask_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                maskWriter = new VideoWriter(videoFileName,
                    VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, maskImg.size(), true);
                assert(mixWriter != 0);
            }
            break;
        }
        case 115:
        {
            auto param = g_detector.getParam(ObjectDetectorParam::SENSITIVITY);
            param -= 5.0f;
            if (param < 5.0f)
                param = 5.0f;
            g_detector.setParam(ObjectDetectorParam::SENSITIVITY, param);
        }
        break;
        case 83:
        {
            g_detector.setParam(ObjectDetectorParam::SENSITIVITY, detectorParams.sensitivity + 5.0f);
        }
        break;
        case 109:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH, detectorParams.maxObjectWidth - 2);
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT, detectorParams.maxObjectHeight - 2);
        }
        break;
        case 77:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH, detectorParams.maxObjectWidth + 2);
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT, detectorParams.maxObjectHeight + 2);
        }
        break;
        case 119:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH, detectorParams.minObjectWidth - 2);
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT, detectorParams.minObjectHeight - 2);
        }
        break;
        case 87:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH, detectorParams.minObjectWidth + 2);
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT, detectorParams.minObjectHeight + 2);
        }
        break;
        }
    }

    return 1;
}
