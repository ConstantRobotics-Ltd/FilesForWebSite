#include <iostream>
#include <chrono>
#include <opencv2/opencv.hpp>
#include "SimpleFileDialog.h"
#include "Gmd.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace cr::detector;
using namespace std::chrono;



/// ROI (Detection mask) top-left X coordinate.
int g_roiX0{0};
/// ROI (Detection mask) top-left Y coordinate.
int g_roiY0{0};
/// ROI (Detection mask) bottom-right X coordinate.
int g_roiX1{0};
/// ROI (Detection mask) bottom-right Y coordinate.
int g_roiY1{0};
/// Draw ROI (Detection mask) flag.
bool g_drawRoi{false};
/// Motion detector.
Gmd g_detector;
/// Display image.
Mat g_displayImg;



/// Mouse callback function to apply detection mask.
void applyDetectionMask(int event, int x, int y, int flags, void* userdata)
{
    // We have mixed video (source + mask). So, we have to limit coordinate
    // of detection ROI.
    if (y > g_displayImg.size().height / 2)
        y = g_displayImg.size().height / 2;

    switch (event)
    {
    case cv::EVENT_LBUTTONDOWN:
    {
        g_drawRoi = true;
        g_roiX0 = x;
        g_roiY0 = y;
        g_roiX1 = x;
        g_roiY1 = y;
        break;
    }
    case cv::EVENT_RBUTTONDOWN: break;
    case cv::EVENT_LBUTTONUP:
    {
        g_drawRoi = false;
        g_roiX1 = x;
        g_roiY1 = y;
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
        {
            // Create maks image.
            Frame maskFrame(g_displayImg.size().width,
                            g_displayImg.size().height / 2, Fourcc::GRAY);
            Mat maskImg(g_displayImg.size().height / 2, g_displayImg.size().width,
                        CV_8UC1, maskFrame.data);
            rectangle(maskImg, Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                                    g_roiY1 - g_roiY0 + 1),
                      Scalar(255, 255, 255), FILLED);

            // Set detection mask.
            g_detector.setMask(maskFrame);
        }
        break;
    }
    case cv::EVENT_MBUTTONDOWN:	break;
    case cv::EVENT_MOUSEMOVE:
    {
        if (g_drawRoi && x > g_roiX0 && y > g_roiY0)
        {
            g_roiX1 = x;
            g_roiY1 = y;
        }
        break;
    }
    }
}



/// Params class.
class Params
{
public:
    /// Video source init string.
    string videoSource{"file dialog"};
    /// Frame buffer size.
    int frameBufferSize{30};
    /// Minimum object width to be detected, pixels. To be detected object's
    /// width must be >= minObjectWidth.
    int minObjectWidth{2};
    /// Maximum object width to be detected, pixels. To be detected object's
    /// width must be <= maxObjectWidth.
    int maxObjectWidth{128};
    /// Minimum object height to be detected, pixels. To be detected object's
    /// height must be >= minObjectHeight.
    int minObjectHeight{2};
    /// Maximum object height to be detected, pixels. To be detected object's
    /// height must be <= maxObjectHeight.
    int maxObjectHeight{128};
    /// Detection sensitivity. Depends on implementation. Default from 0 to 1.
    float sensitivity{10.0f};
    /// Frame scaling factor for processing purposes. Reduce the image size by
    /// scaleFactor times horizontally and vertically for faster processing.
    int scaleFactor{1};
    /// Num threads. Number of threads for parallel computing.
    int numThreads{1};
    /// Horizontal track detection criteria.
    int xDetectionCriteria{10};
    /// Vertical track detection criteria.
    int yDetectionCriteria{10};
    /// resetCriteria.
    int resetCriteria{5};
    /// Minimum object's horizontal speed to be detected, pixels/frame.
    float minXSpeed{0.1f};
    /// Maximum object's horizontal speed to be detected, pixels/frame.
    float maxXSpeed{15.0f};
    /// Minimum object's vertical speed to be detected, pixels/frame.
    float minYSpeed{0.1f};
    /// Maximum object's vertical speed to be detected, pixels/frame.
    float maxYSpeed{15.0f};

    JSON_READABLE(Params, videoSource, frameBufferSize, minObjectWidth,
                  maxObjectWidth, minObjectHeight, maxObjectHeight, sensitivity,
                  scaleFactor, numThreads, xDetectionCriteria,
                  yDetectionCriteria, resetCriteria, minXSpeed, maxXSpeed,
                  minYSpeed, maxYSpeed)
};



int main(void)
{
    cout << "##################################" << endl;
    cout << "#                                #" << endl;
    cout << "#  Gmd v" << Gmd::getVersion() << " demo application   #" << endl;
    cout << "#                                #" << endl;
    cout << "##################################" << endl << endl;

    // Load params.
    Params jsonParams;
    ConfigReader config = ConfigReader();
    const string configFileName = "GedDemo.json";

    // Open config JSON file (if not exist - create new and exit).
    if(!config.readFromFile(configFileName))
    {
        cout << "Can't open config file" << endl;
        // Set default file dialog.
        jsonParams.videoSource = "file dialog";
        // Put params to config reader.
        config.set(jsonParams, "Params");
        // Save params to file.
        config.writeToFile("GedDemo.json");
        return -1;
    }

    // Read application params.
    if(!config.get(jsonParams, "Params"))
    {
        cout << "Can't read params from file" << endl;
        // Set default file dialog.
        jsonParams.videoSource = "file dialog";
        // Put params to config reader.
        config.set(jsonParams, "Params");
        // Save params to file.
        config.writeToFile("GedDemo.json");
        return -1;
    }

    // Open file dialog.
    if (jsonParams.videoSource == "file dialog" ||
        jsonParams.videoSource == "dialog")
    {
        jsonParams.videoSource = SimpleFileDialog::dialog();
        cout << "Video file: " << jsonParams.videoSource << endl;
    }

    // Init video source.
    VideoCapture videoSource;
    if (jsonParams.videoSource.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(jsonParams.videoSource)))
        {
            cout << "Camera not open" << endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(jsonParams.videoSource))
        {
            cout << "Video source not open" << endl;
            return -1;
        }
    }

    // Copy params from config file to parameters structire.
    ObjectDetectorParams detectorParams;
    g_detector.getParams(detectorParams);
    detectorParams.frameBufferSize = jsonParams.frameBufferSize;
    detectorParams.minObjectWidth = jsonParams.minObjectWidth;
    detectorParams.maxObjectWidth = jsonParams.maxObjectWidth;
    detectorParams.minObjectHeight = jsonParams.minObjectHeight;
    detectorParams.maxObjectHeight = jsonParams.maxObjectHeight;
    detectorParams.sensitivity = jsonParams.sensitivity;
    detectorParams.scaleFactor = jsonParams.scaleFactor;
    detectorParams.numThreads = detectorParams.numThreads;
    detectorParams.xDetectionCriteria = detectorParams.xDetectionCriteria;
    detectorParams.yDetectionCriteria = detectorParams.yDetectionCriteria;
    detectorParams.resetCriteria = detectorParams.resetCriteria;
    detectorParams.minXSpeed = detectorParams.minXSpeed;
    detectorParams.maxXSpeed = detectorParams.maxXSpeed;
    detectorParams.minYSpeed = detectorParams.minYSpeed;
    detectorParams.maxYSpeed = detectorParams.maxYSpeed;

    // Init motion detector.
    if (!g_detector.initObjectDetector(detectorParams))
    {
        cout << "Can't init detector" << endl;
        return -1;
    }

    // Init frames.
    Frame maskFrame;
    Mat bgrImg;
    Mat mixImg;

    // Initial processing time, mks.
    float timeMsec = 5.0f;

    // Video writer for result video.
    VideoWriter* resultWriter = nullptr;
    // Video writer for result video.
    VideoWriter* maskWriter = nullptr;
    // Video writer for mix video.
    VideoWriter* mixWriter = nullptr;

    // Create window..
    string windowName = "Gmd v" + Gmd::getVersion();
    namedWindow(windowName);
    // Register mouse callback function for ROI control.
    setMouseCallback(windowName, applyDetectionMask);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        videoSource >> bgrImg;
        if (bgrImg.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Create Frame object.
        Frame bgrFrame;
        bgrFrame.width = bgrImg.size().width;
        bgrFrame.height = bgrImg.size().height;
        bgrFrame.size = bgrFrame.width * bgrFrame.height * 3;
        bgrFrame.data = bgrImg.data;
        bgrFrame.fourcc = Fourcc::BGR24;

        // Detect objects.
        if (!g_detector.detect(bgrFrame))
        {
            continue;
        }

        // Get current params.
        g_detector.getParams(detectorParams);

        // Update processing time.
        timeMsec = 0.9f * timeMsec +
                   0.1f * (float)detectorParams.processingTimeMks / 1000.0f;

        // Draw detected objects.
        for (int n = 0; n < detectorParams.objects.size(); ++n)
        {
            rectangle(bgrImg, Rect(detectorParams.objects[n].x - 5, detectorParams.objects[n].y - 5,
                                   detectorParams.objects[n].width + 10, detectorParams.objects[n].height + 10),
                      Scalar(0, 0, 255), 2);
            putText(bgrImg, to_string(detectorParams.objects[n].id),
                    Point(detectorParams.objects[n].x - 5, detectorParams.objects[n].y - 7),
                    1, 1, Scalar(0, 0, 255));
        }

        // Get binary mask image.
        if (maskFrame.size == 0)
            maskFrame = Frame(bgrFrame.width, bgrFrame.height, Fourcc::GRAY);
        g_detector.getMotionMask(maskFrame);

        // Create mask image.
        Mat maskImgGray(maskFrame.height, maskFrame.width, CV_8UC1, maskFrame.data);
        Mat maskImg;
        cvtColor(maskImgGray, maskImg, COLOR_GRAY2BGR);

        // Create mix image.
        if (mixImg.empty())
            mixImg = Mat(maskFrame.height, maskFrame.width * 2, CV_8UC3);
        vconcat(bgrImg, maskImg, mixImg);

        // Create display image.
        if (mixImg.size().height > 720)
        {
            int dstHeight = 720;
            int dstWidth = (int)((float)mixImg.size().width * (float)dstHeight /
                                  (float)mixImg.size().height);
            resize(mixImg, g_displayImg, Size(dstWidth, dstHeight));
        }
        else
        {
            bgrImg.copyTo(g_displayImg);
        }

        // Record video.
        if (resultWriter != nullptr)
        {
            // Record videos.
            resultWriter->write(bgrImg);
            maskWriter->write(maskImg);
            mixWriter->write(mixImg);

            // Show "RECORDING" message.
            putText(g_displayImg, "RECORDING: R to stop", Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "RECORDING: R to stop", Point(6, 21),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(g_displayImg, "R to start recording", Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "R to start recording", Point(6, 21),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }

        int pos = 40;
        string str = "Processing time: " + to_string((int)timeMsec) + " msec";
        putText(g_displayImg, str, cv::Point(5, pos), FONT_HERSHEY_SIMPLEX, 0.6,
                    Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "SPACE to reset detector";
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                    cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        // Display parameters that can be changed by user.
        pos += 20;
        str = "1 -, 2 + | sensitivity: "
              + std::to_string((int)detectorParams.sensitivity);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "3 -, 4 + | X detection criteria: "
              + std::to_string(detectorParams.xDetectionCriteria);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "5 -, 6 + | Y detection criteria: "
              + std::to_string(detectorParams.yDetectionCriteria);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "7 -, 8 + | Reset criteria: "
              + std::to_string(detectorParams.resetCriteria);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "Q +, A - | Min object width: "
            + std::to_string(detectorParams.minObjectWidth);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "W +, S - | Max object width: "
              + std::to_string(detectorParams.maxObjectWidth);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "E +, D - | Min object height: "
              + std::to_string(detectorParams.minObjectHeight);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "T +, G - | Max object height: "
              + std::to_string(detectorParams.maxObjectHeight);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        str = "MOTION MASK";
        putText(g_displayImg, str, Point(5, g_displayImg.size().height - 10),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(g_displayImg, str, Point(6, g_displayImg.size().height - 9),
            FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        // Draw ROI.
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
            rectangle(g_displayImg,
                      Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                           g_roiY1 - g_roiY0 + 1),
                      Scalar(255, 255, 0), 1);

        // Show results.
        imshow(windowName, g_displayImg);

        // Process keyboard events.
        switch (waitKey(1))
        {
        // ESC - exit.
        case 27:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                mixWriter->release();
                maskWriter->release();
            }
            exit(0);
        }
        // SPACE - reset object detector.
        case 32:
        {
            g_detector.executeCommand(ObjectDetectorCommand::RESET);
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                resultWriter = nullptr;
                mixWriter->release();
                mixWriter = nullptr;
                maskWriter->release();
                maskWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                resultWriter = new VideoWriter(videoFileName,
                                               VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, bgrImg.size(), true);
                assert(resultWriter != 0);
                videoFileName = "mix_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                mixWriter = new VideoWriter(videoFileName,
                                            VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, mixImg.size(), true);
                assert(mixWriter != 0);
                videoFileName = "mask_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                maskWriter = new VideoWriter(videoFileName,
                                             VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, maskImg.size(), true);
                assert(mixWriter != 0);
            }
            break;
        }
        case 49: // 1 - Sensetivity - 1.
        {
            g_detector.setParam(ObjectDetectorParam::SENSITIVITY,
                                detectorParams.sensitivity - 1.0f);
        }
        break;

        case 50: // 2 - Sensetivity + 1.
        {
            g_detector.setParam(ObjectDetectorParam::SENSITIVITY,
                                detectorParams.sensitivity + 1.0f);
        }
        break;

        case 51: // 3 - X detection criteria - 1.
        {
            g_detector.setParam(ObjectDetectorParam::X_DETECTION_CRITERIA,
                                detectorParams.xDetectionCriteria - 1);
        }
        break;

        case 52: // 4 - X detection criteria + 1.
        {
            g_detector.setParam(ObjectDetectorParam::X_DETECTION_CRITERIA,
                                detectorParams.xDetectionCriteria + 1);
        }
        break;

        case 53: // 5 - Y detection criteria - 1.
        {
            g_detector.setParam(ObjectDetectorParam::Y_DETECTION_CRITERIA,
                                detectorParams.yDetectionCriteria - 1);
        }
        break;

        case 54: // 6 - Y detection criteria + 1.
        {
            g_detector.setParam(ObjectDetectorParam::Y_DETECTION_CRITERIA,
                                detectorParams.yDetectionCriteria + 1);
        }
        break;

        case 55: // 7 - Reset criteria - 1.
        {
            g_detector.setParam(ObjectDetectorParam::RESET_CRITERIA,
                                detectorParams.resetCriteria - 1);
        }
        break;

        case 56: // 8 - Reset criteria + 1.
        {
            g_detector.setParam(ObjectDetectorParam::RESET_CRITERIA,
                                detectorParams.resetCriteria + 1);
        }
        break;

        case 113: // Q - Min object width + 1.
        case 81:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH,
                                detectorParams.minObjectWidth + 1);
        }
        break;

        case 97: // A - Min object width - 1.
        case 65:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH,
                                detectorParams.minObjectWidth - 1);
        }
        break;

        case 119: // W - Max object width + 1.
        case 87:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH,
                                detectorParams.maxObjectWidth + 1);
        }
        break;

        case 115: // W - Max object width - 1.
        case 83:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH,
                                detectorParams.maxObjectWidth - 1);
        }
        break;

        case 101: // E - Min object height + 1.
        case 69:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT,
                                detectorParams.minObjectHeight + 1);
        }
        break;

        case 100: // D - Min object height - 1.
        case 68:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT,
                                detectorParams.minObjectHeight - 1);
        }
        break;

        case 116: // T - Max object height + 1.
        case 84:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT,
                                detectorParams.maxObjectHeight + 1);
        }
        break;

        case 103: // G - Max object height - 1.
        case 71:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT,
                                detectorParams.maxObjectHeight - 1);
        }
        break;

        default:
            break;
        }
    }

    return 1;
}
