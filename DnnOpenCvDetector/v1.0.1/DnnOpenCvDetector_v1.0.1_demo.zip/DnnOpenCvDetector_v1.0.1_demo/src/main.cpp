#include <iostream>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <opencv2/opencv.hpp>
#include "SimpleFileDialog.h"
#include "DnnOpenCvDetector.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace cr::detector;
using namespace std::chrono;



/// ROI (Detection mask) top-left X coordinate.
int g_roiX0{ 0 };
/// ROI (Detection mask) top-left Y coordinate.
int g_roiY0{ 0 };
/// ROI (Detection mask) bottom-right X coordinate.
int g_roiX1{ 0 };
/// ROI (Detection mask) bottom-right Y coordinate.
int g_roiY1{ 0 };
/// Draw ROI (Detection mask) flag.
bool g_drawRoi{ false };
/// Motion detector.
DnnOpenCvDetector g_detector;
/// Display image.
Mat g_displayImg;



/// Mouse callback function to apply detection mask.
void applyDetectionMask(int event, int x, int y, int flags, void* userdata)
{
    switch (event)
    {
    case cv::EVENT_LBUTTONDOWN:
    {
        g_drawRoi = true;
        g_roiX0 = x;
        g_roiY0 = y;
        g_roiX1 = x;
        g_roiY1 = y;
        break;
    }
    case cv::EVENT_RBUTTONDOWN: break;
    case cv::EVENT_LBUTTONUP:
    {
        g_drawRoi = false;
        g_roiX1 = x;
        g_roiY1 = y;
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
        {
            // Create mask image.
            Frame maskFrame(g_displayImg.size().width,
                g_displayImg.size().height, Fourcc::GRAY);
            Mat maskImg(g_displayImg.size().height, g_displayImg.size().width,
                CV_8UC1, maskFrame.data);
            rectangle(maskImg, Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                g_roiY1 - g_roiY0 + 1),
                Scalar(255, 255, 255), FILLED);

            // Set detection mask.
            g_detector.setMask(maskFrame);
        }
        break;
    }
    case cv::EVENT_MBUTTONDOWN:	break;
    case cv::EVENT_MOUSEMOVE:
    {
        if (g_drawRoi && x > g_roiX0 && y > g_roiY0)
        {
            g_roiX1 = x;
            g_roiY1 = y;
        }
        break;
    }
    }
}



/// List of class names.
std::vector<std::string> CLASS_NAMES = { "person", "bicycle", "car", "motorbike", "aeroplane", "bus", "train", "truck", "boat", "traffic light","fire hydrant",
"stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe","backpack", "umbrella",
"handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove","skateboard", "surfboard",
"tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange","broccoli", "carrot",
"hot dog", "pizza", "donut", "cake", "chair", "sofa", "pottedplant", "bed", "diningtable", "toilet", "tvmonitor", "laptop", "mouse","remote",
"keyboard", "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush" };



/// Params class.
class Params
{
public:
    /// Video source init string.
    string videoSource{ "file dialog" };
    /// Detector initialization string.
    std::string initString{ "yolov7s.onnx;640;640" };
    /// Minimum detection probability.
    float minDetectionProbability{ 0.5f };
    /// Type: Default 0 - CPU, 1 - integrated GPU (GPU.0), 2 - separate GPU (GPU.1) 3 - both GPUs (MULTI mode).
    int type{ 0 };
    /// Minimum object width to be detected, pixels. To be detected object's
    /// width must be >= minObjectWidth.
    int minObjectWidth{ 2 };
    /// Maximum object width to be detected, pixels. To be detected object's
    /// width must be <= maxObjectWidth.
    int maxObjectWidth{ 128 };
    /// Minimum object height to be detected, pixels. To be detected object's
    /// height must be >= minObjectHeight.
    int minObjectHeight{ 2 };
    /// Maximum object height to be detected, pixels. To be detected object's
    /// height must be <= maxObjectHeight.
    int maxObjectHeight{ 128 };

    JSON_READABLE(Params, videoSource, initString, minDetectionProbability,
        type, minObjectWidth, maxObjectWidth, minObjectHeight,
        maxObjectHeight)
};



int main(void)
{
    cout << "##########################################" << endl;
    cout << "#                                        #" << endl;
    cout << "#   DnnOpenCvDetector  v" << DnnOpenCvDetector::getVersion() <<
        " demo app   #" << endl;
    cout << "#                                        #" << endl;
    cout << "##########################################" << endl;
    cout << endl;

    // Load params.
    Params jsonParams;
    ConfigReader config = ConfigReader();
    const string configFileName = "DnnOpenCvDetectorDemo.json";

    // Open config JSON file (if not exist - create new and exit).
    if (!config.readFromFile(configFileName))
    {
        cout << "Can't open config file" << endl;
        // Set default file dialog.
        jsonParams.videoSource = "file dialog";
        // Put params to config reader.
        config.set(jsonParams, "Params");
        // Save params to file.
        config.writeToFile("DnnOpenCvDetectorDemo.json");
        return -1;
    }

    // Read application params.
    if (!config.get(jsonParams, "Params"))
    {
        cout << "Can't read params from file" << endl;
        // Set default file dialog.
        jsonParams.videoSource = "file dialog";
        // Put params to config reader.
        config.set(jsonParams, "Params");
        // Save params to file.
        config.writeToFile("DnnOpenCvDetectorDemo.json");
        return -1;
    }

    // Open file dialog.
    if (jsonParams.videoSource == "file dialog" ||
        jsonParams.videoSource == "dialog")
    {
        jsonParams.videoSource = SimpleFileDialog::dialog();
        cout << "Video file: " << jsonParams.videoSource << endl;
    }

    // Init video source.
    VideoCapture videoSource;
    if (jsonParams.videoSource.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(jsonParams.videoSource)))
        {
            cout << "Camera not open" << endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(jsonParams.videoSource))
        {
            cout << "Video source not open" << endl;
            return -1;
        }
    }

    // Copy params from config file to parameters structure.
    ObjectDetectorParams detectorParams;
    g_detector.getParams(detectorParams);
    detectorParams.initString = jsonParams.initString;
    detectorParams.minObjectWidth = jsonParams.minObjectWidth;
    detectorParams.maxObjectWidth = jsonParams.maxObjectWidth;
    detectorParams.minObjectHeight = jsonParams.minObjectHeight;
    detectorParams.maxObjectHeight = jsonParams.maxObjectHeight;
    detectorParams.minDetectionProbability = jsonParams.minDetectionProbability;
    detectorParams.type = jsonParams.type;

    // Init motion detector.
    if (!g_detector.initObjectDetector(detectorParams))
    {
        cout << "Can't init detector" << endl;
        return -1;
    }

    // Initial processing time, mks.
    float timeMsec = 5.0f;

    // Video writer for result video.
    VideoWriter* resultWriter = nullptr;

    // Create window..
    string windowName = "DnnOpenCvDetector v" + DnnOpenCvDetector::getVersion();
    namedWindow(windowName);
    // Register mouse callback function for ROI control.
    setMouseCallback(windowName, applyDetectionMask);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        videoSource >> g_displayImg;
        if (g_displayImg.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Create Frame object.
        Frame bgrFrame;
        bgrFrame.width = g_displayImg.size().width;
        bgrFrame.height = g_displayImg.size().height;
        bgrFrame.size = bgrFrame.width * bgrFrame.height * 3;
        bgrFrame.data = g_displayImg.data;
        bgrFrame.fourcc = Fourcc::BGR24;

        // Detect objects.
        if (!g_detector.detect(bgrFrame))
        {
            continue;
        }

        // Get current params.
        g_detector.getParams(detectorParams);

        // Update processing time.
        timeMsec = 0.9f * timeMsec +
            0.1f * (float)detectorParams.processingTimeMks / 1000.0f;

        // Draw detected objects.
        for (int n = 0; n < detectorParams.objects.size(); ++n)
        {
            rectangle(g_displayImg, Rect(detectorParams.objects[n].x, detectorParams.objects[n].y,
                detectorParams.objects[n].width, detectorParams.objects[n].height),
                Scalar(0, 0, 255), 2);
            std::stringstream stream;
            int precision = 2;
            stream << std::fixed << std::setprecision(precision) << detectorParams.objects[n].p;
            std::string probability = stream.str();
            putText(g_displayImg, probability, Point(detectorParams.objects[n].x,
                detectorParams.objects[n].y - 1), 1, 1, Scalar(0, 0, 255));

            putText(g_displayImg, CLASS_NAMES[detectorParams.objects[n].type],
                Point(detectorParams.objects[n].x + 40, detectorParams.objects[n].y - 1),
                1, 1, Scalar(0, 0, 150));
        }

        // Record video.
        if (resultWriter != nullptr)
        {
            // Record videos.
            resultWriter->write(g_displayImg);

            // Show "RECORDING" message.
            putText(g_displayImg, "RECORDING: R to stop", cv::Point(5, 20),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "RECORDING: R to stop", cv::Point(6, 21),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(g_displayImg, "R to start recording", cv::Point(5, 20),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(g_displayImg, "R to start recording", cv::Point(6, 21),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }

        int pos = 40;
        string str = "Processing time: " + to_string((int)timeMsec) + " msec";
        putText(g_displayImg, str, cv::Point(5, pos), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), FONT_HERSHEY_SIMPLEX, 0.6,
            Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "SPACE to reset detector";
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        // Display parameters that can be changed by user.
        pos += 20;
        str = "1 -0.1, 2 +0.1 | minimum probability: "
            + std::to_string(detectorParams.minDetectionProbability);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "Q +, A - | Min object width: "
            + std::to_string(detectorParams.minObjectWidth);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "W +, S - | Max object width: "
            + std::to_string(detectorParams.maxObjectWidth);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "E +, D - | Min object height: "
            + std::to_string(detectorParams.minObjectHeight);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        pos += 20;
        str = "T +, G - | Max object height: "
            + std::to_string(detectorParams.maxObjectHeight);
        putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        // Draw ROI.
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
            rectangle(g_displayImg,
                Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                    g_roiY1 - g_roiY0 + 1),
                Scalar(255, 255, 0), 1);

        // Show results.
        imshow(windowName, g_displayImg);

        // Process keyboard events.
        switch (waitKey(1))
        {
            // ESC - exit.
        case 27:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
            }
            exit(0);
        }
        // SPACE - reset object detector.
        case 32:
        {
            g_detector.executeCommand(ObjectDetectorCommand::RESET);
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (resultWriter != nullptr)
            {
                resultWriter->release();
                resultWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                resultWriter = new VideoWriter(videoFileName,
                    VideoWriter::fourcc('M', 'J', 'P', 'G'), 30, g_displayImg.size(), true);
                assert(resultWriter != 0);
            }
            break;
        }
        case 49: // 1 - Minimum detection probability - 0.1.
        {
            g_detector.setParam(ObjectDetectorParam::MIN_DETECTION_PROPABILITY,
                detectorParams.minDetectionProbability - 0.1f);
        }
        break;

        case 50: // 2 - Minimum detection probability - 0.1.
        {
            g_detector.setParam(ObjectDetectorParam::MIN_DETECTION_PROPABILITY,
                detectorParams.minDetectionProbability + 0.1f);
        }
        break;

        case 113: // Q - Min object width + 1.
        case 81:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH,
                static_cast<float>(detectorParams.minObjectWidth + 1));
        }
        break;

        case 97: // A - Min object width - 1.
        case 65:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_WIDTH,
                static_cast<float>(detectorParams.minObjectWidth - 1));
        }
        break;

        case 119: // W - Max object width + 1.
        case 87:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH,
                static_cast<float>(detectorParams.maxObjectWidth + 1));
        }
        break;

        case 115: // W - Max object width - 1.
        case 83:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_WIDTH,
                static_cast<float>(detectorParams.maxObjectWidth - 1));
        }
        break;

        case 101: // E - Min object height + 1.
        case 69:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT,
                static_cast<float>(detectorParams.minObjectHeight + 1));
        }
        break;

        case 100: // D - Min object height - 1.
        case 68:
        {
            g_detector.setParam(ObjectDetectorParam::MIN_OBJECT_HEIGHT,
                static_cast<float>(detectorParams.minObjectHeight - 1));
        }
        break;

        case 116: // T - Max object height + 1.
        case 84:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT,
                static_cast<float>(detectorParams.maxObjectHeight + 1));
        }
        break;

        case 103: // G - Max object height - 1.
        case 71:
        {
            g_detector.setParam(ObjectDetectorParam::MAX_OBJECT_HEIGHT,
                static_cast<float>(detectorParams.maxObjectHeight - 1));
        }
        break;

        default:
            break;
        }
    }

    return 1;
}
