#include <iostream>
#include <chrono>
#include <opencv2/opencv.hpp>
#include "VStabiliserOpenCv.h"
#include "SimpleFileDialog.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace cr::vstab;
using namespace std::chrono;



/// Params class.
class Params
{
public:

    /// Video source params class.
    class VideoSource
    {
    public:
        /// Video source init string.
        string source{"file dialog"};

        JSON_READABLE(VideoSource, source)
    };

    /// Video source params.
    VideoSource videoSource;
    /// Video stabiliser params.
    VStabiliserParams videoStabiliser;

    JSON_READABLE(Params, videoSource, videoStabiliser)
};



// Entry point.
int main(void)
{
    cout << "##########################################" << endl;
    cout << "#                                        #" << endl;
    cout << "#   VStabiliserOpenCv v" << VStabiliserOpenCv::getVersion() <<
            " demo app    #"<<endl;
    cout << "#                                        #" << endl;
    cout << "##########################################" << endl;
    cout << endl;

    // Init video stabiliser.
    VStabiliser* stabiliser = new VStabiliserOpenCv();
    // Init application params.
    Params params;

    // Load params.
    ConfigReader config = ConfigReader();
    const std::string configFileName = "VStabiliserOpenCvDemo.json";

    // Open config JSON file (if not exist - create new and exit).
    if(!config.readFromFile(configFileName))
    {
        cout << "ERROR: Can't open config file" << endl;
        // Set default file dialog.
        params.videoSource.source = "file dialog";
        // Get default params from video stabiliser.
        stabiliser->getParams(params.videoStabiliser);
        // Put params to config reader.
        config.set(params, "Params");
        // Save params to file.
        config.writeToFile("VStabiliserOpenCvDemo.json");
        return -1;
    }

    // Read application params.
    if(!config.get(params, "Params"))
    {
        cout << "ERROR: Can't read params from file" << endl;
        // Set default file dialog.
        params.videoSource.source = "file dialog";
        // Get default params from video stabiliser.
        stabiliser->getParams(params.videoStabiliser);
        // Put params to config reader.
        config.set(params, "Params");
        // Save params to file.
        config.writeToFile("VStabiliserOpenCvDemo.json");
        return -1;
    }

    // Open file dialog.
    if (params.videoSource.source == "file dialog" ||
        params.videoSource.source == "dialog")
    {
        params.videoSource.source = SimpleFileDialog::dialog();
        cout << "Video file: " << params.videoSource.source << endl;
    }

    // Init video source.
    VideoCapture videoSource;
    if (params.videoSource.source.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(params.videoSource.source)))
        {
            cout << "ERROR: Camera not open" << endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(params.videoSource.source))
        {
            cout << "ERROR: Video source not open" << endl;
            return -1;
        }
    }

    // Init video stabiliser.
    if (!stabiliser->initVStabiliser(params.videoStabiliser))
    {
        cout << "ERROR: Can't init video stabiliser" << endl;
        return -1;
    }

    // Init frames.
    Mat frameOpenCvBgr;
    Frame srcFrame;
    Frame dstFrame;
    Mat srcImg;
    Mat dstImg;
    Mat mixImg;
    Mat displayImg;

    // Initial processing time, mks.
    float timeMsec = 5.0f;

    // Video writer for result video.
    VideoWriter* dstWriter = nullptr;
    // Video writer for mix video.
    VideoWriter* mixWriter = nullptr;

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        videoSource >> frameOpenCvBgr;
        if (frameOpenCvBgr.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Prepare Frame object.
        Frame srcFrame;
        srcFrame.width = frameOpenCvBgr.size().width;
        srcFrame.height = frameOpenCvBgr.size().height;
        srcFrame.size = srcFrame.width * srcFrame.height * 3;
        srcFrame.fourcc = Fourcc::BGR24;
        srcFrame.data = frameOpenCvBgr.data;

        // Stabilise.
        time_point<system_clock> startTime = system_clock::now();
        stabiliser->stabilise(srcFrame, dstFrame);
        timeMsec = 0.9f * timeMsec +
                   0.1f * (float)duration_cast<std::chrono::milliseconds>(
                   system_clock::now() - startTime).count();

        // Init images.
        if (srcImg.empty())
        {
            srcImg = Mat(srcFrame.height, srcFrame.width,CV_8UC3,srcFrame.data);
            dstImg = Mat(dstFrame.height, dstFrame.width,CV_8UC3,dstFrame.data);
            mixImg = Mat::zeros(dstFrame.height * 2, dstFrame.width, CV_8UC3);
        }

        // Create mix image.
        for (uint32_t i = 0; i < dstFrame.height; ++i)
        {
            memcpy(&mixImg.data[i * mixImg.size().width * 3],
                   &srcFrame.data[i * srcFrame.width * 3], srcFrame.width * 3);
            memcpy(&mixImg.data[(i + srcFrame.height) * mixImg.size().width *3],
                   &dstFrame.data[i * dstFrame.width * 3], dstFrame.width * 3);
        }

        // Resize mix video if necessary to fit display.
        if (mixImg.size().height > 960)
        {
            int dstHeight = 960;
            int dstWidth = (int)((float)mixImg.size().width * (float)dstHeight /
                                 (float)mixImg.size().height);
            resize(mixImg, displayImg, Size(dstWidth, dstHeight));
        }
        else
        {
            mixImg.copyTo(displayImg);
        }

        // Record video.
        if (dstWriter != nullptr)
        {
            // Record result video.
            dstWriter->write(dstImg);
            // Record mix video.
            mixWriter->write(mixImg);
            // Show "RECORDING" message.
            putText(displayImg, "RECORDING: R to stop", cv::Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, "RECORDING: R to stop", cv::Point(6, 21),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(displayImg, "R to start recording", cv::Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, "R to start recording", cv::Point(6, 21),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255),1,LINE_AA);
        }

        string str = "Processing time: " + to_string((int)timeMsec) + " msec";
        putText(displayImg, str, Point(5, 40),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, 41),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        str = "SPACE to reset stabiliser";
        putText(displayImg, str, Point(5, 60),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, 61),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        str = "RESULT";
        putText(displayImg, str, Point(5, displayImg.size().height - 10),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, displayImg.size().height - 9),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        str = "SOURCE";
        putText(displayImg, str, Point(5, displayImg.size().height / 2 - 10),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, displayImg.size().height / 2 - 9),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        // Show results.
        str = "VStabiliserOpenCv v" + VStabiliserOpenCv::getVersion();
        imshow(str, displayImg);

        // Process keyboard events.
        switch (waitKey(1))
        {
        // ESC - exit.
        case 27:
        {
            if (dstWriter != nullptr)
            {
                dstWriter->release();
                mixWriter->release();
            }
            exit(0);
        }
        // SPACE - reset video stabilizer.
        case 32:
        {
            stabiliser->executeCommand(VStabiliserCommand::RESET);
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (dstWriter != nullptr)
            {
                dstWriter->release();
                dstWriter = nullptr;
                mixWriter->release();
                mixWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                dstWriter = new VideoWriter(videoFileName,
                VideoWriter::fourcc('M','J','P','G'), 30, dstImg.size(), true);
                assert(dstWriter != 0);
                videoFileName = "mix_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                mixWriter = new VideoWriter(videoFileName,
                VideoWriter::fourcc('M','J','P','G'), 30, mixImg.size(), true);
                assert(mixWriter != 0);
            }
            break;
        }
        }
    }

    return 1;
}
