#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <chrono>
#include <ctime>
#include <opencv2/opencv.hpp>

// Constant Robotics libs.
#include "ConfigReader.h"
#include "nfd.h"
#include "CorrelationVideoTracker.h"

using namespace cr::utils;

// Correlation video tracker params class.
class CorrelationVideoTrackerParams
{
public:
    int frameBufferSize;                    /// Size (number of video frames to store) of video frame buffer.
    int trackingRectangleWidth;             /// Horizontal size of tracking rectangle.
    int trackingRectangleHeight;            /// Vertical size of tracking rectangle.
    double pixelDeviationThreshold;         /// Threshold for pixel deviation to capture object.
    double objectLossThreshold;             /// Threshold for detection object loss.
    double objectDetectionThreshold;        /// Threshold for detection object.
    double patternUpdateCoeff;              /// Coeff for update pattern.
    double probabilityUpdateCoeff;          /// Coeff to update probability threshold.
    int searchWindowWidth;                  /// Width of search window.
    int searchWindowHeight;                 /// Height of search window.
    int lostModeOption;                     /// LOST mode option.
    int maximumNumFramesInLostMode;         /// Maximum number of frames in LOST mode to auto reset of algorithm.
    bool usePredictedPosition;              /// Use predicted position flag.
    bool useTrackingRectangleAutoSize;      /// Tracking rectangle auto size flag.
    bool useTrackingRectangleAutoPosition;  /// Tracking rectangle auto position flag.

    JSON_READABLE(CorrelationVideoTrackerParams,
                  frameBufferSize,
                  trackingRectangleWidth,
                  trackingRectangleHeight,
                  pixelDeviationThreshold,
                  objectLossThreshold,
                  objectDetectionThreshold,
                  patternUpdateCoeff,
                  probabilityUpdateCoeff,
                  searchWindowWidth,
                  searchWindowHeight,
                  lostModeOption,
                  maximumNumFramesInLostMode,
                  usePredictedPosition,
                  useTrackingRectangleAutoSize,
                  useTrackingRectangleAutoPosition);
};

// Video source params class.
class VideoSourceParams
{
public:
    std::string videoSourceInitString;      /// Init string for video source. If "file dialog" - file dialog.
    int scaleFactor;                        /// Downscale factor for input video.

    JSON_READABLE(VideoSourceParams,
                  videoSourceInitString,
                  scaleFactor);
};


// Global vars.
cr::vtracker::CorrelationVideoTracker g_tracker;				/// Video tracker.
cr::vtracker::CorrelationVideoTrackerResultData g_trackerData;	/// Video tracker result data.
bool g_videoStabilizerEnableFlag = false;                       /// Flag of active stabilizer.
int g_frameWidth = 0;                                           /// Video frames width.
int g_frameHeight = 0;                                          /// Video frames height.
int g_mousePositionX = 0;                                       /// Horizontal cursor position in video window.
int g_mousePositionY = 0;                                       /// Vertical cursor position in video window.
float g_probabilityBuffer[256];                                 /// Buffer for probability chart.
float g_thresholdBuffer[256];                                   /// Buffer for threshold chart.
int32_t g_currentBufferFrameID = 0;                             /// Current frame ID in tracker frame buffer.
bool g_stopFrameFlag = false;                                   /// STOP-FRAME mode flag.
bool g_stopPlayFlag = false;                                    /// Flag to stop playing video.
int g_scaleFactor = 1;                                          /// Video scale factor.
double g_videoStabilizerProcessingTime = 0.0;                   /// Stabilizer processing time.
double g_videoTrackerProcessingTime = 0.0;                      /// Tracker processing time.
cv::VideoCapture g_videoSource;                                 /// Video capture object.
float g_videoSourceFps = 0.0f;                                  /// Video source FPS.
cv::VideoWriter* g_videoWriter = nullptr;                       /// Video writer object.
int g_videoPosition = 0;                                        /// Video position.


/**
@brief Prototype of callback function for mouse events.
*/
void mouseCallBackFunction(int event, int x, int y, int flags, void* userdata);
/**
@brief Prototype of function to draw info on video.
*/
void drawInfoFunction(cv::Mat& frame);
/**
@brief Prototype of function to process keyboard events.
*/
void keyboardEventsFunction(int key);
/**
@brief Prototype of function to get current date and time string.
*/
std::string getDayTimeString();
/**
@brief Prototype of function to load tracker params.
*/
bool loadAndInitParams();
/**
@brief Calback function for video position trackbar.
*/
static void videoPosPositionCallback(int, void*)
{
    // Set video position.
    g_videoSource.set(cv::CAP_PROP_POS_FRAMES, g_videoPosition + 1);
}



// Entry point.
int main(void)
{
    // Welcom text.
    std::cout << "=============================================" << std::endl;
    std::cout << "Correlation Video Tracket C++ library v" << cr::vtracker::CorrelationVideoTracker::getVersion() << std::endl;
    std::cout << "=============================================" << std::endl << std::endl;

    // Load and init params.
    if (!loadAndInitParams())
    {
        std::cout << "ERROR: Params not loaded." << std::endl;
        return -1;
    }

	// Get frames size.
    g_frameWidth = (int)g_videoSource.get(cv::CAP_PROP_FRAME_WIDTH);
    g_frameHeight = (int)g_videoSource.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Get FPS.
    g_videoSourceFps = (float)g_videoSource.get(cv::CAP_PROP_FPS);
    if (g_videoSourceFps < 0.0f)
        g_videoSourceFps = 30.0f;
    if (g_videoSourceFps > 60.0f)
        g_videoSourceFps = 60.0f;

	// Init mouse position.
    g_mousePositionX = g_frameWidth / 2;
    g_mousePositionY = g_frameHeight / 2;

	// Create images.
    cv::Mat sourceFrame = cv::Mat(cv::Size(g_frameWidth, g_frameHeight), CV_8UC3);
    cv::Mat bufferFrame = cv::Mat(cv::Size(g_frameWidth, g_frameHeight), CV_8UC3);
    cv::Mat playbackBufferFrame = cv::Mat(cv::Size(g_frameWidth, g_frameHeight), CV_8UC3);
    cv::Mat grayFrame = cv::Mat(cv::Size(g_frameWidth, g_frameHeight), CV_8UC1);
    cv::Mat resizedSourceFrame = cv::Mat(cv::Size(g_frameWidth / g_scaleFactor, g_frameHeight / g_scaleFactor), CV_8UC3);
    cv::Mat trackerPatternImage = cv::Mat(cv::Size(CVT_MAXIMUM_TRACKING_RECTANGLE_WIDTH, CVT_MAXIMUM_TRACKING_RECTANGLE_HEIGHT), CV_8UC1);
    cv::Mat trackerMaskImage = cv::Mat(cv::Size(CVT_MAXIMUM_TRACKING_RECTANGLE_WIDTH, CVT_MAXIMUM_TRACKING_RECTANGLE_HEIGHT), CV_8UC1);
    cv::Mat trackerCorrImage = cv::Mat(cv::Size(CVT_MAXIMUM_SEARCH_WINDOW_WIDTH, CVT_MAXIMUM_SEARCH_WINDOW_HEIGHT), CV_8UC1);
    cv::Mat probabilityImage = cv::Mat(cv::Size(256, 256), CV_8UC3);

	// Buffers for probability values.
    memset(g_probabilityBuffer, 0, 256 * sizeof(float));
    memset(g_thresholdBuffer, 0, 256 * sizeof(float));
	uint8_t currentBufferIndex = 0;

	// Create windows.
    cv::namedWindow("CORRELATION VIDEO TRACKER v" + cr::vtracker::CorrelationVideoTracker::getVersion(), cv::WINDOW_AUTOSIZE);
    cv::moveWindow("CORRELATION VIDEO TRACKER v" + cr::vtracker::CorrelationVideoTracker::getVersion(), 5, 5);
    cv::setMouseCallback("CORRELATION VIDEO TRACKER v" + cr::vtracker::CorrelationVideoTracker::getVersion(), mouseCallBackFunction, nullptr);
	
    // Get number of frames.
    int numFrames = (int)g_videoSource.get(cv::CAP_PROP_FRAME_COUNT);
    if (numFrames > 150)
    {
        // Create trackbar.
        cv::createTrackbar("POS",
            "CORRELATION VIDEO TRACKER v" + cr::vtracker::CorrelationVideoTracker::getVersion(),
            (int*)(uint*)&g_videoPosition,
            numFrames - 1,
            videoPosPositionCallback);
    }
    
    cv::namedWindow("PATTERN", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("PATTERN", g_frameWidth + 15, 5);
	cv::namedWindow("MASK", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("MASK", g_frameWidth + 15, 165);
	cv::namedWindow("CORRELATION", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("CORRELATION", g_frameWidth + 15, 330);
	cv::namedWindow("PROBABILITY", cv::WINDOW_AUTOSIZE);
    cv::moveWindow("PROBABILITY", g_frameWidth + 15, 330 + CVT_MAXIMUM_SEARCH_WINDOW_HEIGHT + 15);

	// Main loop.
    std::chrono::time_point<std::chrono::system_clock> cycleStartTime = std::chrono::system_clock::now();
	while (true)
	{
        // Get next video frame.
        if (g_stopPlayFlag)
        {
            playbackBufferFrame.copyTo(sourceFrame);
        }
        else
        {
            g_videoSource >> sourceFrame;
            if (sourceFrame.empty())
            {
                g_videoSource.set(cv::CAP_PROP_POS_FRAMES, 1);
                continue;
            }
            sourceFrame.copyTo(playbackBufferFrame);
        }

        // Convert to grayscale.
        cv::cvtColor(sourceFrame, grayFrame, cv::COLOR_BGR2GRAY);


		// Calculate tracking.
        std::chrono::time_point<std::chrono::system_clock> trackerStartTime = std::chrono::system_clock::now();
        if (!g_tracker.processFrame(grayFrame.data, g_frameWidth, g_frameHeight, 30))
        {
            std::cout << "ERROR: Incorrect frame processing by tracker" << std::endl;
        }
        // Update processing time value.
        g_videoTrackerProcessingTime = 0.97 * g_videoTrackerProcessingTime +
                0.03 * (double)std::chrono::duration_cast<std::chrono::microseconds>(
                    std::chrono::system_clock::now() - trackerStartTime).count();
        g_trackerData = g_tracker.getTrackerResultData();

        // Copy frame to buffer.
        if (g_stopFrameFlag)
            bufferFrame.copyTo(sourceFrame);
        else
            sourceFrame.copyTo(bufferFrame);

        // Remember current frame ID.
        if (!g_stopFrameFlag)
            g_currentBufferFrameID = g_trackerData.bufferFrameID;

		// Get pattern image.
        g_tracker.getImage(cr::vtracker::CorrelationVideoTrackerImageType::PATTERN_IMAGE, trackerPatternImage.data);

		// Get mask image.
        g_tracker.getImage(cr::vtracker::CorrelationVideoTrackerImageType::MASK_IMAGE, trackerMaskImage.data);

		// Get correlation surface image.
        g_tracker.getImage(cr::vtracker::CorrelationVideoTrackerImageType::CORRELATION_SURFACE_IMAGE, trackerCorrImage.data);

		// Prepare probability image.
		memset(probabilityImage.data, 0, 256 * 256 * 3);
        g_probabilityBuffer[currentBufferIndex] = g_trackerData.objectDetectionProbability;
        g_thresholdBuffer[currentBufferIndex] = g_trackerData.probabilityAdaptiveThreshold;
        //std::cout << trackerData.objectDetectionProbability << " " << trackerData.objectLossThreshold <<  std::endl;
        float newPVal = g_probabilityBuffer[currentBufferIndex];
        float newTVal = g_thresholdBuffer[currentBufferIndex];
		uint8_t tmpBufferIndex = currentBufferIndex - 1;
        float oldPVal = g_probabilityBuffer[tmpBufferIndex];
        float oldTVal = g_thresholdBuffer[tmpBufferIndex];
		int collIndex = 0;
		while (tmpBufferIndex != currentBufferIndex)
		{
			// Draw probability chart.
			cv::line(probabilityImage,
				cv::Point(collIndex, 256 - (float)256 * newPVal),
				cv::Point(collIndex + 1, 256 - (float)256 * oldPVal),
				cv::Scalar(0, 0, 255), 1);
			// Draw adaptive threshold chart.
			cv::line(probabilityImage,
				cv::Point(collIndex, 256 - (float)256 * newTVal),
				cv::Point(collIndex + 1, 256 - (float)256 * oldTVal),
				cv::Scalar(255, 0, 0), 1);
			// Draw object loss detection threshold.
			cv::line(probabilityImage,
                cv::Point(collIndex, 256 - (float)256 * (1.0f - g_trackerData.objectLossThreshold) * newTVal),
                cv::Point(collIndex + 1, 256 - (float)256 * (1.0f - g_trackerData.objectLossThreshold) * oldTVal),
				cv::Scalar(0, 255, 0), 1);
			++collIndex;
			oldPVal = newPVal;
			oldTVal = newTVal;
			--tmpBufferIndex;
            newPVal = g_probabilityBuffer[tmpBufferIndex];
            newTVal = g_thresholdBuffer[tmpBufferIndex];
		}
        ++currentBufferIndex;

		// Draw info function.
        drawInfoFunction(sourceFrame);

		// Record video
        if (g_videoWriter != nullptr)
        {
            g_videoWriter->write(sourceFrame);
            cv::putText(sourceFrame, "RECORDING", cv::Point(g_frameWidth - 90, 15), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 0, 255));
        }

        // Resize result image.
        cv::resize(sourceFrame, resizedSourceFrame, cv::Size(g_frameWidth / g_scaleFactor, g_frameHeight / g_scaleFactor), cv::INTER_CUBIC);

		// Show images.
        cv::imshow("CORRELATION VIDEO TRACKER v" + cr::vtracker::CorrelationVideoTracker::getVersion(), resizedSourceFrame);
		cv::imshow("PATTERN", trackerPatternImage);
		cv::imshow("MASK", trackerMaskImage);
		cv::imshow("CORRELATION", trackerCorrImage);
		cv::imshow("PROBABILITY", probabilityImage);

		// Process keyboard events.
        int waitTimeMs = (int)std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::system_clock::now() - cycleStartTime).count();
        waitTimeMs = (1000.0f / g_videoSourceFps) - waitTimeMs;
        if (waitTimeMs < 0)
            waitTimeMs = 1;
        if (waitTimeMs > 30)
            waitTimeMs = 30;

        keyboardEventsFunction(cv::waitKey(1));
        std::this_thread::sleep_for(std::chrono::milliseconds(waitTimeMs));
        cycleStartTime = std::chrono::system_clock::now();
	}

	return 1;
}



// Mouse callback function.
void mouseCallBackFunction(int event, int x, int y, int flags, void* userdata)
{
	// Update mouse position.
    g_mousePositionX = x * g_scaleFactor;
    if (g_mousePositionX - g_trackerData.trackingRectangleWidth / 2 < 1)
        g_mousePositionX = g_trackerData.trackingRectangleWidth / 2 + 1;
    if (g_mousePositionX + g_trackerData.trackingRectangleWidth / 2 > g_frameWidth - 1)
        g_mousePositionX = g_frameWidth - g_trackerData.trackingRectangleWidth / 2 - 1;
    g_mousePositionY = y * g_scaleFactor;
    if (g_mousePositionY - g_trackerData.trackingRectangleHeight / 2 < 1)
        g_mousePositionY = g_trackerData.trackingRectangleHeight / 2 + 1;
    if (g_mousePositionY + g_trackerData.trackingRectangleHeight / 2 > g_frameHeight - 1)
        g_mousePositionY = g_frameHeight - g_trackerData.trackingRectangleHeight / 2 - 1;

	// Check ivent.
	switch (event)
	{
	case cv::EVENT_LBUTTONDOWN: // Capture/Reset function
        if (g_trackerData.mode == CVT_FREE_MODE_INDEX)
		{
			/*
			Capture object if tracker is free.
			last parameter is frame ID of last displayed frame (for STOP-FRAME function).
			*/
            g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::CAPTURE,
                                     g_mousePositionX, g_mousePositionY, g_currentBufferFrameID);
			
			// Reset buffers for charts.
            memset(g_probabilityBuffer, 0, 256 * sizeof(float));
            memset(g_thresholdBuffer, 0, 256 * sizeof(float));

            g_stopFrameFlag = false;
            g_stopPlayFlag = false;
		}
		else
		{
			// Reset tracker if tracker no in FREE mode.
            g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::RESET);

            g_stopFrameFlag = false;
            g_stopPlayFlag = false;
		}
		break;
	case cv::EVENT_RBUTTONDOWN:	break;
	case cv::EVENT_MBUTTONDOWN:	break;
	case cv::EVENT_MOUSEMOVE:	break;
    }
}



// Draw info.
void drawInfoFunction(cv::Mat& frame)
{
	// Check video tracker mode. We draw video tracker data only in tracking modes.
    if (g_trackerData.mode != CVT_FREE_MODE_INDEX)
	{
		// Choose a color for tracking the rectangle depending on mode.
		cv::Scalar strobColor;
        if (g_trackerData.mode == CVT_TRACKING_MODE_INDEX)
			strobColor = cv::Scalar(0, 0, 255);
        if (g_trackerData.mode == CVT_LOST_MODE_INDEX)
			strobColor = cv::Scalar(255, 0, 0);
        if (g_trackerData.mode == CVT_INERTIAL_MODE_INDEX)
			strobColor = cv::Scalar(0, 255, 0);
        if (g_trackerData.mode == CVT_STATIC_MODE_INDEX)
			strobColor = cv::Scalar(255, 255, 0);

		// Calculate tracking rectangle.
        cv::Rect strobeRect(g_trackerData.trackingRectangleCenterX - g_trackerData.trackingRectangleWidth / 2,
            g_trackerData.trackingRectangleCenterY - g_trackerData.trackingRectangleHeight / 2,
            g_trackerData.trackingRectangleWidth, g_trackerData.trackingRectangleHeight);
		// Calculate object rectangle.
        cv::Rect objectRect(g_trackerData.objectCenterX - g_trackerData.objectWidth / 2,
            g_trackerData.objectCenterY - g_trackerData.objectHeight / 2,
            g_trackerData.objectWidth, g_trackerData.objectHeight);
		// Calculate search window rectangle.
        int32_t windW = g_trackerData.searchWindowWidth;
        int32_t windH = g_trackerData.searchWindowHeight;
        int32_t windX0 = g_trackerData.trackingRectangleCenterX - windW / 2;
        int32_t windY0 = g_trackerData.trackingRectangleCenterY - windH / 2;
		cv::Rect windowRect(windX0, windY0, windW, windH);

        // Draw object rectangle.
        cv::rectangle(frame, objectRect, cv::Scalar(255, 255, 255), g_scaleFactor);
		// Draw tracking rectangle.
        cv::rectangle(frame, strobeRect, strobColor, 2 * g_scaleFactor);
		// Draw search windows rectangle.
        //cv::rectangle(frame, windowRect, cv::Scalar(0, 0, 0), g_scaleFactor);

		// Draw tracking rectangle position.
        std::string str = "P(" + std::to_string(g_trackerData.trackingRectangleCenterX) + ":" +
            std::to_string(g_trackerData.trackingRectangleCenterY) + ")";
		cv::putText(frame, str, cv::Point(strobeRect.x, strobeRect.y - 25), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(255, 255, 0));
		// Draw tracking rectangle size and objec velocity.
        str = "S(" + std::to_string(g_trackerData.trackingRectangleWidth) + ":" + std::to_string(g_trackerData.trackingRectangleHeight) + ")";
		cv::putText(frame, str, cv::Point(strobeRect.x, strobeRect.y + strobeRect.height + 15), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(255, 255, 0));
        str = "V(" + std::to_string((int)g_trackerData.horizontalObjectVelocity) + ":" + std::to_string((int)g_trackerData.verticalObjectVelocity) + ")";
		cv::putText(frame, str, cv::Point(strobeRect.x, strobeRect.y + strobeRect.height + 35), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(255, 255, 0));
		// Draw tracker mode.
        switch (g_trackerData.mode)
		{
		case CVT_FREE_MODE_INDEX: str = "FREE"; break;
		case CVT_TRACKING_MODE_INDEX: str = "TRACKING"; break;
		case CVT_LOST_MODE_INDEX: str = "LOST"; break;
		case CVT_INERTIAL_MODE_INDEX: str = "INERTIAL"; break;
		case CVT_STATIC_MODE_INDEX: str = "STATIC"; break;
		default: str = "UNDEFINED"; break;
		}
		cv::putText(frame, str, cv::Point(strobeRect.x, strobeRect.y - 5), cv::FONT_HERSHEY_SIMPLEX, 0.5, strobColor);
		// Draw center of tracking rectangle.
        if (g_trackerData.mode == CVT_TRACKING_MODE_INDEX)
		{
            cv::line(frame, cv::Point(g_trackerData.trackingRectangleCenterX - 10, g_trackerData.trackingRectangleCenterY),
                cv::Point(g_trackerData.trackingRectangleCenterX + 10, g_trackerData.trackingRectangleCenterY),
				cv::Scalar(255, 255, 255));
            cv::line(frame, cv::Point(g_trackerData.trackingRectangleCenterX, g_trackerData.trackingRectangleCenterY - 10),
                cv::Point(g_trackerData.trackingRectangleCenterX, g_trackerData.trackingRectangleCenterY + 10),
				cv::Scalar(255, 255, 255));

            cv::circle(frame, cv::Point(g_trackerData.trackingRectangleCenterX + (int32_t)(g_trackerData.horizontalObjectVelocity * 2.0f),
                g_trackerData.trackingRectangleCenterY + (int32_t)(g_trackerData.verticalObjectVelocity * 2.0f)), 2,
				cv::Scalar(255, 255, 0), cv::FILLED);
		}
	}
	else
	{
		// In FREE mode draw only capture rectangle.
        cv::rectangle(frame, cv::Rect(g_mousePositionX - g_trackerData.trackingRectangleWidth / 2,
            g_mousePositionY - g_trackerData.trackingRectangleHeight / 2,
            g_trackerData.trackingRectangleWidth, g_trackerData.trackingRectangleHeight),
            cv::Scalar(255, 255, 255), g_scaleFactor);
	}

	// Draw tracker processing time.
    cv::putText(frame, "TRACKER PROCESSING TIME: " + std::to_string((float)g_videoTrackerProcessingTime / 1000.0f) + " ms", cv::Point(5, 15), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 0, 255));

    // Draw stabilization flag.
    if (g_videoStabilizerEnableFlag == true)
        cv::putText(frame, "STABILIZATION PROCESSING TIME " + std::to_string((float)g_videoStabilizerProcessingTime / 1000.0f) + " ms", cv::Point(5, 35), cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(255, 255, 0));
}



// Keyboard events processing function.
void keyboardEventsFunction(int key)
{
	// Check returned value from cv::waitKey(...) function.
	switch (key) {

	case 27:// ESC - EXIT.
		std::cout << "EXIT" << std::endl;
        if (g_videoWriter != nullptr)
            g_videoWriter->release();
		exit(0);

	case 112:// P - Set INERTIAL mode.
        if (g_trackerData.mode != CVT_INERTIAL_MODE_INDEX)
		{
            g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::SET_INERTIAL_MODE);
		}
		else
		{
            g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::SET_LOST_MODE);
		}
		break;

	case 119:// W - Increase tracking rectangle vertical size.
        g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::TRACKING_RECTANGLE_HEIGHT,
                              (double)g_trackerData.trackingRectangleHeight + 8);
		break;

	case 115:// S - Decrease tracking rectangle vertical size.
        g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::TRACKING_RECTANGLE_HEIGHT,
                              (double)g_trackerData.trackingRectangleHeight - 8);
		break;

	case 100:// D - Increase tracking rectangle horizontal size.
        g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::TRACKING_RECTANGLE_WIDTH,
                              (double)g_trackerData.trackingRectangleWidth + 8);
		break;

	case 97:// A - Decrease tracking rectangle horizontal size.
        g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::TRACKING_RECTANGLE_WIDTH,
                              (double)g_trackerData.trackingRectangleWidth - 8);
		break;

	case 116:// T - Move strobe UP (change position in TRACKING mode).
        g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::MOVE_TRACKING_RECTANGLE, 0, 4);
		break;

	case 103:// G - Move strobe DOWN (change position in TRACKING mode).
        g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::MOVE_TRACKING_RECTANGLE, 0, -4);
		break;

	case 104:// H - Move strobe RIGHT (change position in TRACKING mode).
        g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::MOVE_TRACKING_RECTANGLE, -4, 0);
		break;

	case 102:// F - Move strobe LEFT (change position in TRACKING mode).
        g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::MOVE_TRACKING_RECTANGLE, 4, 0);
		break;

	case 114:// R - Start/stop video recording.
        if (g_videoWriter != nullptr)
        {
            g_videoWriter->release();
            g_videoWriter = nullptr;
		}
		else {
			std::string videoFileName = "record_" + getDayTimeString() + ".avi";
            g_videoWriter = new cv::VideoWriter(videoFileName, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'), 30,
                                                cv::Size(g_frameWidth, g_frameHeight), true);
            assert(g_videoWriter != 0);
        }
		break;

	case 113: // Q - autosize of tracking rectangle.
        g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::SET_TRACKING_RECTANGLE_AUTO_SIZE);
		break;

    case 101: // E - set of tracking rectangle position to object center.
        g_tracker.executeCommand(cr::vtracker::CorrelationVideoTrackerCommand::SET_TRACKING_RECTANGLE_AUTO_POSITION);
        break;

	case 32: // SPACE - on/off STOP-FRAME mode.
	{
        if (g_stopFrameFlag == false)
            g_stopFrameFlag = true;
		else
            g_stopFrameFlag = false;
	}		
		break;

    case 13: // ENTER - on/off stop playback mode.
    {
        g_stopPlayFlag = !g_stopPlayFlag;
        break;
    }

	default:
		return;
	}
}



// Function to get current time string
std::string getDayTimeString()
{
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);

    std::stringstream ss;
    ss << std::put_time(std::localtime(&in_time_t), "%d_%m_%Y_%H_%M_%S");
    std::string str = ss.str();

    return str;
}



// Function to load tracker params.
bool loadAndInitParams()
{
    // Init config reader.
    ConfigReader config = ConfigReader();
    const std::string configFileName = "CorrelationVideoTrackerDemoApplication.json";

    // Open config json file (if not exist - create new and exit).
    if(!config.readFromFile(configFileName))
    {
        std::cout << "ERROR: Config file not loaded" << std::endl;
        return -1;
    }

    // Read correlation video tracker params.
    CorrelationVideoTrackerParams videoTrackerParams;
    if(!config.get(videoTrackerParams, "CorrelationVideoTrackerParams"))
    {
        std::cout << "ERROR: Video tracker params not read" << std::endl;
        return -1;
    }

    // Read video source params.
    VideoSourceParams videoSourceParams;
    if(!config.get(videoSourceParams, "VideoSourceParams"))
    {
        std::cout << "ERROR: Video source params not read" << std::endl;
        return -1;
    }

    // Init video source.
    if (videoSourceParams.videoSourceInitString == "file dialog")
    {
        NFD_Init();

        nfdchar_t *outPath;
        nfdresult_t result = NFD_OpenDialog(&outPath, NULL, 0, NULL);
        if ( result == NFD_OKAY )
        {
            if(!g_videoSource.open(std::string(outPath)))
            {
                std::cout << "ERROR: Video file not open" << std::endl;

                NFD_FreePath(outPath);
                NFD_Quit();

                return false;
            }
            NFD_FreePath(outPath);
        }
        else if ( result == NFD_CANCEL )
        {
            std::cout << "ERROR: Video file not open" << std::endl;

            NFD_FreePath(outPath);
            NFD_Quit();

            return false;
        }
        else
        {
            printf("Error: %s\n", NFD_GetError() );

            NFD_FreePath(outPath);
            NFD_Quit();

            return false;
        }

        NFD_Quit();
    }
    else
    {
        if (!g_videoSource.open(videoSourceParams.videoSourceInitString))
        {
           std::cout << "ERROR: Video source " << videoSourceParams.videoSourceInitString << " not open" << std::endl;
           return -1;
        }
    }
    g_scaleFactor = videoSourceParams.scaleFactor;

    // Set video tracker params.
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::FRAME_BUFFER_SIZE, videoTrackerParams.frameBufferSize);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::TRACKING_RECTANGLE_WIDTH, videoTrackerParams.trackingRectangleWidth);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::TRACKING_RECTANGLE_HEIGHT, videoTrackerParams.trackingRectangleHeight);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::PIXEL_DEVIATION_THRESHOLD, videoTrackerParams.pixelDeviationThreshold);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::OBJECT_LOSS_THRESHOLD, videoTrackerParams.objectLossThreshold);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::OBJECT_DETECTION_THRESHOLD, videoTrackerParams.objectDetectionThreshold);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::PATTERN_UPDATE_COEFF, videoTrackerParams.patternUpdateCoeff);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::PROBABILITY_UPDATE_COEFF, videoTrackerParams.probabilityUpdateCoeff);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::SEARCH_WINDOW_WIDTH, videoTrackerParams.searchWindowWidth);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::SEARCH_WINDOW_HEIGHT, videoTrackerParams.searchWindowHeight);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::LOST_MODE_OPTION, videoTrackerParams.lostModeOption);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::MAXIMUM_NUM_FRAMES_IN_LOST_MODE, videoTrackerParams.maximumNumFramesInLostMode);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::USE_PREDICTED_POSITION, videoTrackerParams.usePredictedPosition ? 1.0 : 0.0);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::USE_TRACKING_RECTANGLE_AUTO_POSITION, videoTrackerParams.useTrackingRectangleAutoPosition ? 1.0 : 0.0);
    g_tracker.setProperty(cr::vtracker::CorrelationVideoTrackerProperty::USE_TRACKING_RECTANGLE_AUTO_SIZE, videoTrackerParams.useTrackingRectangleAutoSize ? 1.0 : 0.0);

	return true;
}
