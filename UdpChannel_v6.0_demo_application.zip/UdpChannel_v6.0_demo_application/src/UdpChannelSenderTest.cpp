#include <iostream>
#include <cstring>
#include <thread>
#include <ctime>
#include <chrono>
#include <fstream>

#include "UdpChannel.h"
#include "UdpSocket.h"
#include "ConfigReader.h"
#include "Tracer.h"


using namespace cr::clib;
using namespace cr::utils;


// Class to read JSON configuration file.
class Params : public InitParamsBase {
public:
    // UdpChannel
    std::string dstIp;              // Destination IP.
    uint16_t hostUdpPort;           // Input UDP port only for receiving.
    uint16_t dstUdpPort;            // Output UDP port only for sending.

    // Setvice UDP port.
    uint16_t serviceUdpPort;        // Service UDP port.

    // Other
    double channelBaudrateMbps;      // Communication channel baudrate.
    uint32_t normalDataSize;         // Normal data size.
    uint32_t peakDataSize;           // Peak data size.
    uint32_t peakDataPeriod;         // Peak data period.
    uint32_t resendsCount;           // Number of repetitions.
    uint32_t dataPeriodUsec;         // Data period in microsecond [Usec].
    int32_t waitConfirmationTimeoutMs;// Timeout to wait confirmation (-1 - no wait).

    void createInitList() {
        initList.clear();
        initList.push_back(dstIp);
        initList.push_back(std::to_string(hostUdpPort));
        initList.push_back(std::to_string(dstUdpPort));
    }

    JSON_READABLE(Params, dstIp, hostUdpPort, dstUdpPort, serviceUdpPort,
                  channelBaudrateMbps, normalDataSize, peakDataSize,
                  peakDataPeriod, resendsCount, dataPeriodUsec, waitConfirmationTimeoutMs);
};



// Entry point.
int main(void)
{
    std::cout<<"=================================================" << std::endl;
    std::cout<<"UdpChannelSenderTest " << "2.0.0"                  << std::endl;
    std::cout<<"=================================================" << std::endl;
    std::cout<<"Submodule versions: "                              << std::endl;
    std::cout<<"ConfigReader:......"<< ConfigReader::getVersion()  << std::endl;
    std::cout<<"UdpChannel:........"<< UdpChannel::getVersion()    << std::endl;
    std::cout<<"UdpSocket:........."<< UdpSocket::getVersion()     << std::endl;
    std::cout<<"-------------------------------------------------" << std::endl;

    // Read configuration file.
    Params params = Params();
    ConfigReader config = ConfigReader();
    const std::string configFileName = "UdpChannelSenderTest.json";

    // Open config json file (if not exist - create new and exit)
    if(!config.readFromFile(configFileName)) {
        std::cout << "ERROR: Config file not loaded" << std::endl;
        config.set(params, "Params"); config.writeToFile(configFileName);
        return -1;
    }

    // Read values and set to params
    if(!config.get(params, "Params")) {
        std::cout << "ERROR: Params were not read" << std::endl;
        return -1;
    }

    // Init UdpChannel
    params.createInitList();
    std::shared_ptr<UdpChannel> channel(new UdpChannel());
    if (!channel->init(params.toInitString()))
    {
        std::cout << "ERROR: UDP channel not init" << std::endl;
        return -1;
    }

    // Init service UDP socket.
    UdpSocket serviceUdpSocket(false);
    if (!serviceUdpSocket.setDstAddr(params.dstIp, params.serviceUdpPort))
    {
        std::cout << "ERROR: IP address not set" << std::endl;
        return -1;
    }
    if (!serviceUdpSocket.open())
    {
        std::cout << "ERROR: UDP service socet not init" << std::endl;
        return -1;
    }


    // Init data buffer.
    uint8_t* normalData = new uint8_t[params.normalDataSize];
    uint8_t* peakData = new uint8_t[params.peakDataSize];

    // Fill data by fandom values.
    for (uint32_t i = 0; i < params.normalDataSize; ++i)
    {
        normalData[i] = (uint8_t)(rand() % 255);
    }
    for (uint32_t i = 0; i < params.peakDataSize; ++i)
    {
        peakData[i] = (uint8_t)(rand() % 255);
    }

	// Main loop.
    uint32_t data_counter = 0;
    uint8_t data_value = 0;
    bool isConfirmed = params.waitConfirmationTimeoutMs > 0 ? true : false;
    std::chrono::time_point<std::chrono::system_clock> cycle_start_time = std::chrono::system_clock::now();
	while (true)
	{
        // Prepare data.
        uint8_t* p_data = nullptr;
        uint32_t output_size = 0;
        if (data_counter == params.peakDataPeriod)
        {
            p_data = &peakData[0];
            output_size = params.peakDataSize;
        }
        else
        {
            p_data = &normalData[0];
            output_size = params.normalDataSize;
        }
        ++data_counter;
        if (data_counter > params.peakDataPeriod)
            data_counter = 0;

        // Update data index.
        p_data[0] = data_value;
        ++data_value;

        // Send 1 byte of data value. Twice.
        serviceUdpSocket.sendData(p_data, 1);
        serviceUdpSocket.sendData(p_data, 1);

        // Send data.
        if (isConfirmed)
        {
            std::chrono::time_point<std::chrono::system_clock> startTime = std::chrono::system_clock::now();
            if (!channel->sendData(p_data, output_size, 0, params.resendsCount,
                                  params.channelBaudrateMbps, params.waitConfirmationTimeoutMs)) {
                std::cout << "Confirmation not received" << std::endl;
                //TRACE(g_tracer, SHORT_PRINT, EXCEPTION, "%s\n", "Confirmation not received");
            }
            else
            {
                uint32_t deliveryTimeMs = (uint32_t)std::chrono::duration_cast<std::chrono::milliseconds>(
                                std::chrono::system_clock::now() - startTime).count();
                std::cout << "ID:" << (int)data_value << " size:" << output_size <<
                          " delivery time with confirmation " << deliveryTimeMs << " ms"<< std::endl;
            }
        }
        else
        {
            if (!channel->sendData(p_data, output_size, 0, params.resendsCount,
                                  params.channelBaudrateMbps, params.waitConfirmationTimeoutMs)) {
                std::cout << "Send data problem" << std::endl;
            }
            else
            {
                std::cout << "ID:" << (int)data_value << " size:" << output_size << std::endl;
            }
        }

		// Wait for next data portion.
        while (params.dataPeriodUsec > (uint32_t)std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::system_clock::now() - cycle_start_time).count())
        {
            // Random operations.
            uint8_t tmp = normalData[0];
            ++tmp;
        }

        // Update cycle start time.
        cycle_start_time = std::chrono::system_clock::now();
	}

	return 1;
}


