#include <iostream>
#include <cstring>
#include <thread>
#include <ctime>
#include <chrono>
#include <fstream>

#include "UdpChannel.h"
#include "ConfigReader.h"
#include "Tracer.h"

using namespace cr::clib;
using namespace cr::utils;

class Params : public InitParamsBase {
public:
    // UdpChannel
    std::string dstIp;                // Destination IP.
    uint16_t hostUdpPort;             // Input UDP port only for receiving.
    uint16_t dstUdpPort;              // Output UDP port only for sending.

    // Other
    uint32_t waitDataTimeoutMsec;     // wait period in millisecond [msec].
    uint16_t serviceUdpPort;          // Service UDP port.

    void createInitList() {
        initList.clear();
        initList.push_back(dstIp);
        initList.push_back(std::to_string(hostUdpPort));
        initList.push_back(std::to_string(dstUdpPort));
    }

    JSON_READABLE(Params, dstIp, hostUdpPort, dstUdpPort, waitDataTimeoutMsec, serviceUdpPort);
};

// Global variables.
UdpSocket serviceUdpSocket(true);
std::atomic<std::chrono::time_point<std::chrono::system_clock>> g_timePoints[256];


// Function prototype for receiving thread.
void readThreadFunc();


// Entry point.
int main(void)
{
    std::cout<<"=================================================" << std::endl;
    std::cout<<"UdpChannelReceiverTest " << "2.0.0"                << std::endl;
    std::cout<<"=================================================" << std::endl;
    std::cout<<"Submodule versions: "                              << std::endl;
    std::cout<<"ConfigReader......."<< ConfigReader::getVersion()  << std::endl;
    std::cout<<"UdpChannel:........"<< UdpChannel::getVersion()    << std::endl;
    std::cout<<"UdpSocket:........."<< UdpSocket::getVersion()     << std::endl;
    std::cout<<"-------------------------------------------------" << std::endl;

    Tracer::setTraceLevel(DEBUG, "UdpChannel");

    Params params = Params();
    ConfigReader config = ConfigReader();
    std::shared_ptr<UdpChannel> channel(new UdpChannel());
    const std::string configFileName = "UdpChannelReceiverTest.json";

    // Open config json file (if not exist - create new and exit)
    if(!config.readFromFile(configFileName)) {
        std::cout << "ERROR: Config file not loaded" << std::endl;
        config.set(params, "Params"); config.writeToFile(configFileName);
        return -1;
    }

    // Read values and set to params
    if(!config.get(params, "Params")) {
        std::cout << "ERROR: Params were not read" << std::endl;
        return -1;
    }

    // Init UdpChannel.
    params.createInitList();
    if (!channel->init(params.toInitString()))
    {
        std::cout << "ERROR: UDP channel not init" << std::endl;
        return -1;
    }

    // Init service UDP port.
    if (!serviceUdpSocket.setHostAddr("0.0.0.0", params.serviceUdpPort))
    {
        std::cout << "ERROR: UDP service socket destination IP not set" << std::endl;
        return -1;
    }
    if (!serviceUdpSocket.open())
    {
        std::cout << "ERROR: UDP service socket not init" << std::endl;
        return -1;
    }

    // Remember start time.
    for (uint32_t i = 0; i < 256; ++i)
        g_timePoints[i].store(std::chrono::system_clock::now());

    // Launch read thread.
    std::thread readThread(&readThreadFunc);

    // Init data buffer.
    uint32_t maxDataSize = 10000000;
    uint8_t* inputData = new uint8_t[maxDataSize];

	// Main loop.
    int32_t oldDataValue = 0;
    int32_t lostDataCounter = 0;
    uint8_t dataPartCounter = 0;
	while (true)
	{
        // Wait new data.
        int32_t logicPort = 0;
        uint32_t inputDataSize = 0;
        if (channel->getData(inputData, maxDataSize, inputDataSize, logicPort, params.waitDataTimeoutMsec))
		{
            // Calculte local delivery time.
            uint32_t deliveryTimeMs = (uint32_t)std::chrono::duration_cast<std::chrono::milliseconds>(
                            std::chrono::system_clock::now() - g_timePoints[inputData[0]].load()).count();
            std::cout << "ID:" << (int)inputData[0] << " size:" << inputDataSize << " delivery time:" << deliveryTimeMs << " ms" << std::endl;

            // Get new data value.
            int32_t newDataValue = (int32_t)inputData[0];

            // Compare input data value.
            if (newDataValue - oldDataValue > 1)
            {
                lostDataCounter += newDataValue - oldDataValue - 1;
                //std::cout << lostDataCounter << " data lost" << std::endl;
            }
            else
            {
                if (newDataValue - oldDataValue != -255 && newDataValue < oldDataValue)
                {
                    lostDataCounter += (255 - oldDataValue) + newDataValue;
                    //std::cout << lostDataCounter << " data lost" << std::endl;
                }

            }
            oldDataValue = newDataValue;

            ++dataPartCounter;
            if (dataPartCounter == 255)
            {
                std::cout << "Recieved 256 data parts and lost " << lostDataCounter << " parts" << std::endl;
                lostDataCounter = 0;
            }
		}
        else
        {
            std::cout << "no data" << std::endl;
        }


	}

	return 1;
}


void readThreadFunc()
{
    // Init variables.
    uint8_t buff[1] = {0};

    // Thread loop.
    while (true)
    {
        // Wait input data.
        int bytes = serviceUdpSocket.readData(buff, sizeof(buff));

        // Check data size.
        if (bytes == 1)
        {
            g_timePoints[buff[0]].store(std::chrono::system_clock::now());
        }
    }
}



