#include <iostream>
#include <chrono>
#include <cstdint>
#include <string.h>
#include <opencv2/opencv.hpp>
#include "Dehazer.h"
#include "SimpleFileDialog.h"



// Level.
int g_level{0};
// Dehazer.
cr::video::Dehazer g_dehazer;
/// ROI (Detection mask) top-left X coordinate.
int g_roiX0{ 0 };
/// ROI (Detection mask) top-left Y coordinate.
int g_roiY0{ 0 };
/// ROI (Detection mask) bottom-right X coordinate.
int g_roiX1{ 0 };
/// ROI (Detection mask) bottom-right Y coordinate.
int g_roiY1{ 0 };
/// Draw ROI (Detection mask) flag.
bool g_drawRoi{ false };
/// Display image.
cv::Mat g_displayImg;



/// Mouse callback function to apply detection mask.
void applyDetectionMask(int event, int x, int y, int flags, void* userdata)
{
    // We have mixed video (source + mask). So, we have to limit coordinate
    // of detection ROI.
    if (y > g_displayImg.size().height / 2)
    {
       y = g_displayImg.size().height / 2;
    }

    switch (event)
    {
    case cv::EVENT_LBUTTONDOWN:
    {
        g_drawRoi = true;
        g_roiX0 = x;
        g_roiY0 = y;
        g_roiX1 = x;
        g_roiY1 = y;
        break;
    }
    case cv::EVENT_RBUTTONDOWN: break;
    case cv::EVENT_LBUTTONUP:
    {
        g_drawRoi = false;
        g_roiX1 = x;
        g_roiY1 = y;
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
        {
            // Create mask image.
            cr::video::Frame maskFrame(g_displayImg.size().width,
                g_displayImg.size().height / 2, cr::video::Fourcc::GRAY);
            cv::Mat maskImg(g_displayImg.size().height / 2, g_displayImg.size().width,
                CV_8UC1, maskFrame.data);
            cv::rectangle(maskImg, cv::Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                g_roiY1 - g_roiY0 + 1),
                cv::Scalar(255, 255, 255), cv::FILLED);

            // Set detection mask.
            g_dehazer.setMask(maskFrame);
        }
        break;
    }
    case cv::EVENT_MBUTTONDOWN:	break;
    case cv::EVENT_MOUSEMOVE:
    {
        if (g_drawRoi && x > g_roiX0 && y > g_roiY0)
        {
            g_roiX1 = x;
            g_roiY1 = y;
        }
        break;
    }
    }
}



static void levelCalback(int, void*)
{
    g_dehazer.setParam(cr::video::VFilterParam::LEVEL, static_cast<float>(g_level));
}



int main(void)
{
    std::cout << "Dehazer v" << cr::video::Dehazer::getVersion() << " demo app" << std::endl;

    // Chose source.
    std::string source = "";
    std::cout << "File dialog (y/n) ? : ";
    std::cin >> source;
    if (source == "y" || source == "Y")
    {
        source = cr::utils::SimpleFileDialog::dialog();
    }
    else
    {
        std::cout << "Enter video source init string "
             << "(camera num, rtsp string, video file): ";
        std::cin >> source;
    }

    // Open video source.
    cv::VideoCapture videoSource;
    if (source.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(source)))
        {
            std::cout << "ERROR: Camera not open" << std::endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(source))
        {
            std::cout << "ERROR: Video source not open" << std::endl;
            return -1;
        }
    }

    // Get frame size.
    int width = (int)videoSource.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = (int)videoSource.get(cv::CAP_PROP_FRAME_HEIGHT);

    // Init frames.
    cv::Mat frameOpenCvBgr(height, width, CV_8UC3);
    cv::Mat resultOpenCvBgr(height, width, CV_8UC3);
    cv::Mat mixOpenCvBgr(height * 2, width, CV_8UC3);
    cr::video::Frame frame(width, height, cr::video::Fourcc::YUV24);

    // Video writer for result video.
    cv::VideoWriter* dstWriter = nullptr;
    // Video writer for mix video.
    cv::VideoWriter* mixWriter = nullptr;

    // Create window.
    std::string windowName = "Dehazer v" + cr::video::Dehazer::getVersion();
    cv::namedWindow(windowName, cv::WINDOW_AUTOSIZE);
    cv::createTrackbar("Level", windowName, &g_level, 100, &levelCalback);
    // Register mouse callback function for ROI control.
    cv::setMouseCallback(windowName, applyDetectionMask);

    // Set initial trackbar position.
    g_level = (int)g_dehazer.getParam(cr::video::VFilterParam::LEVEL);
    cv::setTrackbarPos("Level", windowName, g_level);

    // Set default params for demo application.
    g_dehazer.setParam(cr::video::VFilterParam::TYPE, 1);
    g_dehazer.setParam(cr::video::VFilterParam::MODE, 1);

    // Main loop.
    cr::video::VFilterParams params;
    while (true)
    {
        // Capture next video frame.
        videoSource >> frameOpenCvBgr;
        if (frameOpenCvBgr.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(cv::CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR to YUV.
        cv::Mat frameOpenCvYuv(frame.height, frame.width, CV_8UC3, frame.data);
        cvtColor(frameOpenCvBgr, frameOpenCvYuv, cv::COLOR_BGR2YUV);

        // Dehaze.
        g_dehazer.processFrame(frame);

        // Get params.
        g_dehazer.getParams(params);

        // Convert YUV to BGR.
        cvtColor(frameOpenCvYuv, resultOpenCvBgr, cv::COLOR_YUV2BGR);

        // Create mix image.
        memcpy(&mixOpenCvBgr.data[0], &frameOpenCvBgr.data[0], frame.size);
        memcpy(&mixOpenCvBgr.data[height * width * 3], &resultOpenCvBgr.data[0], frame.size);

        // Resize mix video if necessary to fit display.
        if (mixOpenCvBgr.size().height > 860)
        {
            int dstHeight = 860;
            int dstWidth = (int)(width * (float)dstHeight / (height * 2));
            resize(mixOpenCvBgr, g_displayImg, cv::Size(dstWidth, dstHeight));
        }
        else
        {
            mixOpenCvBgr.copyTo(g_displayImg);
        }

        int pos = 25;
        std::string str = "[1] Type: " + std::to_string(params.type);
        cv::putText(g_displayImg, str, cv::Point(5, pos), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        cv::putText(g_displayImg, str, cv::Point(6, pos + 1), cv::FONT_HERSHEY_SIMPLEX, 0.6,
            cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
        pos += 25;

        str = "Processing time: " + std::to_string(params.processingTimeMcSec) + " msec";
        putText(g_displayImg, str, cv::Point(5, pos),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, pos + 1),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
        pos += 25;
        std::cout << str << std::endl;
        // Record video.
        if (dstWriter != nullptr)
        {
            // Record result video.
            dstWriter->write(resultOpenCvBgr);
            // Record mix video.
            mixWriter->write(mixOpenCvBgr);
            // Show "RECORDING" message.
            putText(g_displayImg, "RECORDING: R to stop", cv::Point(5, pos),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
            putText(g_displayImg, "RECORDING: R to stop", cv::Point(6, pos + 1),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 255), 1, cv::LINE_AA);
        }
        else
        {
            putText(g_displayImg, "R to start recording", cv::Point(5, pos),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
            putText(g_displayImg, "R to start recording", cv::Point(6, pos + 1),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255),1, cv::LINE_AA);
        }

        pos += 25;

        if (params.mode == 0)
        {
            str = "SPACE to enable dehazer";
            putText(g_displayImg, str, cv::Point(5, pos),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
            putText(g_displayImg, str, cv::Point(6, pos + 1),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
        }
        else
        {
            str = "SPACE to disable dehazer";
            putText(g_displayImg, str, cv::Point(5, pos),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
            putText(g_displayImg, str, cv::Point(6, pos + 1),
                cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
        }

        str = "RESULT";
        putText(g_displayImg, str, cv::Point(5, g_displayImg.size().height - 10),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, g_displayImg.size().height - 9),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
        str = "SOURCE";
        putText(g_displayImg, str, cv::Point(5, g_displayImg.size().height / 2 - 10),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
        putText(g_displayImg, str, cv::Point(6, g_displayImg.size().height / 2 - 9),
            cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);

        // Draw ROI.
        if (g_roiX1 > g_roiX0 && g_roiY1 > g_roiY0)
        {
            cv::rectangle(g_displayImg,
                cv::Rect(g_roiX0, g_roiY0, g_roiX1 - g_roiX0 + 1,
                    g_roiY1 - g_roiY0 + 1),
                cv::Scalar(255, 255, 0), 1);
        }

        // Show results.
        imshow(windowName, g_displayImg);

        // Process keyboard events.
        switch (cv::waitKey(24))
        {
        // ESC - exit.
        case 27:
        {
            if (dstWriter != nullptr)
            {
                dstWriter->release();
                mixWriter->release();
            }
            exit(0);
        }
        // T - Change type of dehazer.
        case 49:
        {
            g_dehazer.setParam(cr::video::VFilterParam::TYPE, static_cast<float>(1 - params.type));
            break;
        }
        
        // SPACE - reset video stabilizer.
        case 32:
        {
            g_dehazer.setParam(cr::video::VFilterParam::MODE, static_cast<float>(1 - params.mode));
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (dstWriter != nullptr)
            {
                dstWriter->release();
                dstWriter = nullptr;
                mixWriter->release();
                mixWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                std::ostringstream oss;
                oss << std::put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                std::string dateAndTime = oss.str();
                std::string videoFileName = "dst_" + dateAndTime + ".avi";
                std::cout << "Created: " << videoFileName << std::endl;
                dstWriter = new cv::VideoWriter(videoFileName,
                    cv::VideoWriter::fourcc('M','J','P','G'), 30,
                resultOpenCvBgr.size(), true);
                assert(dstWriter != 0);
                videoFileName = "mix_" + oss.str() + ".avi";
                std::cout << "Created: " << videoFileName << std::endl;
                mixWriter = new cv::VideoWriter(videoFileName,
                    cv::VideoWriter::fourcc('M','J','P','G'), 30,
                mixOpenCvBgr.size(), true);
                assert(mixWriter != 0);
            }
            break;
        }
        }
    }

    return 1;
}