#include <iostream>
#include <chrono>
#include <cstdint>
#include <string.h>
#include <opencv2/opencv.hpp>
#include "Dehazer.h"
#include "SimpleFileDialog.h"



// Link namespaces.
using namespace cv;
using namespace std;
using namespace cr::video;
using namespace cr::utils;
using namespace cr::dehaze;



// Level.
int g_level{0};
// Dehazer.
Dehazer g_dehazer;



static void levelCalback( int, void* )
{
    g_dehazer.setParam(DehazerParam::LEVEL, (float)g_level);
}



// Entry point.
int main(void)
{
    cout << "Dehazer v" << Dehazer::getVersion() << " demo app" << endl << endl;

    // Chose source.
    string source = "";
    cout << "File dialog (y/n) ? : ";
    cin >> source;
    if (source == "y" || source == "Y")
    {
        source = SimpleFileDialog::dialog();
    }
    else
    {
        cout << "Enter video source init string "
             << "(camera num, rtsp string, video file): ";
        cin >> source;
    }

    // Open video source.
    VideoCapture videoSource;
    if (source.size() < 4)
    {
        // Open camera.
        if (!videoSource.open(stoi(source)))
        {
            cout << "ERROR: Camera not open" << endl;
            return -1;
        }
    }
    else
    {
        // Open video source.
        if (!videoSource.open(source))
        {
            cout << "ERROR: Video source not open" << endl;
            return -1;
        }
    }

    // Get frame size.
    int width = (int)videoSource.get(CAP_PROP_FRAME_WIDTH);
    int height = (int)videoSource.get(CAP_PROP_FRAME_HEIGHT);

    // Init frames.
    Mat displayImg;
    Mat frameOpenCvBgr(height, width, CV_8UC3);
    Mat resultOpenCvBgr(height, width, CV_8UC3);
    Mat mixOpenCvBgr(height * 2, width, CV_8UC3);
    Frame frame(width, height, Fourcc::YUV24);

    // Video writer for result video.
    VideoWriter* dstWriter = nullptr;
    // Video writer for mix video.
    VideoWriter* mixWriter = nullptr;

    // Create window.
    namedWindow("Dehazer v" + Dehazer::getVersion(), WINDOW_AUTOSIZE);
    createTrackbar("Level", "Dehazer v" + Dehazer::getVersion(), &g_level, 100,
                   &levelCalback);

    // Set initial trackbar position.
    g_level = (int)g_dehazer.getParam(DehazerParam::LEVEL);
    setTrackbarPos("Level", "Dehazer v" + Dehazer::getVersion(), g_level);

    // Main loop.
    while (true)
    {
        // Capture next video frame.
        videoSource >> frameOpenCvBgr;
        if (frameOpenCvBgr.empty())
        {
            // If we have video file we can set initial position to replay.
            videoSource.set(CAP_PROP_POS_FRAMES, 1);
            continue;
        }

        // Convert BGR to YUV.
        Mat frameOpenCvYuv(frame.height, frame.width, CV_8UC3, frame.data);
        cvtColor(frameOpenCvBgr, frameOpenCvYuv, COLOR_BGR2YUV);

        // Dehaze.
        g_dehazer.dehaze(frame);

        // Convert YUV to BGR.
        cvtColor(frameOpenCvYuv, resultOpenCvBgr, COLOR_YUV2BGR);

        // Create mix image.
        memcpy(&mixOpenCvBgr.data[0], &frameOpenCvBgr.data[0], frame.size);
        memcpy(&mixOpenCvBgr.data[height * width * 3], &resultOpenCvBgr.data[0], frame.size);

        // Resize mix video if necessary to fit display.
        if (mixOpenCvBgr.size().height > 860)
        {
            int dstHeight = 860;
            int dstWidth = (int)(width * (float)dstHeight / (height * 2));
            resize(mixOpenCvBgr, displayImg, Size(dstWidth, dstHeight));
        }
        else
        {
            mixOpenCvBgr.copyTo(displayImg);
        }

        // Record video.
        if (dstWriter != nullptr)
        {
            // Record result video.
            dstWriter->write(resultOpenCvBgr);
            // Record mix video.
            mixWriter->write(mixOpenCvBgr);
            // Show "RECORDING" message.
            putText(displayImg, "RECORDING: R to stop", cv::Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, "RECORDING: R to stop", cv::Point(6, 21),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 255), 1, LINE_AA);
        }
        else
        {
            putText(displayImg, "R to start recording", cv::Point(5, 20),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, "R to start recording", cv::Point(6, 21),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255),1,LINE_AA);
        }

        string str = "Processing time: " +
        to_string((int)g_dehazer.getParam(DehazerParam::PROCESSING_TIME_MCSEC) / 1000) + " msec";
        putText(displayImg, str, Point(5, 40),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, 41),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        if (g_dehazer.getParam(DehazerParam::MODE) == 0.0f)
        {
            str = "SPACE to enable dehazer";
            putText(displayImg, str, Point(5, 60),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, str, Point(6, 61),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }
        else
        {
            str = "SPACE to disable dehazer";
            putText(displayImg, str, Point(5, 60),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
            putText(displayImg, str, Point(6, 61),
                    FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        }

        str = "RESULT";
        putText(displayImg, str, Point(5, displayImg.size().height - 10),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, displayImg.size().height - 9),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);
        str = "SOURCE";
        putText(displayImg, str, Point(5, displayImg.size().height / 2 - 10),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 0, 0), 1, LINE_AA);
        putText(displayImg, str, Point(6, displayImg.size().height / 2 - 9),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(255, 255, 255), 1, LINE_AA);

        // Show results.
        imshow("Dehazer v" + Dehazer::getVersion(), displayImg);

        // Process keyboard events.
        switch (waitKey(24))
        {
        // ESC - exit.
        case 27:
        {
            if (dstWriter != nullptr)
            {
                dstWriter->release();
                mixWriter->release();
            }
            exit(0);
        }
        // SPACE - reset video stabilizer.
        case 32:
        {
            float mode = g_dehazer.getParam(DehazerParam::MODE);
            g_dehazer.setParam(DehazerParam::MODE, 1.0f - mode);
            break;
        }
        // R - Start/stop video recording.
        case 114:
        {
            if (dstWriter != nullptr)
            {
                dstWriter->release();
                dstWriter = nullptr;
                mixWriter->release();
                mixWriter = nullptr;
            }
            else
            {
                time_t t = time(nullptr);
                tm tm = *localtime(&t);
                ostringstream oss;
                oss << put_time(&tm, "%Y_%m_%d_%H_%M_%S");
                string dateAndTime = oss.str();
                string videoFileName = "dst_" + dateAndTime + ".avi";
                cout << "Created: " << videoFileName << endl;
                dstWriter = new VideoWriter(videoFileName,
                VideoWriter::fourcc('M','J','P','G'), 30,
                resultOpenCvBgr.size(), true);
                assert(dstWriter != 0);
                videoFileName = "mix_" + oss.str() + ".avi";
                cout << "Created: " << videoFileName << endl;
                mixWriter = new VideoWriter(videoFileName,
                VideoWriter::fourcc('M','J','P','G'), 30,
                mixOpenCvBgr.size(), true);
                assert(mixWriter != 0);
            }
            break;
        }
        }
    }

    return 1;
}
